<script src="<?=JS_PATH; ?>jquery.js"></script>
<script src="<?=BS_PATH;?>js/bootstrap.min.js"></script>
<script>
    $(document).ready(function () {
        $('.lightBox').click(function () {
            var type1=$(this).attr("data-toggle");
            var link1="/"+$(this).attr("data-link");
            var postData = {};
            postData.value1 = $(this).attr("value");
            $.ajax({
                url: "<?= site_url('background');?>" + link1,
                type: 'post',
                dataType: 'html',
                data: postData
            }).done(function (data) {
                $('#myModal').find('.modal-body').html(data);
            }).fail(function () {
                alert("error");
                $('.progressdiv').hide();
            });
        });
        $('#privacymodel').click(function () {
            $.ajax({
                url: "<?PHP echo site_url('welcome/viewprivacy'); ?>",
                type: 'post',
                data: 'data=data'
            }).done(function (data) {
                $('#myModal').find('.modal-body').html(data);
            });
        });
        $('.fullview').click(function () {
            var bigdata = [];
            bigdata['need'] = 'dsdsd';
            bigdata[$(this).attr('get')] = $(this).attr('value');
            $('#myModal').find('.modal-body').html("<img class='col-xs-offset-23' src='<?= IMAGES_PATH ?>camera-loader.gif' />");
            $.ajax({
                url: "<?PHP echo site_url('welcome/viewdetails'); ?>?" + $(this).attr('get') + '=' + $(this).attr('value'),
                type: 'get',
                data: bigdata
            }).done(function (data) {
                $('#myModal').find('.modal-body').html(data);
            });
        });
    });
</script>