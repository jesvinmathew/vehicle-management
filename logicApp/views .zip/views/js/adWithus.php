
<script>
    $(function () {
                $("#exampletable").slimtable({
                    colSettings: [
                        {colNumber: 5, enableSort: false, addClasses: ['customclass']},
                        {colNumber: 4, enableSort: false, addClasses: ['customclass']}
                    ]
                });
            });
    $(document).ready(function () {
        
        $('.adBox').click(function () {            
            $.ajax({
                url: "<?PHP echo base_url('ad/adRequest');?>"
            }).done(function (data) {
                $('#myModal').show();
                $('#myModal').find('.modal-body').html(data);
                return false;
            });
        });
        $('.adDetails').click(function(){
            var postData = {};
            postData.value1=$(this).attr('id');
            $.ajax({
                url: "<?PHP echo base_url('ad/adDetails');?>",
                type: 'post',
                dataType: 'html',
                data: postData
            }).done(function (data) {
                $('#myModal').show();
                $('#myModal').find('.modal-body').html(data);
                return false;
            });
        });
    });
</script>