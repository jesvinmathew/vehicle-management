<script language="javascript" type="text/javascript" src="<?= JS_PATH;?>calendar/jquery.plugin.js"></script>
<script language="javascript" type="text/javascript" src="<?= JS_PATH;?>calendar/jquery.calendars.js"></script>
<script language="javascript" type="text/javascript" src="<?= JS_PATH;?>calendar/jquery.calendars.plus.js"></script>
<script language="javascript" type="text/javascript" src="<?= JS_PATH;?>calendar/jquery.calendars.picker.js"></script>
<script language="javascript" type="text/javascript" src="<?= JS_PATH;?>calendar/jquery.calendars.persian.js"></script>