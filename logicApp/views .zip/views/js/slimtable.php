<script language="javascript" type="text/javascript" src="<?= JS_PATH;?>slimtable.js"></script>
<script language="javascript" type="text/javascript" src="<?= JS_PATH;?>slimtable.min.js"></script>