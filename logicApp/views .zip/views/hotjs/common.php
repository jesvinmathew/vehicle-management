<script src="<?= JS_PATH; ?>jquery-1.8.2.min.js"></script>
<script src="<?= BS_PATH ?>js/bootstrap.min.js"></script>