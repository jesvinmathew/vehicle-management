<script type="text/javascript">
    $(document).ready(function () {
    $("#slctad").click(function () {
    if($("#slctad").prop('checked') == true){
        $("#caddress").html($("#paddress").val());
        }
        });
        $(".vehiDat").hide();
        $(".vehiDesc").hide();
        $(".vehiType").click(function () {
            $(".vehiDat").hide();
            $(".vehiDesc").show();
            $("#" + $(this).attr('data-filed')).show();
            $("#" + $(this).attr('data-fill')).show();
            $("#" + $(this).attr('data-f')).show();
        });
        
        $(".companyName").change(function () {
            var postData = {};
            postData.value1 = $(this).val();
            $.ajax({
                url: "<?PHP echo site_url('newjson'); ?>/getmodel",
                type: 'post',
                dataType: 'json',
                data: postData
            }).done(function (data) {
                $('#model').html('<option value="0">Select</option>');
                $.each(data, function (index, value) {
                    $('#model').append('<option value="' + value.id + '">' + value.content + '</option>');
                });
            });
        });
        $(".tomodel").change(function () {
            var postData = {};
            postData.value1 = $(this).val();
            $.ajax({
                url: "<?PHP echo site_url('newjson'); ?>/getvariant",
                type: 'post',
                dataType: 'json',
                data: postData
            }).done(function (data) {
                $('#variant').html('<option value="0">Select</option>');
                $.each(data, function (index, value) {
                    $('#variant').append('<option value="' + value.content + '">' + value.content + '</option>');
                });
            });
        });
        
        
        var error = {};
        $('.required').blur(function () {
            var variable = $(this).attr('id');
            if ($(this).val().length <= 0) {
                $(this).parent('div').children('.alert').remove();
                $(this).parent('div').append('<div class="alert">This field is required</div>').children('.alert').css('background-color', 'red');
                error[variable] = true;
                $.extend({}, error);
            } else {
                $(this).parent('div').children('.alert').css('background-color', 'green').text('Its Ok').fadeOut(3000);
                $.extend({}, postData);
                error[variable] = false;
                $.extend({}, error);
            }
        });
        $('.number').change(function () {
            if (!$.isNumeric($(this).val())) {
                
                $(this).parent('div').children('.alert').remove();
                $(this).parent('div').append('<div class="alert">This field is required</div>').children('.alert').css('background-color', 'red');
                error[variable] = true;
                $.extend({}, error);
            } else {
                $(this).parent('div').children('.alert').css('background-color', 'green').text('Its Ok').fadeOut(3000);
                $.extend({}, postData);
                error[variable] = false;
                $.extend({}, error);
            }
        });
    });

</script>
<div class="col-xs-48 col-xs-offset-1">
    <div class="col-xs-50">
        <div class="page1_block1">
            <?PHP
            $this->db->where_in('loc', array('52', '53'));
            $this->db->order_by('loc', 'ASC');
            $add = $this->db->get('add')->result();
            foreach ($add as $ad) {
                if (isset($ad->img_path1)) {
                    ?>
                    <a href="<?= $ad->link; ?>"><img src="<?= IMAGES_PATH . "advertisement/" . $ad->img_path1; ?>" class="col-xs-23 col-xs-offset-1"/></a>
                    <?php
                }
            }
            ?>
        </div>
    </div>
    <div class="col-xs-50">
        
            <div class="box2 col-xs-35">
                <div class=" col-xs-35">
                <form class="blocks" method="post" id="form" enctype="multipart/form-data">
                    <center><h2><b>Apply Vehicle Loan</b></h2></center>

                    <div class="col-xs-13"><img class="col-xs-50" src="<?= IMAGES_PATH; ?>button_required_for.png" /></div>
                    <div class="col-xs-8" style="padding:10px 0 0 20px;">
                        <input type="radio"  id="newc" class="vehiType" data-fill="newVmod" data-filed="newCmake" data-f="newVvar" name="vehiType"  value="1">New Car
                    </div>
                    <div class="col-xs-8" style="padding:10px 0 0 0;">
                        <input type="radio" id="newb" class="vehiType" data-fill="newVmod" data-filed="newBmake" data-f="newVvar" name="vehiType" value="2"> New bike
                    </div>
                    <div class="col-xs-9" style="padding:10px 0 0 0;">
                        <input type="radio" id="usedc" class="vehiType" data-fill="usedVmod" name="vehiType" data-filed="usedVmake" data-f="usedVvar" value="3">Pre owned car
                    </div>
                    <div class="col-xs-9" style="padding:10px 0 0 0;">
                        <input type="radio" id="usedb" class="vehiType" data-fill="usedVmod" name="vehiType" data-filed="usedVmake" data-f="usedVvar"  value="4"> Pre owned bike
                    </div>
                    <div class="col-xs-48 form-group col-xs-offset-1" style=" padding: 5px;">
                        <div class="col-xs-50">
                          <h2>Personal details</h2>  
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                First Name
                            </div>
                            <div class="col-xs-40"> 
                                <input type="text" placeholder="Full name"  required="required"  id="fullName" name="fullName" class="required text form-control" />
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                Last Name
                            </div>
                            <div class="col-xs-40"> 
                                <input type="text" placeholder="Last name"  required="required"  id="lName" name="lName" class="required text form-control" />
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                D.O.B
                            </div>
                            <div class="col-xs-40"> 
                                <input type="date" placeholder="Date of birth"  required="required"  id="dob" name="dob" class="text form-control" type="date" />
                            </div>
                        </div>
                        <div class="col-xs-24 form-group" ><br/>
                        <div class="col-xs-9 col-xs-offset-1">
                        Gender
                    </div><br/>

                    <div class="col-xs-15" >
                        <input type="radio" id="male"   name="sex"   value="male" >Male
			<input type="radio" id="female"   name="sex"   value="female">Female
                    </div>
                    </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-50">
                                Mobile Number
                            </div>
                            <div class="col-xs-10"> 
                                <input type="text" required="required"  id="cuCode" name="cuCode" value="+91" class="number form-control" />
                            </div>
                            <div class="col-xs-30"> 
                                <input type="text" placeholder="Mobile no"  required="required"  id="mobileNo" name="mobileNo" class="number form-control" />
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-50">
                                Land no
                            </div>
                            <div class="col-xs-15"> 
                                <input type="text" placeholder="Code" required="required"  id="lCode" name="lCode" value="" class="number form-control" />
                            </div>
                            <div class="col-xs-25"> 
                                <input type="text" placeholder="Land no"  required="required"  id="landNo" name="landNo" class="text form-control" type="email" />
                            </div>
                        </div>
                        
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                Email id
                            </div>
                            <div class="col-xs-40"> 
                                <input type="email" placeholder="Email id"  required="required"  id="emailId" name="emailId" class="text form-control" type="email" />
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                Residence type
                            </div>
                            <div class="col-xs-40"> 
                                <select name="residence" class="tmSelect auto form-control" required="required" style="line-height:13px;" id="selectresidence" data-class="tmSelect tmSelect2" data-constraints="">
                                    <option value="">Select residence type</option>
                                    <option value="Owned by self/spouse">Owned by self/spouse</option>
                                    <option value="Owned by parents/siblings">Owned by parents/siblings</option>
                                    <option value="Rented-with family">Rented-with family</option>
                                    <option value="Rented-with friends">Rented-with friends</option>
                                    <option value="Rented-staying alone">Rented-staying alone</option>
                                    <option value="Paying guest">Paying guest</option>
                                    <option value="Hostel">Hostel</option>
                                    <option value="Company provided">Company provided</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                Permanent address
                            </div>
                            <div class="col-xs-40">
                                <textarea  placeholder="Address"  required="required"  id="paddress" name="paddress" class="text form-control"></textarea>
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                Current address
                            </div>
                            <div class="col-xs-40">
                                <textarea  placeholder="Address"  required="required"  id="caddress" name="caddress" class="text form-control"></textarea>
                            </div>
                        </div>
                        <div class="col-xs-50 form-group">
                        <input type = "checkbox"
                               id = "slctad"
                               value = "checkbox" />Current address same as Permanant address
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                District
                            </div>
                            <div class="col-xs-40"> 
                                <select name="pdistrict" class="tmSelect auto form-control" required="required" style="line-height:13px;" id=pdistrict"" data-class="tmSelect tmSelect2" data-constraints="">
                                    <option value="0">Select district</option>
                                    <?PHP
                                    foreach ($district as $dis) {
                                        echo "<option value='$dis->placename'>$dis->placename</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                District
                            </div>
                            <div class="col-xs-40"> 
                                <select name="cdistrict" class="tmSelect auto form-control" required="required" style="line-height:13px;" id="cdistrict" data-class="tmSelect tmSelect2" data-constraints="">
                                    <option value="0">Select district</option>
                                    <?PHP
                                    foreach ($district as $dis) {
                                        echo "<option value='$dis->placename'>$dis->placename</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                Pin code
                            </div>
                            <div class="col-xs-40"> 
                                <input type="number" placeholder="Pin code"  required="required"  id="ppinCode" name="ppinCode" class="text form-control" type="email" />
                            </div>
                        </div>
                        
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                Pin code
                            </div>
                            <div class="col-xs-40"> 
                                <input type="number" placeholder="Pin code"  required="required"  id="cpinCode" name="cpinCode" " class="text form-control" type="email" />
                            </div>
                        </div>
                        
                        
                        
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                When did you move to current residence
                            </div>
                            <div class="col-xs-20">
                                <select name="tYear" class="select required form-control" required="required" id="tYear">
                                    <option value="0" selected="selected">year</option>
                                    <?php
                                    $i = 2014;
                                    while ($i >= 1920) {
                                        echo '<option value="' . $i . '">' . $i . '</option>';
                                        $i--;
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="col-xs-20"> 
                                <select name="tMonth" class="select required form-control" required="required" id="tMonth">
                                    <option value="" selected="selected">month</option>
                                    <option value="january" >January</option>
                                    <option value="February" >February</option>
                                    <option value="March">March</option>
                                    <option value="April" >April</option>
                                    <option value="May" >May</option>
                                    <option value="June" >June</option>
                                    <option value="July" >July</option>
                                    <option value="August">August</option>
                                    <option value="September" >September</option>
                                    <option value="October" >October</option>
                                    <option value="November" >November</option>
                                    <option value="December" >December</option>
                                </select> 
                            </div>
                        </div>
                </div>
                <hr style=" color:  brown">
            <div class="col-xs-48 form-group col-xs-offset-1" style=" padding: 5px;">
                        
                        <div class="col-xs-50 vehiDesc">
                          <h2>Vehicle details:</h2>  
                        </div>
                        
                        <div class="col-xs-24 form-group vehiDat" id="newCmake">
                            <div class="col-xs-40">
                                Make
                            </div>
                            <div class="col-xs-40"> 
                                <select name="newmakeC" class="companyName tmSelect auto form-control"  style="line-height:13px;" id="car" data-class="tmSelect tmSelect2" data-constraints="">
                                    <option value="">Select make</option>
                                    <?PHP
                                    foreach ($Cbrands as $brand)
                                        echo "<option value='$brand->cmp_id'>$brand->companyname</option>";
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-24 form-group vehiDat" id="newBmake">
                            <div class="col-xs-40">
                                Make
                            </div>
                            <div class="col-xs-40"> 
                                <select name="newmakeB" class="companyName tmSelect auto form-control"  style="line-height:13px;" id="bike" data-class="tmSelect tmSelect2" data-constraints="">
                                    <option value="">Select make</option>
                                    <?PHP
                                    foreach ($Bbrands as $brand)
                                        echo "<option value='$brand->cmp_id'>$brand->companyname</option>";
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-24 form-group vehiDat" id="usedVmake">
                            <div class="col-xs-40">
                                Make
                            </div>
                            <div class="col-xs-40"> 
                                <input type="text" placeholder="Type make"    id="companyName1" name="usedmake" class="text form-control" type="email" />
                            </div>
                        </div>
                        <div class="col-xs-24 form-group vehiDat" id="usedVmod">
                            <div class="col-xs-40">
                                Model
                            </div>
                            <div class="col-xs-40"> 
                                <input type="text" placeholder="Type model"  id="model1" name="usedmodel" class="text form-control" type="email" />
                            </div>
                        </div>
                        <div class="col-xs-24 form-group vehiDat" id="newVmod">
                            <div class="col-xs-40">
                                Model
                            </div>
                            <div class="col-xs-40"> 
                                <select name="newmodel" class="tmSelect auto form-control tomodel" style="line-height:13px;" id="model" data-class="tmSelect tmSelect2" data-constraints="">
                                    <option value="">Select model type</option>                    
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-24 form-group vehiDat" id="newVvar">
                            <div class="col-xs-40">
                                Variant
                            </div>
                            <div class="col-xs-40"> 
                                <select name="newvariant" class="tmSelect auto form-control" style="line-height:13px;" id="variant" data-class="tmSelect tmSelect2" data-constraints="">
                                    <option value="">Select variant type</option>                    
                                </select>
                            </div>
                        </div>
                <div class="col-xs-24 form-group vehiDat" id="usedVvar">
                            <div class="col-xs-40">
                                Variant
                            </div>
                            <div class="col-xs-40"> 
                                <input type="text" placeholder="Type variant"  id="variant1" name="usedvariant" class="text form-control"/>
                            </div>
                        </div>
                <div class="col-xs-50">
                          <h2>Proffessional details:</h2>  
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                Type of employment
                            </div>
                            <div class="col-xs-40"> 
                                <select name="employ" class="tmSelect auto form-control" required="required" style="line-height:13px;" id="selectemploy" data-class="tmSelect tmSelect2" data-constraints="">
                                    <option value="">Select type</option>
                                    <option value="Salaried">Salaried</option>
                                    <option value="Self employed business">Self employed business</option>
                                    <option value="Self employed proffessional">Self employed proffessional</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                Loan amount
                            </div>
                            <div class="col-xs-40"> 
                                <input type="number" placeholder="Loan amount" required="required"   id="loanAmount" name="loanAmount" class="text form-control" type="email" />
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                Annual income
                            </div>
                            <div class="col-xs-40"> 
                                <input type="number" placeholder="Annual income"  required="required"  id="anualIncome" name="anualIncome" class="text form-control" type="email" />
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                Select bank
                            </div>
                            <div class="col-xs-40"> 
                                <select name="bank" class="tmSelect auto form-control" required="required" style="line-height:13px;" id="selectbank" data-class="tmSelect tmSelect2" data-constraints="">
                                    <option value="">Select bank</option>
                                    <option value="HDFC">HDFC bank</option>
                                    <option value="SBT">SBT bank</option>
                                    <option value="SBI">SBI bank</option>
                                    <option value="Axis">Axis bank</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                Upload pancard copy (max-size 5 mb)
                            </div>
                            <div class="col-xs-40"> 
                                <input  class="form-control" name="pancard" id="image" type="file"   />
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                Upload address proof (max-size 5 mb)
                            </div>
                            <div class="col-xs-40"> 
                                <input  class="form-control" name="addrproof" id="image" type="file"   />
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                Statements of 3 month income(max-size 5 mb)
                            </div>
                            <div class="col-xs-40"> 
                                <input   class="form-control"  name="salaryStmnt" id="image" type="file"   />
                            </div>
                        </div>
                    </div>
                    <div class="clear"></div>
                    <div class="col-xs-40">
                        <p>Vehicle Booked: <input type="radio"  name="select" value="3"> Yes
                            <input type="radio" name="select" value="4"> No</p>
                    </div>
                    <div class="col-xs-50">
			<input type = "checkbox"
                               id = "chk"
                               value = "checkbox" required="required" /> I declare that the information I have provided above is accurate and complete to the best of my knowledge.I authorize Keralaonroad its representatives to call or sms me with reference to my loan application as per our <a href="<?= site_url('welcome/view/privacy-policy'); ?>">privacy policy</a> and<a href="<?= site_url('welcome/view/terms-and-conditions'); ?>"> Terms and conditions</a>
                    </div>
                    <div class="col-xs-20">
                        <input type="submit" name="submit" id="sentMail" value="Submit" class="btn" />
                    </div>
                    </form>
                </div>
                
                <div class="col-xs-15" style="padding-top: 75px;">
    	<?PHP 
            
              $this->db->where_in('loc', array('104', '105'));
              $this->db->order_by('loc', 'ASC');
              $add = $this->db->get('add')->result();
              foreach($add as $ad){
              if(isset($ad->img_path1)){
                        ?>
        <a href="<?=$ad->link;?>"><img src="<?= IMAGES_PATH . "advertisement/" . $ad->img_path1; ?>" style="margin: 20px 0 20px 0"/></a>
          <?php }
                     }
                ?>
    </div>
                <div class="clear"></div>
        
    </div>
</div>

<div class="col-xs-50">
    <div class="page1_block1">
        <?PHP
        $this->db->where('loc', 45);
        $this->db->order_by('loc', 'ASC');
        $add = $this->db->get('add')->result();
        if (isset($add[0]->img_path1)) {
            ?>
            <a href="<?= $add[0]->link; ?>"><img src="<?= IMAGES_PATH . "advertisement/" . $add[0]->img_path1; ?>" class="col-xs-48 col-xs-offset-1"/></a>
            <?php } ?>
    </div>
</div>
</div>