<form method="POST" enctype="multipart/form-data">
<div class="col-xs-50" style="padding:20px;">
            <div class="col-xs-15">
                <label>Upload Image Here</label>
            </div>
            <div class="col-xs-25">
                <input  class="form-control" name="userfile" id="image" type="file" style="width: 500px;"  />
            </div>
    <div class="col-xs-15">
                <label>Paste Link Jere</label>
            </div>
            <div class="col-xs-25">
                <input  class="form-control" name="link" id="link" type="text" style="width: 500px;"  />
            </div>
            <div class="col-xs-10" style="float:right">
                <input type="submit" name="submit" value="upload" class="form-control" style="width: 70px;" />
            </div>
        </div>
</form>
