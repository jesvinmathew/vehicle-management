<div class="col-xs-48 col-xs-offset-1">
    <div class="col-xs-50">
        <div class="col-xs-50 col-md-35">
            <div class="h1">Advertisement Details </div>
	<table id='exampletable'>
            <thead>
                <tr>
                    <th>Location</th>
                    <th>Type</th>
                    <th>Position</th>
                    <th>Duration</th>
                    <th></th><th></th>
                </tr>
            </thead>
            <tbody>
                <?PHP
                    foreach ($ad as $add){
                        ?>
                <tr>
                    <td><?=$add->location;?></td><td><?=$add->type;?></td><td><?=$add->postion;?></td><td><?=$add->duration;?></td>
                    <td><a id="<?= $add->id; ?>" class="adDetails" data-target="#myModal" data-toggle="modal" href="#myModal">Details</a></td>
                    <td><a href="<?=site_url('ad/adRequest');?>"><img src="<?= IMAGES_PATH ?>contact.png" width="103" height="38" alt="contact"></a></td>
                </tr>
                        <?PHP
                    }
                ?>
            </tbody>
        </table>
        </div>
    </div>
</div>
<script type='text/javascript'>
            
        </script>