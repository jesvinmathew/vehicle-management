<script src="<?PHP echo JS_PATH; ?>jquery.js"></script>
<script type="text/javascript">
    $(document).ready(function (){
        
        $("#submit").click(function(){
            var toname="";
            var toemail="";
            var msg="";
            if($("#name").val()!=""){
                msg+="Name:"+$("#name").val();
                toname=$("#name").val();
            }
            else{
                alert("Please enter Name");
                return false;
            }
            if($("#phone").val()!=""){
        
                msg+="<br />phone:"+$("#phone").val();
            }
            else{
                alert("Please enter phone");
                return false;
            }
            if($("#message").val()!=""){
        
                msg+="<br />message:"+$("#message").val();
            }
            else{
                alert("Please enter your message");
                return false;
            }
            if($("#email").val()!=""){
                msg+="<br />email:"+$("#email").val();
                toemail=$("#email").val();
            }
            else{
                alert("Please enter email id");
                return false;
            }
            var postdata = {};
            postdata.toname = toname;
            postdata.toemail = toemail;
            postdata.msg = msg;
            $.ajax({
                url: "<?= site_url('welcome'); ?>/contact",
                type: 'post',
                dataType: 'html',
                data: postdata
            }).done(function (data) {
                alert(data);
            });
        });
    });
</script>
<div class="col-xs-48 col-xs-offset-1">
    <div class="col-xs-49">
        <?=isset($msg)?"<center><h4 class='mb1'>$msg</h4></center>":"";?>
        <center><h2 class="mb1">Contact Us</h2></center>
        <div class="col-xs-24">
            
                <div class="col-xs-50">
                    <div class="col-xs-10 form-group">
                        <label class="name">Name :</label>
                    </div>	
                    <div class="col-xs-34">
                        <input class="text form-control"  type="text" id="name" name="name" placeholder="Contact Name" required="required" />
                    </div>	
                </div>
                <div class="col-xs-50" >
                    <div class="col-xs-10 form-group">
                        <label class="name">Phone :</label>
                    </div>	
                    <div class="col-xs-34">     
                        <input class="text form-control" type="text"  id="phone" name="phone" placeholder="Contact Phone Number" required="required" />

                    </div>  
                </div>
                <div class="col-xs-50">

                    <div class="col-xs-10 form-group">
                        <label class="name" for="email">Email :</label>
                    </div>	
                    <div class="col-xs-34">   
                        <input placeholder="Enter Your User Name"   id="email" name="email" class="text form-control" type="email" required="required" />

                    </div>  
                </div>
                <div class="col-xs-50">
                    <div class="col-xs-10 form-group">
                        <label class="name" for="msg">Message :</label>
                    </div>
                    <div class="col-xs-34">
                        <textarea class="text form-control"  id="message" name="message" required="required" placeholder="Eneter Your Message"></textarea>
                    </div>
                </div>
                <div class="col-xs-50">

                    <div class="col-xs-12 form-group">
                        <label>&nbsp;</label>
                        <input type="button" id="submit" class="btn" value="Send" />
                    </div>
                </div>
            
        </div>
        <div class="col-xs-24" id="details" >
            
            <table style="width:100%">
  
  <tr>
      <td><h6>Head Office – Kerala</h6></td>
    
  </tr>
  <tr>
    <td>Kerala on road</td>
    
  </tr>
  <tr>
    <td>26/700</td>
    
  </tr>
  <tr>
    <td>Soorya Platinum</td>
    
  </tr>
  <tr>
    <td>Nurani</td>
    
  </tr>
  <tr>
    <td>Palakkad - 678004</td>
    
  </tr>
  <tr>
    <td>Kerala</td>
    
  </tr>
  <tr>
    <td>India</td>
    
  </tr>
  
  <tr>
      <td><h6>Contact No</h6></td>
    
  </tr>
  <tr>
    <td>+91- 491-2503260</td>
    
  </tr>
  <tr>
    <td>+91- 491-2503261</td>
    
  </tr>
  <tr>
    <td>+91- 491-2503262</td>
    
  </tr>
  <tr>
      <td><h6>Email Id</h6></td>
    
  </tr>
  <tr>
    <td>info@keralaonroad.com</td>
    
  </tr>
  <tr>
    <td>support@keralaonroad.com</td>
    
  </tr>
</table>
        </div>
    </div>
</div> 