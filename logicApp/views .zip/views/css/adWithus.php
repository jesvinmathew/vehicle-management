<style>
.row1{
    background: #f1f1f1;
    border: solid 1px #ccc;
}
.row2{
    background: #fafafa;
    border: solid 1px #ccc;
}
.row3
{
	width:740px;
	height:250px;
	background:url(<?=IMAGES_PATH ?>row_grey.jpg) no-repeat;
}
.row4
{
	width:740px;
	height:250px;
	background:url(<?=IMAGES_PATH ?>row_white.jpg) no-repeat;
}
.row5
{
	width:740px;
	height:250px;
	background:url(<?=IMAGES_PATH ?>row_grey.jpg) no-repeat;
}
.row6
{
	width:740px;
	height:250px;
	background:url(<?=IMAGES_PATH ?>row_white.jpg) no-repeat;
}
.row7
{
	width:740px;
	height:250px;
	background:url(<?=IMAGES_PATH ?>row_grey.jpg) no-repeat;
}
.h1{
	font-family:"Myriad Pro";
	font-size:27px;
	font-weight:bold;
	color:#6c9bb7;
}
.h2{
	font-family:"Myriad Pro";
	font-size:18px;
	font-weight:600;
	color:#000;
}
.h3
{
	font-family:"Myriad Pro";
	font-size:17px;
	font-weight:200;
	color:#000;
}
.h4
{
	font-family:"Myriad Pro";
	font-size:13px;
	line-height:25.99pt;
	color:#000;
}
.h4_copy
{
	font-family:"Myriad Pro";
	font-size:13px;
	line-height:23.99pt;
	color:#000;
}

.box11
{
	padding-left:30px;
	padding-top:5px;
}
.box21
{
	padding-left:30px;
}
.box31
{
    margin-top: -10px;
    padding-left:30px;
}
.box41
{
	padding-left:30px;
	text-align:right;
	padding-right:25px;
}
</style>