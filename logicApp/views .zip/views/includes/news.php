		<section><p>				
			<div class="grid_4 alpha"  align="justify">
       	    	<img class="image" src="<?php echo IMAGES_PATH;?>/page1_img7.jpg">Lorem ipsum dolor sit amet conse ctetur Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<br><strong class="fright"><a href="#">More</strong></a><br>
            </div>
            <div class="grid_4"  align="justify">
       	    	<img class="image" src="<?php echo IMAGES_PATH;?>/page1_img8.jpg">Lorem ipsum dolor sit amet conse ctetur Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<br><strong class="fright"><a href="#">More</strong></a><br>
            </div>
            <div class="grid_4 alpha"  align="justify">
       	    	<img class="image" src="<?php echo IMAGES_PATH;?>/page1_img9.jpg">Lorem ipsum dolor sit amet conse ctetur Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<br><strong class="fright"><a href="#">More</strong></a><br>
            </div>
            <div class="grid_4"  align="justify">
       	    	<img class="image" src="<?php echo IMAGES_PATH;?>/page1_img10.jpg">Lorem ipsum dolor sit amet conse ctetur Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<br><strong class="fright"><a href="#">More</strong></a><br>
            </div>
      			
		</p></section>