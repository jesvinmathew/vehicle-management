 <div class="footer col-xs-50 ">
    <div class="col-xs-20 col-sm-9 col-xs-offset-1">
        <br />
        <ul>
            <li><a href="<?= site_url('welcome/view/about');?>">About us</a></li>
            <li><a href="<?= site_url('welcome/view/terms-and-conditions');?>">Terms and conditions</a></li>
            <li><a href="#">COPYRIGHT</a></li>
            <li><a href="<?= site_url('welcome/view/visitor-agreement');?>">User agreement</a></li>
        </ul>
    </div>
    <div class="col-xs-20 col-sm-9 col-xs-offset-1">
        <br />
        <ul>
            <li><a href="<?= site_url('ad/adsWithus');?>">Advertise with us</a></li>
            <li><a href="<?= site_url('welcome/plans');?>">User plans</a></li>
            <li><a href="<?= site_url('welcome/contact'); ?>">Contact us</a></li>
            <li><a href="<?= site_url('hotties');?>">Hot groups</a></li>
        </ul>
    </div>
     <div class="col-xs-20 col-sm-9 col-xs-offset-1">
        <br />
        <ul>
            <li><a href="<?= site_url('welcome/sell/car');?>">Sell car</a></li>
            <li><a href="<?= site_url('welcome/sell/bike');?>">Sell bike</a></li>
            <li><a href="<?= site_url('welcome/brands/car');?>">Car brands</a></li>
            <li><a href="<?= site_url('welcome/brands/bike');?>">Bike brands</a></li>
        </ul>
    </div>
     <div class="col-xs-20 col-sm-9 col-xs-offset-1">
        <br />
        <ul>
            <li><a href="<?= site_url('welcome/search');?>">Search</a></li>
            <li><a href="<?= site_url('welcome/dealers/used/car');?>">Used car dealers</a></li>
            <li><a href="<?= site_url('welcome/dealers/used/bike');?>">Used bike dealers</a></li>
            <li><a href="<?= site_url('welcome/dealers/new/car');?>">New car dealers</a></li>
        </ul>
    </div>
     <div class="col-xs-20 col-sm-9 col-xs-offset-1">
        <br />
        <ul>
            <li><a href="<?= site_url('welcome/dealers/new/bike');?>">New bike dealers</a></li>
            <li><a href="<?= site_url('insurance');?>">Insurance</a></li>
            <li><a href="<?= site_url('welcome/loan');?>">Loan</a></li>
            <li><a href="<?= site_url('news');?>">News and events</a></li>
        </ul>
    </div>
    <!--<div class="col-xs-24 col-sm-10 col-xs-offset-1">
        <h4 style="color:#fff;">My Account</h4>
        <ul>
            <li><a href="#">Incididunt ut labore </a></li>
            <li><a href="#">Et dolore magna aliqua</a></li>
            <li><a href="#">Ut enim ad minim veniam</a></li>
            <li><a href="#">Quis nostrud exercitation </a></li>
            <li><a href="#">Lorem ipsum dolor </a></li>
            <li><a href="#">Conse ctetur adipisicing </a></li>
            <li><a href="#">Elit sed do eiusmod </a></li>
        </ul>
    </div>
    <div class="col-xs-24 col-sm-16 col-xs-offset-1">
        <h4 style="color:#fff;">Store Information</h4>
        <p style="color:#FF9;">4578 Marmora Road, Glasgow D04 89</p>
        <h4 style="color:#fff;">Reservation Centre: </h4>
        <div class="f_phone">(800) 2345-7896</div>
        <div class="socials"><a href="#" class="fa fa-twitter "></a><a href="#" class="fa fa-facebook"></a></div>
    </div>-->
   
    <div class="col-xs-50 copy">
        <div class="col-xs-1"></div>
        <div class="col-xs-49">Kerala On Road  &copy; <span id="copyright-year"></span>. <!-- class="lightBox"  data-toggle="wp" data-target=""--><a href="<?= site_url('welcome/view/privacy-policy');?> " >Privacy Policy</a> <!--{%FOOTER_LINK} -->
        </div>
    </div>
</div>
 <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>

                </div>
                <div class="modal-body">

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

                </div>
            </div>
        </div>
    </div>  