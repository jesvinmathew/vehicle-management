<ul id="itemContainer2">
        	<li>
        		<div class="grid_3 alpha">
          			<div class="block1">
            		<img src="<?php echo IMAGES_PATH;?>/page1_img6.jpg" alt="">
            		<div class="title"><a href="#">Lorem ipsum dolor sit amet conse ctetur</a></div>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            		<div class="price">$1.899<span>300 KM INCLUDED PER DAY</span></div>
            		<a href="#" class="btn">details</a>
          			</div>
        		</div>
              </li>
              <li>
        		<div class="grid_3">
          			<div class="block1">
            		<img src="<?php echo IMAGES_PATH;?>/page1_img5.jpg" alt="">
            		<div class="title"><a href="#">Lorem ipsum dolor sit amet conse ctetur</a></div>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            		<div class="price">$1.899<span>300 KM INCLUDED PER DAY</span></div>
            		<a href="#" class="btn">details</a>
          			</div>
        		</div>
              </li>
              <li>
        		<div class="grid_3">
          			<div class="block1">
            		<img src="<?php echo IMAGES_PATH;?>/page1_img4.jpg" alt="">
            		<div class="title"><a href="#">Lorem ipsum dolor sit amet conse ctetur</a></div>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            		<div class="price">$1.899<span>300 KM INCLUDED PER DAY</span></div>
            		<a href="#" class="btn">details</a>
          			</div>
        		</div>
              </li>
              <li>
        		<div class="grid_3">
          			<div class="block1">
            		<img src="<?php echo IMAGES_PATH;?>/page1_img3.jpg" alt="">
            		<div class="title"><a href="#">Lorem ipsum dolor sit amet conse ctetur</a></div>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            		<div class="price">$1.899<span>300 KM INCLUDED PER DAY</span></div>
            		<a href="#" class="btn">details</a>
          			</div>
        		</div>
              </li>
              <li>
        		<div class="grid_3 alpha">
          			<div class="block1">
            		<img src="<?php echo IMAGES_PATH;?>/page1_img2.jpg" alt="">
            		<div class="title"><a href="#">Lorem ipsum dolor sit amet conse ctetur</a></div>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            		<div class="price">$1.899<span>300 KM INCLUDED PER DAY</span></div>
            		<a href="#" class="btn">details</a>
          			</div>
        		</div>
              </li>
              <li>
        		<div class="grid_3">
          			<div class="block1">
            		<img src="<?php echo IMAGES_PATH;?>/page1_img1.jpg" alt="">
            		<div class="title"><a href="#">Lorem ipsum dolor sit amet conse ctetur</a></div>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            		<div class="price">$1.899<span>300 KM INCLUDED PER DAY</span></div>
            		<a href="#" class="btn">details</a>
          			</div>
        		</div>
              </li>
              <li>
        		<div class="grid_3">
          			<div class="block1">
            		<img src="<?php echo IMAGES_PATH;?>/page1_img6.jpg" alt="">
            		<div class="title"><a href="#">Lorem ipsum dolor sit amet conse ctetur</a></div>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            		<div class="price">$1.899<span>300 KM INCLUDED PER DAY</span></div>
            		<a href="#" class="btn">details</a>
          			</div>
        		</div>
              </li>
              <li>
        		<div class="grid_3">
          			<div class="block1">
            		<img src="<?php echo IMAGES_PATH;?>/page1_img5.jpg" alt="">
            		<div class="title"><a href="#">Lorem ipsum dolor sit amet conse ctetur</a></div>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            		<div class="price">$1.899<span>300 KM INCLUDED PER DAY</span></div>
            		<a href="#" class="btn">details</a>
          			</div>
        		</div>
              </li>
              <li>
        		<div class="grid_3 alpha">
          			<div class="block1">
            		<img src="<?php echo IMAGES_PATH;?>/page1_img4.jpg" alt="">
            		<div class="title"><a href="#">Lorem ipsum dolor sit amet conse ctetur</a></div>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            		<div class="price">$1.899<span>300 KM INCLUDED PER DAY</span></div>
            		<a href="#" class="btn">details</a>
          			</div>
        		</div>
              </li>
              <li>
        		<div class="grid_3">
          			<div class="block1">
            		<img src="<?php echo IMAGES_PATH;?>/page1_img3.jpg" alt="">
            		<div class="title"><a href="#">Lorem ipsum dolor sit amet conse ctetur</a></div>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            		<div class="price">$1.899<span>300 KM INCLUDED PER DAY</span></div>
            		<a href="#" class="btn">details</a>
          			</div>
        		</div>
              </li>
              <li>
        		<div class="grid_3">
          			<div class="block1">
            		<img src="<?php echo IMAGES_PATH;?>/page1_img2.jpg" alt="">
            		<div class="title"><a href="#">Lorem ipsum dolor sit amet conse ctetur</a></div>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            		<div class="price">$1.899<span>300 KM INCLUDED PER DAY</span></div>
            		<a href="#" class="btn">details</a>
          			</div>
        		</div>
              </li>
              <li>
        		<div class="grid_3">
          			<div class="block1">
            		<img src="<?php echo IMAGES_PATH;?>/page1_img1.jpg" alt="">
            		<div class="title"><a href="#">Lorem ipsum dolor sit amet conse ctetur</a></div>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            		<div class="price">$1.899<span>300 KM INCLUDED PER DAY</span></div>
            		<a href="#" class="btn">details</a>
          			</div>
        		</div>
              </li>
           </ul>