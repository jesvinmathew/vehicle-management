<div class="slider_wrapper ">
      <div id="camera_wrap">    
        <div data-src="<?php echo IMAGES_PATH;?>advertisement/ekm_ad_4_homepage.jpg"></div>
        <div data-src="<?php echo IMAGES_PATH;?>advertisement/ekm_ad_4_homepage.jpg"></div>
       </div>
</div>   