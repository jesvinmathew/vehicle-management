<div class="col-xs-50" id="showresults">


</div>
<ul class="pager" style="cursor: pointer;">
    <li class="previous" value="0"><a >Previous</a></li>
    <li  class="next" value="10" ><a >Next</a></li>
</ul>