<div class="col-xs-50 col-xs-offset-1" id="main_page">
    <div class="col-xs-48 whiteBox1">
            <?php
            foreach ($images as $img){?>
        <div class="col-xs-25" style="padding: 5px 0 0 0;" align='center'><?=$img->datainfo;?></div><?PHP
            }
            ?>
    </div>
</div>
