<?php if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class Admin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }
    public function index()
    {
        $webData['tittle'] = "Welcome To KeralaONRoads";
        $webData['style'][] = "index";
        $webData['script'][] = "index";
        $webData['content'][] = 'welcome';
        $this->load->view('templates/welcome', $webData);
    }
    public function logout()
    {
        $this->session->unset_userdata('keralaonroads');
        redirect(base_url() . 'welcome', 'refresh');
        header('location:' . base_url() . 'welcome');
    }
    public function placemanage(){
	    if ($this->session->userdata('keralaonroads_admin')) {
	        $webData['country'] = $this->db->get_where('place',  array('type'=>1))->result();
	        $webData['tittle'] = "Welcome To KeralaOnRoads- Place Mange";
	        $webData['script'][] = "placeMange";
	        $webData['content'][] = 'placeMange';
	        $this->load->view('templates/welcome', $webData);
	}
        else
        redirect('welcome/login');
    }
    public function plans(){
    	if ($this->session->userdata('keralaonroads_admin')) {
	        $webData['plans'] = $this->db->get('uptype')->result();
	        $webData['tittle'] = "Welcome To KeralaOnRoads- Plans";
	        $webData['content'][] = 'planMange';
	        $webData['script'][] = "planMange";
	        $this->load->view('templates/welcome', $webData);
	}
        else
        	redirect('welcome/login');
    }
    public function updatePlan(){
    	if ($this->session->userdata('keralaonroads_admin')) {
    		if(is_array($_POST)){
    			$this->db->update('uptype',$_POST,array('uptype_id'=>$this->input->post('uptype_id')));
    			echo "Updated Successfully";
    		}
    		else{
    			echo "File error";
    		}
    	}
    }

}