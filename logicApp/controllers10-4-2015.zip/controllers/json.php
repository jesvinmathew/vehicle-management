<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Json extends CI_Controller {

    public function __construct() {
        parent::__construct();
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
        header('Content-type: application/json; charset=utf8');
        $this->load->helper(array('form', 'url'));
        $this->load->model('datas');
        $this->load->model('CommanModel');
        $this->load->model('validate');
        $this->load->model('users');
    }

    public function register() {
        $this->load->library('encrypt');
        if (!isset($_POST['name'])) {
            $this->datas->data->message = 'Please enter your name';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (( strlen($this->input->post('name')) <= 3 ) || ( strlen($this->input->post('name')) >
                30 )) {
            $this->datas->data->message = 'Please enter your name use 4-30 characters';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!preg_match("/^[a-zA-Z' .-]+$/", $this->input->post('name'))) {
            $this->datas->data->message = 'Please enter your name use A-Z a-z characters';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['location'])) {
            $this->datas->data->message = 'Please enter your location';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (( strlen($this->input->post('location')) <= 3 ) || ( strlen($this->input->post('location')) >
                30 )) {
            $this->datas->data->message = 'Please enter your location use 4-30 characters';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!preg_match("/^[a-zA-Z' .-]+$/", $this->input->post('location'))) {
            $this->datas->data->message = 'Please enter your location use A-Z a-z characters';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['phone'])) {
            $this->datas->data->message = 'Please enter a  Mobile Number';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (( strlen($this->input->post('phone')) <= 9 ) || ( strlen($this->input->post('phone')) >
                12 )) {
            $this->datas->data->message = 'Not a valid Mobile Number only 10 to 12 charcters allowed';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!preg_match("/^[0-9]+$/", $this->input->post('phone'))) {
            $this->datas->data->message = 'Not a valid Mobile Number only numbers allowedsss';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['email'])) {
            $this->datas->data->message = 'Please enter your email';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!filter_var($this->input->post('email'), FILTER_VALIDATE_EMAIL)) {
            $this->datas->data->message = 'Enter a valid email address like "example@mail.com"';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (( strlen($this->input->post('email')) <= 6 ) || ( strlen($this->input->post('email')) >
                50 )) {
            $this->datas->data->message = 'Enter a valid email address use 7-50 charcters';
            $this->datas->data->error = true;
            $this->datas->output();
        } else {
            $sql = $this->db->get_where('users', array('email' => $this->input->post('email')));
            if ($sql->num_rows() > 0) {
                $this->datas->data->message = 'This email already exists in our records';
                $this->datas->data->error = true;
                $this->datas->output();
            }
            $sql->free_result();
        }
        if (!isset($_POST['pass'])) {
            $this->datas->data->message = 'Please enter a password';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (strlen($this->input->post('pass')) <= 5) {
            $this->datas->data->message = 'Password is too small min 5 characters';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['rpass'])) {
            $this->datas->data->message = 'Please Enter confirm password';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if ($this->input->post('pass') != $this->input->post('rpass')) {
            $this->datas->data->message = 'Password and confirm passwords do not match';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (( isset($_POST['email']) ) && ( isset($_POST['pass']) )) {
            $password = $this->input->post('pass');
            $username = $this->input->post('email');
            if ($password == $username) {
                $this->datas->data->message = 'Same Email and password';
                $this->datas->data->error = true;
                $this->datas->output();
            }
            $this->datas->data->ph = $this->input->post('phone');
            $this->users->make_password($password);
            $ipaddress = $this->input->ip_address();
            $platform = 1;
            $password = $this->users->enc_password;
            $this->users->make_email_conf_key($username);
            $ccEmail = "admin.executive@keralaonroad.com";
            $this->db->insert('users', array(
                'email' => $username,
                'username' => $this->input->post('name'),
                'passwords' => $password,
                'contactno' => $this->input->post('phone'),
                'location' => $this->input->post('location'),
                'status' => 0,
                'utype_id' => 1,
                'created_at' => date("Y-m-d H:i:s"),
                'ac_type' => 1,
                'keys' => $this->users->confirmkey,
                'ipaddress' => $ipaddress));
            $this->load->library('email');
            $config = Array(
                'protocol' => 'smtp',
                'smtp_host' => 'vps.tricetechnologies.in',
                'smtp_port' => 587,
                'smtp_user' => 'development@keralaonroad.com',
                'smtp_pass' => '_C^(4^6L=P^r',
                'mailtype' => 'html',
                'charset' => 'iso-8859-1'
            );
            $this->email->initialize($config);
            $this->email->from('development@keralaonroad.com', 'Support');
            $this->email->to($this->input->post('userName'));
            $this->email->cc('info@keralaonroad.com');
            $this->email->subject('Welcome TO keralaonroad.com');
            $this->email->message('<div style="color: #f00; font-weight: bold;"><h2>WELCOME TO KERALA ON ROAD</h2><br /><a style="color: #f00;" href="http://www.keralaonroad.com/">www.keralaonroad.com</a><br />India�s N0.1 Automobile sellers, buyers, retailers, manufacturers and all related entities under a single umbrella.</div>
<p style="font-weight: bold">We are focused to conduct trade of new as well as used cars and bikes and everything that you look for being an automobile user & enthusiast...<br /><br />Click on the below LINK to complete your USER registration and �ENJOY� being part of US��<br /><br /><a href="' . site_url('welcome/
rdReSet') . '/' . $this->users->confirmkey . '/' . $this->input->post('userName') . '">Keralaonroad login</a></p>');
            $this->email->send();
            /* $this->email->from('info@keralaonroad.com', 'Admin');
              $this->email->to($username);
              $this->email->cc('info@keralaonroad.com');
              //$this->email->bcc('info@keralaonroad.com');
              $this->email->subject('Confirm your email registered in Keralaonroad.com');
              $this->email->message('Testing the email address Please press this key and confirm it please .' .
              base_url() . 'welcome/mail_confirm/' . $this->users->confirmkey);
              $this->email->send(); */
            $this->datas->data->email_message = $this->email->print_debugger();
            if ($this->db->affected_rows() > 0) {
                $userid = $this->db->insert_id();
                $this->datas->data->message = 'Successfully Registered';
                $this->datas->data->error = false;
                $this->datas->output();
            } else {
                $this->datas->data->message = 'something error occured';
                $this->datas->data->error = true;
                $this->datas->output();
            }
        }
    }

    public function login() {
        if (!isset($_POST['userName'])) {
            $this->datas->data->error = true;
            $this->datas->data->message = 'Please enter Your Username';
            $this->datas->output();
        }
        if (!filter_var($this->input->post('userName'), FILTER_VALIDATE_EMAIL)) {
            $type = 'name';
            $this->datas->data->error = true;
            $this->datas->data->message = 'Please enter a valid email like sample@keralaonroads.com ';
            $this->datas->output();
        }
        if (( strlen($this->input->post('userName')) <= 6 ) || ( strlen($this->input->post('userName')) >
                50 )) {
            $this->datas->data->error = true;
            $this->datas->data->message = 'not a valid email (6-50 charcters)';
            $this->datas->output();
        }
        if (!isset($_POST['pass'])) {
            $this->datas->data->error = true;
            $this->datas->data->message = 'Please enter your password';
            $this->datas->output();
        }
        if (strlen($this->input->post('pass')) < 5) {
            $this->datas->data->error = true;
            $this->datas->data->message = 'small pwd (>5 characters)';
            $this->datas->output();
        }
        if (( isset($_POST['userName']) ) && ( isset($_POST['pass']) )) {
            $password = $this->input->post('pass');
            $this->users->make_password($password);
            $password = $this->users->enc_password;
            $username = $this->input->post('userName');
            $user = $this->db->get_where('users', array('email' => $username, 'passwords' => $password));
            $count = $user->num_rows();
            if ($count == 1) {
                $row = $user->row();
                $id = $row->user_id;
                $username = $row->username;
                $status = $row->status;
                if ($status == 0) {
                    $this->datas->data->error = true;
                    $this->datas->data->message = 'Confirm your mail please ,Check your mail box';
                    $this->datas->output();
                } else {
                    if ($row->utype_id == 107) {
                        $this->datas->data->error = false;
                        $this->datas->data->message = 'You have successfully logged in';
                        $this->session->set_userdata("keralaonroads_admin", $id);
                        $this->session->set_userdata("keralaonroads", $id);
                        $this->session->set_userdata("keralaonroads_name", "Admin");
                        $sname = $this->session->userdata('keralaonroads_admin');
                        $this->datas->output();
                    } else {
                        $this->session->set_userdata("keralaonroads", $id);
                        $sname = $this->session->userdata('keralaonroads');
                        $this->datas->data->error = false;
                        $this->datas->data->message = 'You have successfully logged in';
                        $this->session->set_userdata("keralaonroads", $id);
                        $this->session->set_userdata("keralaonroads_name", $username);
                        $sname = $this->session->userdata('keralaonroads');
                        $this->datas->output();
                    }
                }
            } else {
                $this->datas->data->error = true;
                $this->datas->data->message = 'Please enter a valid username or password';
                $this->datas->output();
            }
        }
        $this->datas->output();
    }

    public function search() {
        if ($this->input->post('table') == 1) {
            if ($this->input->post('totalcheck') >= 1) {
                $i = 0;
                $checks = $this->input->post('check');
                $total = $this->input->post('totalcheck');
                $where = '';
                while ($i < $total) {
                    $where[] = $checks[$i];
                    $i++;
                }
                $this->db->where_in('model.cmp_id', $where);
            }
            if ($this->input->post('type') == 1 || $this->input->post('type') == 2) {
                $where = 'onroad_model.vtype_id =' . $this->input->post('type');
                $this->db->where($where);
            }
            if ($this->input->post('company') != '') {
                $where = 'model.cmp_id =' . $this->input->post('company');
                $this->db->where($where);
            }
            if ($this->input->post('searchinput') != '') {
                $array = "(`model_name` LIKE  '%" . $this->input->post('searchinput') . "%'OR  `companyname` LIKE  '%" . $this->input->post('searchinput') . "%')";
                $this->db->where($array);
            }
            if ($this->input->post('frominput') != '') {
                $from = $this->input->post('frominput');
            } else {
                $from = 0;
            }
            if ($this->input->post('toinput') != '') {
                $to = $this->input->post('toinput');
            } else {
                $to = 100000000000000;
            }
            if ($this->input->post('frominput') || $this->input->post('toinput')) {
                $where = 'price BETWEEN ' . $from . ' AND ' . $to;
                $this->db->where($where);
            }
            if ($this->input->post('fuel')) {
                $where = 'onroad_variant.fuel_type =' . $this->input->post('fuel');
                $this->db->where($where);
            }
            if ($this->input->post('body')) {
                $where = 'onroad_model.body_type =' . $this->input->post('body');
                $this->db->where($where);
            }
            if ($this->input->post('from') != '' && $this->input->post('to') != '') {
                $this->datas->data->from = ( $this->input->post('from') );
                $this->datas->data->to = ( $this->input->post('to') );
                $this->db->limit(( 10 + 1), $this->input->post('from'));
            } else {
                $this->datas->data->from = 0;
                $this->datas->data->to = 10;
                $this->db->limit(11, 0);
            }
            $i = 0;
            $this->db->select('model.model_id, variant.var_name, model.model_name, company.companyname, model_images.model_image');
            $this->db->order_by("model.model_id", "desc");
            $this->db->join('vehicle_type_global', 'vehicle_type_global.vtype_id = model.vtype_id', 'LEFT OUTER');
            $this->db->join('variant', 'variant.model_id = model.model_id', 'LEFT OUTER');
            $this->db->join('model_images', 'model.model_id = model_images.model_id', 'LEFT OUTER');
            $this->db->join('company', 'model.cmp_id = company.cmp_id', 'LEFT OUTER');
            $this->db->group_by("model.model_id");
            $this->db->where('company.status',1);
            $this->db->where_in('model.status', array(1, 2));
            $onroad_vehicle_detailsquery = $this->db->get('model');
            $this->db->last_query();
            if ($onroad_vehicle_detailsquery->num_rows() > 0) {
                foreach ($onroad_vehicle_detailsquery->result() as $rowonroad_vehicle_details) {
                    $i++;
                    $this->datas->data->id[$i] = $rowonroad_vehicle_details->model_id;
                    $this->datas->data->condition[$i] = 'new';
                    $this->datas->data->variant[$i] = $rowonroad_vehicle_details->var_name;
                    $this->datas->data->model[$i] = $rowonroad_vehicle_details->model_name;
                    $this->datas->data->company[$i] = $rowonroad_vehicle_details->companyname;
                    $this->datas->data->title[$i] = $rowonroad_vehicle_details->model_name;
                    $this->datas->data->year[$i] = 'New';
                    $this->datas->data->i = $i;
                    if ($rowonroad_vehicle_details->model_image !== '') {
                        $this->datas->data->image[$i] = str_replace('.', '_thumb.', $rowonroad_vehicle_details->model_image);
                    } else {
                        $this->datas->data->image[$i] = 'new.jpg';
                    }
                }
                $this->datas->data->get = 'viewnew';
            } else {
                $this->datas->data->i = $i;
            }
        } else if($this->input->post('table') == 2) {
            if($this->input->post('checkplace')){
                $this->db->where(array('district_id'=>$this->input->post('checkplace')));
            }
            /*if ($this->input->post('location') != '') {
                $this->db->where($array);
            }
             if ($this->input->post('totalcheckplace') >= 1) {
              $i = 0;
              $checks = $this->input->post('checkplace');
              $total = $this->input->post('totalcheckplace');
              $where = '(';
              while ($i < $total) {
              if ($i != 0) {
              $where = $where . ' or ';
              }
              $array = "(
              `onroad_vehicle_details`.`title_name` LIKE  '%" . $checks[$i] . "%'
              OR `onroad_vehicle_details`.`ownershipdetails` LIKE  '%" . $checks[$i] . "%'
              OR `onroad_vehicle_details`.`place_id` LIKE  '%" . $checks[$i] . "%'
              OR  `onroad_vehicle_details`.`discription` LIKE  '%" . $checks[$i] . "%'

              )";
              $where = $where . $array;
              $i++;
              }
              $where = $where . ')';
              $this->db->where($where);
              } */
            if ($this->input->post('totalcheck') >= 1) {
                $i = 0;
                $checks = $this->input->post('check');
                $total = $this->input->post('totalcheck');
                $where = '(';
                while ($i < $total) {
                    if ($i != 0) {
                        $where = $where . ' or ';
                    }
                    $where = $where . 'onroad_vehicle_details.cmp_id =' . $checks[$i];
                    $i++;
                }
                $where = $where . ')';
                $this->db->where($where);
            }
            if ($this->input->post('type') == 1 || $this->input->post('type') == 2) {
                $where = 'vehicle_details.vtype_id =' . $this->input->post('type');
                $this->db->where($where);
            }
            if ($this->input->post('company') != '') {
                $where = 'vehicle_details.cmp_id =' . $this->input->post('company');
                $this->db->where($where);
            }
            if ($this->input->post('searchinput') != '') {
                $array = "(
`onroad_vehicle_details`.`title_name` LIKE  '%" . $this->input->post('searchinput') .
                        "%'
OR  `var_name` LIKE  '%" . $this->input->post('searchinput') . "%'
OR  `model_name` LIKE  '%" . $this->input->post('searchinput') . "%'
OR  `companyname` LIKE  '%" . $this->input->post('searchinput') . "%'
OR  `discription` LIKE  '%" . $this->input->post('searchinput') . "%'
)";
                $this->db->where($array);
            }
            if ($this->input->post('frominput') != '') {
                $from = $this->input->post('frominput');
            } else {
                $from = 0;
            }
            if ($this->input->post('toinput') != '') {
                $to = $this->input->post('toinput');
            } else {
                $to = 100000000000000;
            }
            if ($this->input->post('frominput') || $this->input->post('toinput')) {
                $where = 'exp_prize BETWEEN ' . $from . ' AND ' . $to;
                $this->db->where($where);
            }
            if ($this->input->post('fromyear') != '') {
                $fromyear = $this->input->post('fromyear');
            } else {
                $fromyear = 1900;
            }
            if ($this->input->post('toyear') != '') {
                $toyear = $this->input->post('toyear');
            } else {
                $toyear = 2222;
            }
            if ($this->input->post('fromyear') || $this->input->post('toyear')) {
                $where = 'model_year BETWEEN ' . $fromyear . ' AND ' . $toyear;
                $this->db->where($where);
            }
            if ($this->input->post('body')) {
                $where = 'onroad_model.body_type =' . $this->input->post('body');
                $this->db->where($where);
            }
            if ($this->input->post('mileage')) {
                $where = 'millage <=' . $this->input->post('mileage');
                $this->db->where($where);
            }
            if ($this->input->post('fuel')) {
                $where = 'onroad_variant.fuel_type =' . $this->input->post('fuel');
                $this->db->where($where);
            }
            if ($this->input->post('from') != '' && $this->input->post('to') != '') {
                $this->datas->data->from = ( $this->input->post('from') );
                $this->datas->data->to = ( $this->input->post('to') );
                $this->db->limit(( 10 + 1), $this->input->post('from'));
            } else {
                $this->datas->data->from = 0;
                $this->datas->data->to = 10;
                $this->db->limit(11);
            }
            $i = 0;
            $this->db->select('*');
            $this->db->from('vehicle_details');
            $this->db->join('company', 'company.cmp_id = vehicle_details.cmp_id', 'LEFT OUTER JOIN');
            $this->db->join('model', 'model.model_id = vehicle_details.model_id', 'LEFT OUTER JOIN');
            $this->db->join('variant', 'variant.varient_id = vehicle_details.varient_id', 'LEFT OUTER JOIN');
            $this->db->join('vehicle_type_global', 'vehicle_type_global.vtype_id = vehicle_details.vtype_id', 'LEFT OUTER JOIN');
            $this->db->order_by("vehicle_details.pro_id", "desc");
            $onroad_vehicle_detailsquery = $this->db->get();
            $this->db->last_query();
            if ($onroad_vehicle_detailsquery->num_rows() > 0) {
                foreach ($onroad_vehicle_detailsquery->result() as $rowonroad_vehicle_details) {
                    $i++;
                    $this->datas->data->id[$i] = $rowonroad_vehicle_details->pro_id;
                    $this->datas->data->condition[$i] = 'used';
                    $this->datas->data->variant[$i] = $rowonroad_vehicle_details->var_name;
                    $this->datas->data->model[$i] = $rowonroad_vehicle_details->model_name;
                    $this->datas->data->company[$i] = $rowonroad_vehicle_details->companyname;
                    $this->datas->data->title[$i] = $rowonroad_vehicle_details->title_name;
                    $this->datas->data->year[$i] = $rowonroad_vehicle_details->model_year;
                    $this->datas->data->millage[$i] = $rowonroad_vehicle_details->millage;
                    $this->datas->data->kilo_meter[$i] = $rowonroad_vehicle_details->kilo_meter;
                    $this->datas->data->price[$i] = $rowonroad_vehicle_details->exp_prize;
                    $this->datas->data->i = $i;
                    $this->db->limit(1);
                    //$this->db->order_by("vimg_id", "desc");
                    $onroad_vehicle_imagesquery = $this->db->get_where('vehicle_images', array('pro_id' => $rowonroad_vehicle_details->pro_id));
                    if ($onroad_vehicle_imagesquery->num_rows() > 0) {
                        $image = explode('.', trim($onroad_vehicle_imagesquery->result()[0]->image));
                        $this->datas->data->image[$i] = $image[0] . '_thumb.' . $image[1];
                    } else {
                        $this->datas->data->image[$i] = 'new.jpg';
                    }
                }
                $this->datas->data->get = 'view';
            } else {
                $this->datas->data->i = $i;
            }
        }
        $this->datas->output();
    }

    public function getvehicletype() {
        $i = 0;
        $onroad_vehicle_type_globalquery = $this->db->get('vehicle_type_global');
        foreach ($onroad_vehicle_type_globalquery->result() as $rowonroad_vehicle_type_global) {
            $vtype_id = $rowonroad_vehicle_type_global->vtype_id;
            $i++;
            $this->datas->data->id[$i] = $vtype_id;
            $this->datas->data->content[$i] = $rowonroad_vehicle_type_global->typename;
        }
        $this->datas->data->i = $i;
        $this->datas->data->ids = 'vehicletype';
        $this->datas->data->error = false;
        $this->datas->output();
    }

    public function getcompany() {
        $i = 0;
        $this->db->order_by("companyname", "ASC");
        $onroad_companyquery = $this->db->get_where('company', array('type' => $this->input->post('value1')));
        foreach ($onroad_companyquery->result() as $rowonroad_company) {
            $cmp = $rowonroad_company->cmp_id;
            $i++;
            $this->datas->data->id[$i] = $cmp;
            $this->datas->data->content[$i] = $rowonroad_company->companyname;
            $image = explode('.', trim($rowonroad_company->image));
            $this->datas->data->image[$i] = $image[0] . '_thumb.' . $image[1];
            $this->datas->data->web[$i] = $rowonroad_company->web;
            $this->datas->data->loan[$i] = $rowonroad_company->loan;
            $this->datas->data->insu[$i] = $rowonroad_company->insurance;
            $this->datas->data->status[$i] = $rowonroad_company->status;
        }
        $this->datas->data->i = $i;
        $this->datas->data->ids = 'company';
        $this->datas->data->error = false;
        $this->datas->output();
    }

    public function getdealers() {
        $i = 0;
        if (( $this->input->post('value1') ) != 0) {
            $onroad_dealersquery = $this->db->get_where('dealer', array('company_id' => $this->input->post('value1'), 'type' => $this->input->post('value2')));
        } else {
            $onroad_dealersquery = $this->db->get_where('dealer', array('type' => $this->input->post('value2')));
        }
        foreach ($onroad_dealersquery->result() as $rowonroad_dealers) {
            $dealerId = $rowonroad_dealers->id;
            $i++;
            $this->datas->data->id[$i] = $dealerId;
            $this->datas->data->content[$i] = $rowonroad_dealers->name;
            $image = explode('.', trim($rowonroad_dealers->logo));
            $this->datas->data->image[$i] = $image[0] . '_thumb.' . $image[1];
            $this->datas->data->phone[$i] = $rowonroad_dealers->phnum;
            $this->datas->data->email[$i] = $rowonroad_dealers->email;
        }
        $this->datas->data->i = $i;
        $this->datas->data->ids = 'adtitle';
        $this->datas->data->error = false;
        $this->datas->output();
    }

    public function getBranches() {
        $i = 0;
        if (( $this->input->post('value1'))) {
            $delBranch = $this->db->get_where('dealer_branch', array('dealer_id' => $this->input->post('value1')));
            foreach ($delBranch->result() as $branch) {
                $i++;
                $this->datas->data->id[$i] = $branch->branch_id;
                $this->datas->data->content[$i] = $branch->name;
                $this->datas->data->add[$i] = $branch->address;
                $this->datas->data->map_iframe[$i] = $branch->map_iframe;
                $this->datas->data->ph1[$i] = $branch->ph1;
                $this->datas->data->email[$i] = $branch->email;
                $this->datas->data->sale_ph[$i] = $branch->sale_ph;
                $this->datas->data->ph2[$i] = $branch->ph2;
                $this->datas->data->sar_ph[$i] = $branch->sar_ph;
                $this->datas->data->sale_email[$i] = $branch->sale_email;
                $this->datas->data->sar_email[$i] = $branch->sar_email;
            }
        }
        $this->datas->data->i = $i;
        $this->datas->data->ids = 'branch';
        $this->datas->data->error = false;
        $this->datas->output();
    }

    public function getvariant() {
        if (isset($_POST['value1'])) {
            $i = 0;
            $onroad_variantquery = $this->db->get_where('variant', array('model_id' => $this->input->post('value1')));
            foreach ($onroad_variantquery->result() as $rowonroad_variant) {
                $varient_id = $rowonroad_variant->varient_id;
                $i++;
                $this->datas->data->id[$i] = $varient_id;
                $this->datas->data->content[$i] = $rowonroad_variant->var_name;
                $this->datas->data->about[$i] = $rowonroad_variant->about;
                $this->datas->data->brouchure[$i] = $rowonroad_variant->brochure;
                $this->datas->data->price[$i] = $rowonroad_variant->price;
                $this->datas->data->price_text[$i] = $rowonroad_variant->price_text;
                $this->datas->data->cc[$i] = $rowonroad_variant->cubicc;
                $this->datas->data->sc[$i] = $rowonroad_variant->seatingc;
                $this->datas->data->fuel[$i] = $rowonroad_variant->fuel_type;
                $this->datas->data->status[$i] = $rowonroad_variant->status;
            }
            $this->datas->data->i = $i;
            $this->datas->data->ids = 'variant';
            $this->datas->data->error = false;
            $this->datas->output();
        }
    }

    public function getbarand() {
        foreach ($onroad_brandquery->result() as $rowonroad_brand) {
            $cmp = $rowonroad_brand->cmp_id + 111;
            $brand = $rowonroad_brand->brand_id + 111;
            echo '<option cmp="' . $cmp . '" value="' . $brand . '">	' . $rowonroad_brand->brand_name .
            '	</option>';
        }
    }

    public function getfeatureslist() {
        $i = 0;
        $this->db->join('feaur', 'feaur_vehicle.feachur_id = feaur.feachur_id', 'LEFT OUTER');
        $query = $this->db->get_where('feaur_vehicle', array('verient_id' => $this->input->post
                    ('value1'), 'patent !=' => 0));
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $i++;
                $this->datas->data->id[$i] = $row->feachur_id;
                $this->datas->data->content[$i] = $row->feachur;
                $this->datas->data->value[$i] = $row->value;
            }
        }
        $this->datas->data->i = $i;
        $this->datas->data->idType = 'liList';
        $this->datas->data->ids = 'featuresul';
        $this->datas->data->error = false;
        $this->datas->output();
    }

    public function getspeclist() {
        $i = 0;
        $this->db->join('specification', 'specification_vehicle.spec_id = specification.spec_id', 'LEFT OUTER');
        $query = $this->db->get_where('specification_vehicle', array('verient_id' => $this->input->post
                    ('value1'), 'patent !=' => 0));
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $i++;
                $this->datas->data->id[$i] = $row->spec_id;
                $this->datas->data->content[$i] = $row->specification;
                $this->datas->data->value[$i] = $row->value;
            }
        }
        $this->datas->data->i = $i;
        $this->datas->data->idType = 'liList';
        $this->datas->data->ids = 'specul';
        $this->datas->data->error = false;
        $this->datas->output();
    }

    public function getdetaillist() {
        $i = 0;
        $this->db->select("deatils_vehicle.deatil_id, value, deatil");
        $this->db->join('deatils', 'deatils_vehicle.deatil_id = deatils.deatil_id', 'LEFT OUTER');
        $query = $this->db->get_where('deatils_vehicle', array('verient_id' => $this->input->post
                    ('value1')));
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $i++;
                $this->datas->data->id[$i] = $row->deatil_id;
                $this->datas->data->content[$i] = $row->deatil;
                $this->datas->data->value[$i] = $row->value;
            }
        }
        $this->datas->data->i = $i;
        $this->datas->data->idType = 'liList';
        $this->datas->data->ids = 'deatil';
        $this->datas->data->error = false;
        $this->datas->output();
    }

    public function getcolorslist() {
        $i = 0;
        $query = $this->db->get_where('color_new_vehicle', array('model_id' => $this->input->post
                    ('value1')));
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $i++;
                $this->datas->data->id[$i] = $row->ci_id;
                $this->datas->data->content[$i] = $row->colorname;
                $this->datas->data->image[$i] = str_replace('.', '_thumb.', $row->colorimage);
            }
        }
        $this->datas->data->i = $i;
        $this->datas->data->ids = 'colorslist';
        $this->datas->data->error = false;
        $this->datas->output();
    }

    public function getmodelImgs() {
        $i = 0;
        $query = $this->db->get_where('model_images', array('model_id' => $this->input->post('value1')));
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $i++;
                $this->datas->data->id[$i] = $row->img_id;
                $this->datas->data->image[$i] = str_replace('.', '_thumb.', $row->model_image);
            }
        }
        $this->datas->data->i = $i;
        $this->datas->data->idType = "image";
        $this->datas->data->ids = 'veImgList';
        $this->datas->data->error = false;
        $this->datas->output();
    }

    public function getcolorcodelist() {
        $i = 0;
        $query = $this->db->get_where('color_new_vehicle', array('verient_id' => $this->input->post
                    ('value1')));
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $i++;
                $this->datas->data->id[$i] = $row->ci_id;
                $this->datas->data->content[$i] = $row->colorcode;
            }
        }
        $this->datas->data->i = $i;
        $this->datas->data->ids = 'colorcodelist';
        $this->datas->data->error = false;
        $this->datas->output();
    }

    public function viewdealers() {
        if ($this->input->post('id') != '') {
            $query = $this->db->get_where('place', array('placename' => $this->input->post('id')));
            if ($query->num_rows() > 0) {
                $row = $query->first_row();
                $place_id = $row->place_id;
                $this->db->where('district_id', $place_id);
            }
        }
        if ($this->input->post('condition') != '') {
            switch ($this->input->post('condition')) {
                case 'used': {
                        $this->db->where('dealer.type', 3);
                        break;
                    }
                case 'new': {
                        $names = array('4', '8');
                        $this->db->where_in('dealer.type', $names);
                        if ($this->input->post('vehicle') != '') {
                            switch ($this->input->post('vehicle')) {
                                case 'car': {
                                        $this->db->where('vtype', 2);
                                        break;
                                    }
                                case 'bike': {
                                        $this->db->where('vtype', 1);
                                        break;
                                    }
                            }
                        }
                        break;
                    }
            }
        }
        $i = 0;
        $this->db->select('branch_id,id,logo,ph1,address,dealer_branch.name,dealer.name as dealername');
        $this->db->join('dealer_branch', 'dealer_branch.dealer_id = dealer.id', 'LEFT OUTER');
        $query = $this->db->get_where('dealer', array('dealer.status' => 1,
            'dealer_branch.status' => 1));
        $this->db->last_query();
        foreach ($query->result() as $row) {
            $i++;
            $this->datas->data->dealername[$i] = $row->dealername;
            $this->datas->data->brid[$i] = $row->branch_id;
            $this->datas->data->id[$i] = $row->id;
            $this->datas->data->img[$i] = $row->logo;
            $this->datas->data->number[$i] = $row->ph1;
            $this->datas->data->address[$i] = $row->address;
            $this->datas->data->name[$i] = $row->name;
        }
        $this->datas->data->i = $i;
        $this->datas->data->ids = 'viewdealers';
        $this->datas->data->error = false;
        $this->datas->output();
    }

    public function getmodel() {
        $i = 0;
        $onroad_modelquery = $this->db->get_where('model', array('cmp_id' => $this->input->post
                    ('value1')));
        foreach ($onroad_modelquery->result() as $rowonroad_model) {
            $model = $rowonroad_model->model_id;
            $i++;
            $this->datas->data->id[$i] = $model;
            $this->datas->data->content[$i] = $rowonroad_model->model_name;
            $this->datas->data->start[$i] = $rowonroad_model->start_year;
            $this->datas->data->end[$i] = $rowonroad_model->end_year;
            $this->datas->data->body[$i] = $rowonroad_model->body_type;
            $this->datas->data->brochure[$i] = $rowonroad_model->brochure;
            $this->datas->data->about[$i] = $rowonroad_model->about_model;
            $this->datas->data->status[$i] = $rowonroad_model->status;
        }
        $this->datas->data->i = $i;
        $this->datas->data->ids = 'model';
        $this->datas->data->error = false;
        $this->datas->output();
    }

    public function getbody() {
        $i = 0;
        $onroad_modelquery = $this->db->get_where('body_type', array('vtype_id' => $this->input->post
                    ('value1')));
        foreach ($onroad_modelquery->result() as $rowonroad_model) {
            $v_id = $rowonroad_model->v_id;
            $i++;
            $this->datas->data->id[$i] = $v_id;
            $this->datas->data->content[$i] = $rowonroad_model->vehicle_type;
        }
        $this->datas->data->i = $i;
        $this->datas->data->ids = 'bodytype';
        $this->datas->data->error = false;
        $this->datas->output();
    }

    public function getfuel() {
        $i = 0;
        $onroad_modelquery = $this->db->get('fueltype');
        foreach ($onroad_modelquery->result() as $rowonroad_model) {
            $fl_id = $rowonroad_model->fl_id;
            $i++;
            $this->datas->data->id[$i] = $fl_id;
            $this->datas->data->content[$i] = $rowonroad_model->fueltypename;
        }
        $this->datas->data->i = $i;
        $this->datas->data->ids = 'fueltype';
        $this->datas->data->error = false;
        $this->datas->output();
    }

    public function addvehicletype() {
        
    }

    public function addcompany() {
        $query = $this->db->get_where('company', array('cmp_id' => $this->input->post('id')));
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data = array(
                    'companyname' => $this->input->post('value2'),
                    'web' => $this->input->post('value7'),
                    'status' => $this->input->post('comStatus'),
                    'type' => $this->input->post('value3'));
                $this->db->update('company', $data, array('cmp_id' => $this->input->post('id')));
                $this->datas->data->message = "ok";
                $this->datas->data->process = 'up';
                $this->datas->data->id = $this->input->post('id');
                $this->datas->data->error = false;
                $this->datas->data->append = $this->input->post('value1');
                $this->datas->data->content = $this->input->post('value2');
                $this->datas->output();
            }
        } else {
            $array = array(
                'companyname' => $this->input->post('value2'),
                'web' => $this->input->post('value7'),
                'status' => $this->input->post('comStatus'),
                'type' => $this->input->post('value3'));
            $this->db->insert('company', $array);
            $this->datas->data->message = "ok";
            $this->datas->data->process = 'add';
            $this->datas->data->id = $this->db->insert_id();
            $this->datas->data->error = false;
            $this->datas->data->append = $this->input->post('value1');
            $this->datas->data->content = $this->input->post('value2');
            $this->datas->output();
        }
    }

    public function deletedetails() {
        $query = $this->db->get_where('variant', array('varient_id' => $this->input->post('value6')));
        if ($query->num_rows() > 0) {
            $data = array('verient_id' => $this->input->post('value6'), 'deatil_id' => $this->input->post
                        ('value13'));
            $query = $this->db->get_where('deatils_vehicle', $data);
            if ($query->num_rows() > 0) {
                $query = $this->db->delete('deatils_vehicle', $data);
                $this->datas->data->message = "deleted";
                $this->datas->data->error = false;
                $this->datas->output();
            } else {
                $this->datas->data->error = true;
                $this->datas->data->message = "don't repeat it";
                $this->datas->output();
            }
        } else {
            $this->datas->data->error = true;
            $this->datas->data->message = "don't repeat it";
            $this->datas->output();
        }
    }

    public function deletefeature() {
        $query = $this->db->get_where('variant', array('varient_id' => $this->input->post('value6')));
        if ($query->num_rows() > 0) {
            $data = array('verient_id' => $this->input->post('value6'), 'feachur_id' => $this->input->post
                        ('value11'));
            $query = $this->db->get_where('feaur_vehicle', $data);
            if ($query->num_rows() > 0) {
                $query = $this->db->delete('feaur_vehicle', $data);
                $this->datas->data->message = "deleted";
                $this->datas->data->error = false;
                $this->datas->output();
            } else {
                $this->datas->data->error = true;
                $this->datas->data->message = "don't repeat it";
                $this->datas->output();
            }
        } else {
            $this->datas->data->error = true;
            $this->datas->data->message = "don't repeat it";
            $this->datas->output();
        }
    }

    public function addfeatureslist() {
        $query = $this->db->get_where('variant', array('varient_id' => $this->input->post('value6')));
        if ($query->num_rows() > 0) {
            $where = $data = array('verient_id' => $this->input->post('value6'), 'feachur_id' => $this->input->post
                        ('value11'));
            $query = $this->db->get_where('feaur_vehicle', $data);
            if ($query->num_rows() > 0) {
                $data = array(
                    'verient_id' => $this->input->post('value6'),
                    'feachur_id' => $this->input->post('value11'),
                    'value' => $this->input->post('value13'));
                $this->db->update('feaur_vehicle', $data, $where);
                $this->datas->data->message = "updated";
                $this->datas->data->error = false;
                $this->datas->output();
            } else {
                $data = array(
                    'verient_id' => $this->input->post('value6'),
                    'feachur_id' => $this->input->post('value11'),
                    'value' => $this->input->post('value13'));
                $this->db->insert('feaur_vehicle', $data);
                $this->datas->data->message = "ok";
                $this->datas->data->process = 'add';
                $this->datas->data->id = $this->input->post('value1');
                $this->datas->data->error = false;
                $this->datas->data->append = 'alert';
                $this->datas->data->content = 'Added';
                $this->datas->output();
            }
        } else {
            $this->datas->data->error = true;
            $this->datas->data->message = "don't repeat it";
            $this->datas->output();
        }
    }

    public function deletespec() {
        $query = $this->db->get_where('variant', array('varient_id' => $this->input->post('value6')));
        if ($query->num_rows() > 0) {
            $data = array('verient_id' => $this->input->post('value6'), 'spec_id' => $this->input->post
                        ('value12'));
            $query = $this->db->get_where('specification_vehicle', $data);
            if ($query->num_rows() > 0) {
                $query = $this->db->delete('specification_vehicle', $data);
                $this->datas->data->message = "deleted";
                $this->datas->data->error = false;
                $this->datas->output();
            } else {
                $this->datas->data->error = true;
                $this->datas->data->message = "don't repeat it";
                $this->datas->output();
            }
        } else {
            $this->datas->data->error = true;
            $this->datas->data->message = "don't repeat it";
            $this->datas->output();
        }
    }

    public function addspeclist() {
        $query = $this->db->get_where('variant', array('varient_id' => $this->input->post('value6')));
        if ($query->num_rows() > 0) {
            $data = array('verient_id' => $this->input->post('value6'), 'spec_id' => $this->input->post
                        ('value12'));
            $query = $this->db->get_where('specification_vehicle', $data);
            if ($query->num_rows() > 0) {
                $this->datas->data->message = "already added";
                $this->datas->data->error = false;
                $this->datas->output();
            } else {
                $data = array(
                    'verient_id' => $this->input->post('value6'),
                    'spec_id' => $this->input->post('value12'),
                    'value' => $this->input->post('value14'));
                $this->db->insert('specification_vehicle', $data);
                $this->datas->data->message = "ok";
                $this->datas->data->process = 'add';
                $this->datas->data->id = $this->input->post('value1');
                $this->datas->data->error = false;
                $this->datas->data->append = 'specsul';
                $this->datas->data->content = 'spec added';
                $this->datas->output();
            }
        } else {
            $this->datas->data->error = true;
            $this->datas->data->message = "don't repeat it";
            $this->datas->output();
        }
    }

    public function adddeatilslist() {
        $query = $this->db->get_where('variant', array('varient_id' => $this->input->post('value6')));
        if ($query->num_rows() > 0) {
            $data = array('verient_id' => $this->input->post('value6'), 'deatil_id' => $this->input->post
                        ('value15'));
            $query = $this->db->get_where('deatils_vehicle', $data);
            if ($query->num_rows() > 0) {
                $this->datas->data->message = "already added";
                $this->datas->data->error = false;
                $this->datas->output();
            } else {
                $data = array(
                    'verient_id' => $this->input->post('value6'),
                    'deatil_id' => $this->input->post('value15'),
                    'value' => $this->input->post('value16'));
                $this->db->insert('deatils_vehicle', $data);
                $this->datas->data->message = "ok";
                $this->datas->data->process = 'add';
                $this->datas->data->id = $this->input->post('value1');
                $this->datas->data->error = false;
                $this->datas->data->append = 'deatil';
                $this->datas->data->content = 'dec added';
                $this->datas->output();
            }
        } else {
            $this->datas->data->error = true;
            $this->datas->data->message = "don't repeat it";
            $this->datas->output();
        }
    }

    public function addvariant() {
        if (isset($_POST['variantsname'], $_POST['model'])) {
            $brouchure = '#';
            if ($this->input->post('file') != '') {
                if (isset($_FILES)) {
                    $config['upload_path'] = './assets/files/';
                    $config['allowed_types'] = 'pdf|doc|docs|txt';
                    $config['max_size'] = '306420';
                    $config['file_name'] = 'keralaOnRoad_' . $this->input->post('model');
                    $this->load->library('upload', $config);
                    if (!$this->upload->do_upload('0')) {
                        $error = array('error' => $this->upload->display_errors());
                        $this->datas->data->message = $this->upload->display_errors();
                        $this->datas->data->errora = $error;
                        $this->datas->data->error = true;
                        $this->datas->output();
                    } else {
                        $data = array('upload_data' => $this->upload->data());
                        $brouchure = $data['upload_data']['file_name'];
                        $this->datas->data->message = "Added Successfuly";
                        $this->datas->data->process = 'add';
                        $this->datas->data->error = false;
                        $this->datas->data->message = "updated successfully";
                        $this->datas->data->error = false;
                    }
                }
            }
            $query = $this->db->get_where('variant', array('varient_id' => $this->input->post('variant')));
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $row) {
                    $data = array(
                        'var_name' => $this->input->post('variantsname'),
                        'vtype_id' => $this->input->post('type'),
                        'model_id' => $this->input->post('model'),
                        'fuel_type' => $this->input->post('fuel'),
                        'brochure' => $brouchure,
                        'price' => $this->input->post('price'),
                        'price_text' => $this->input->post('priceText'),
                        'cubicc' => $this->input->post('cubicc'),
                        'seatingc' => $this->input->post('seatingc'),
                        'status' => $this->input->post('variantstatus'),
                        'about' => $this->input->post('about'));
                    $this->db->update('variant', $data, array('varient_id' => $this->input->post('variant')));
                    $this->datas->data->message = "ok";
                    $this->datas->data->process = 'up';
                    $this->datas->data->id = $this->input->post('variant');
                    $this->datas->data->error = false;
                    $this->datas->data->append = $this->input->post('variant');
                    $this->datas->data->content = $this->input->post('variant');
                    $this->datas->output();
                }
            } else {
                $array = array(
                    'var_name' => $this->input->post('variantsname'),
                    'vtype_id' => $this->input->post('type'),
                    'model_id' => $this->input->post('model'),
                    'fuel_type' => $this->input->post('fuel'),
                    'brochure' => $brouchure,
                    'price' => $this->input->post('price'),
                    'price_text' => $this->input->post('priceText'),
                    'cubicc' => $this->input->post('cubicc'),
                    'seatingc' => $this->input->post('seatingc'),
                    'status' => $this->input->post('variantstatus'),
                    'about' => $this->input->post('about'));
                $this->db->insert('variant', $array);
                $this->datas->data->message = "ok";
                $this->datas->data->process = 'add';
                $this->datas->data->id = $this->db->insert_id();
                $this->datas->data->error = false;
                $this->datas->data->append = $this->input->post('variant');
                $this->datas->data->content = $this->input->post('variant');
                $this->datas->output();
            }
        }
    }

    public function addmodel() {
        if (isset($_POST['modelname'])) {
            $brouchure = '#';
            if ($this->input->post('file') != '') {
                if (isset($_FILES)) {
                    $config['upload_path'] = './assets/files/';
                    $config['allowed_types'] = 'pdf|doc|docs|txt';
                    $config['max_size'] = '306420';
                    $config['file_name'] = 'keralaOnRoad_' . $this->input->post('model');
                    $this->load->library('upload', $config);
                    if (!$this->upload->do_upload('0')) {
                        $error = array('error' => $this->upload->display_errors());
                        $this->datas->data->message = $this->upload->display_errors();
                        $this->datas->data->errora = $error;
                        $this->datas->data->error = true;
                        $this->datas->output();
                    } else {
                        $data = array('upload_data' => $this->upload->data());
                        $brouchure = $data['upload_data']['file_name'];
                        $this->datas->data->message = "Added Successfuly";
                        $this->datas->data->process = 'add';
                        $this->datas->data->error = false;
                        $this->datas->data->message = "updated successfully";
                        $this->datas->data->error = false;
                    }
                }
            }
            $query = $this->db->get_where('model', array('model_id' => $this->input->post('model')));
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $row) {
                    $data = array(
                        'model_name' => $this->input->post('modelname'),
                        'vtype_id' => $this->input->post('type'),
                        'cmp_id' => $this->input->post('company'),
                        'start_year' => $this->input->post('fromyear'),
                        'end_year' => $this->input->post('toyear'),
                        'brochure' => $brouchure,
                        'body_type' => $this->input->post('bodytype'),
                        'status' => $this->input->post('modelstatus'),
                        'about_model' => $this->input->post('about')
                    );
                    $oldBrouch = $row->brochure;
                    if ((!empty($oldBrouch)) && $oldBrouch != "#") {
                        delete_files(base_url() . "assets/files/$oldBrouch");
                        unlink("assets/files/$oldBrouch");
                    }
                    $this->db->update('model', $data, array('model_id' => $this->input->post('model')));
                    $this->datas->data->message = "ok";
                    $this->datas->data->process = 'up';
                    $this->datas->data->id = $this->input->post('model');
                    $this->datas->data->error = false;
                    $this->datas->data->append = $this->input->post('modelname');
                    $this->datas->data->content = $this->input->post('modelname');
                    $this->datas->output();
                }
            } else {
                $array = array(
                    'model_name' => $this->input->post('modelname'),
                    'vtype_id' => $this->input->post('type'),
                    'cmp_id' => $this->input->post('company'),
                    'start_year' => $this->input->post('fromyear'),
                    'end_year' => $this->input->post('toyear'),
                    'brochure' => $brouchure,
                    'body_type' => $this->input->post('bodytype'),
                    'status' => $this->input->post('modelstatus'),
                    'about_model' => $this->input->post('about'));
                $this->db->insert('model', $array);
                $this->datas->data->message = "ok";
                $this->datas->data->process = 'add';
                $this->datas->data->id = $this->db->insert_id();
                $this->datas->data->error = false;
                $this->datas->data->append = $this->input->post('modelname');
                $this->datas->data->content = $this->input->post('modelname');
                $this->datas->output();
            }
        }
        $this->datas->output();
    }

    public function addadtitle() {
        $image = 'default.jpg';
        $type = ( ( $this->input->post('condition') ) * $this->input->post('type') );
        if ($this->input->post('condition') == 1) {
            $type = 3;
        }
        $array = array('id' => $this->input->post('id'), 'type' => $type);
        $query = $this->db->get_where('dealer', $array);
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $this->datas->data->id = $row->id;
                $image = $row->logo;
            }
            $this->datas->data->process = 'up';
            $data = array(
                'name' => $this->input->post('dealer'),
                'email' => $this->input->post('dealeremail'),
                'phnum' => $this->input->post('dealernumber'),
                'updated_at' => date("Y-m-d H:i:s"));
            $this->db->update('dealer', $data, $array);
        } else {
            $array = array(
                'name' => $this->input->post('dealer'),
                'logo' => $image,
                'vtype' => $this->input->post('type'),
                'type' => $type,
                'company_id' => $this->input->post('company'),
                'email' => $this->input->post('dealeremail'),
                'phnum' => $this->input->post('dealernumber'),
                'inserted_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"));
            $this->db->insert('dealer', $array);
            $this->datas->data->message = "ok";
            $this->datas->data->process = 'add';
            $this->datas->data->id = $this->db->insert_id();
        }
        $image = explode('.', trim($image));
        $this->datas->data->image = $image[0] . '_thumb.' . $image[1];
        $this->datas->data->error = false;
        $this->datas->data->append = 'adtitle';
        $this->datas->data->content = $this->input->post('dealer');
        $this->datas->output();
    }

    public function addvehicle() {
        if ($this->session->userdata('keralaonroads') == false) {
            redirect(base_url() . 'welcome/login', 'refresh');
            header('location:' . base_url() . 'welcome/login');
            echo 'Sorry Sir Please Login or Register';
        }
        $sname = $this->session->userdata('keralaonroads');
        if (!isset($_POST['adtitle'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'adtitle';
            $this->datas->data->error = true;
            $this->datas->output();
        } else
        if (!preg_match("/^[a-zA-Z0-9 ]+$/", $this->input->post('adtitle'))) {
            $this->datas->data->message = "Its not valid title (A-Z a-z 0-9 and space only allowed)";
            $this->datas->data->id = 'adtitle';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['company'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'company';
            $this->datas->data->error = true;
            $this->datas->output();
        } else
        if ((!preg_match("/^[0-9]+$/", $this->input->post('company')) ) || ( $this->input->post
                        ('company') == 0 )) {
            $this->datas->data->message = "Please select a valid company Name";
            $this->datas->data->id = 'company';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['model'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'model';
            $this->datas->data->error = true;
            $this->datas->output();
        } else
        if ((!preg_match("/^[0-9]+$/", $this->input->post('model')) ) || ( $this->input->post
                        ('model') == 0 )) {
            $this->datas->data->message = "Please select a valid model Name";
            $this->datas->data->id = 'model';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['variant'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'variant';
            $this->datas->data->error = true;
            $this->datas->output();
        } else
        if ((!preg_match("/^[0-9]+$/", $this->input->post('variant')) ) || ( $this->input->post
                        ('variant') == 0 )) {
            $this->datas->data->message = "Please select a valid variant Name";
            $this->datas->data->id = 'variant';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['year'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'year';
            $this->datas->data->error = true;
            $this->datas->output();
        } else
        if ((!preg_match("/^[0-9]+$/", $this->input->post('year')) ) || ( $this->input->post
                        ('year') == 0 )) {
            $this->datas->data->message = "Please select a valid year";
            $this->datas->data->id = 'year';
            $this->datas->data->error = true;
            $this->datas->output();
        }

        if (!isset($_POST['condition'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'condition';
            $this->datas->data->error = true;
            $this->datas->output();
        } else
        if ((!preg_match("/^[0-9]+$/", $this->input->post('condition')) ) || ( $this->input->post
                        ('condition') == 0 )) {
            $this->datas->data->message = "Please select a valid condition";
            $this->datas->data->id = 'condition';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['color'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'color';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['vehicletype'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'vehicletype';
            $this->datas->data->error = true;
            $this->datas->output();
        } else
        if ((!preg_match("/^[0-9]+$/", $this->input->post('vehicletype')) ) || ( $this->input->post
                        ('vehicletype') == 0 )) {
            $this->datas->data->message = "Please select a valid vehicle type Name";
            $this->datas->data->id = 'vehicletype';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['Odometer'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'Odometer';
            $this->datas->data->error = true;
            $this->datas->output();
        } else
        if ((!preg_match("/^[0-9]+$/", $this->input->post('Odometer')) ) || ( $this->input->post
                        ('Odometer') < 1 )) {
            $this->datas->data->message = "Please enter a valid Odometer value";
            $this->datas->data->id = 'Odometer';
            $this->datas->data->error = true;
            $this->datas->output();
        }

        if (!isset($_POST['textarea'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'textarea';
            $this->datas->data->error = true;
            $this->datas->output();
        } else
        if (( strlen($this->input->post('textarea')) > 150 ) || ( strlen($this->input->post
                                ('textarea')) <= 5 )) {
            $this->datas->data->message = "Please enter description 5-150 charcters only";
            $this->datas->data->id = 'textarea';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['inr'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'inr';
            $this->datas->data->error = true;
            $this->datas->output();
        } else
        if ((!preg_match("/^[0-9]+$/", $this->input->post('inr')))) {
            $this->datas->data->message = "Please sslect a valid INR value";
            $this->datas->data->id = 'price';
            $this->datas->data->error = true;
            $this->datas->output();
        }


        if (!isset($_POST['register'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'register';
            $this->datas->data->error = true;
            $this->datas->output();
        } else
        if ((!preg_match("/^[a-zA-Z0-9 -]+$/", $this->input->post('register')))) {
            $this->datas->data->message = "Please enter a valid register Number";
            $this->datas->data->id = 'register';
            $this->datas->data->error = true;
            $this->datas->output();
        }

        if (!isset($_POST['price'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'price';
            $this->datas->data->error = true;
            $this->datas->output();
        } else
        if ((!preg_match("/^[0-9]+$/", $this->input->post('price')) ) || ( $this->input->post
                        ('price') == 0 )) {
            $this->datas->data->message = "Please sslect a valid price value";
            $this->datas->data->id = 'price';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['place'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'place';
            $this->datas->data->error = true;
            $this->datas->output();
        } else
        if (!preg_match("/^[a-zA-Z ]+$/", $this->input->post('place'))) {
            $this->datas->data->message = "Its not valid place name (A-Z a-z and space only allowed)";
            $this->datas->data->id = 'place';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['vehicleauth'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'vehicleauth';
            $this->datas->data->error = true;
            $this->datas->output();
        } else
        if (( strlen($this->input->post('vehicleauth')) > 150 ) || ( strlen($this->input->post
                                ('vehicleauth')) <= 5 )) {
            $this->datas->data->message = "Please enter vehicle details 5-150 charcters only";
            $this->datas->data->id = 'vehicleauth';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['number'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'number';
            $this->datas->data->error = true;
            $this->datas->output();
        } else
        if ((!preg_match("/^[0-9]+$/", $this->input->post('number')) || ( strlen($this->input->post('number')) > 12 ) || ( strlen($this->input->post('number')) <= 9 ))) {
            $this->datas->data->message = "Please sslect a valid contact number";
            $this->datas->data->id = 'number';
            $this->datas->data->error = true;
            $this->datas->output();
        }


        if (!isset($_POST['inscomp'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'inscomp';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['tmission'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'tmission';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['ftype'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'ftype';
            $this->datas->data->error = true;
            $this->datas->output();
        }


        $this->db->insert('vehicle_details', array(
            'title_name' => $this->input->post('adtitle'),
            'user_id' => $sname,
            'brand_id' => ( $this->input->post('brandname') ),
            'model_id' => ( $this->input->post('model') ),
            'varient_id' => ( $this->input->post('variant') ),
            'district_id' => ( $this->input->post('district') ),
            'v_id' => ( $this->input->post('cartype') ),
            'cmp_id' => ( $this->input->post('company') ),
            'con_id' => ( $this->input->post('condition') ),
            'model_year' => $this->input->post('year'),
            'kilo_meter' => $this->input->post('Odometer'),
            'color_id' => $this->input->post('color'),
            'tr_id' => ( $this->input->post('Transmission') ),
            'millage' => $this->input->post('Mileage'),
            'exp_prize' => $this->input->post('inr'),
            'pr_id' => ( $this->input->post('price') ),
            'reg_no' => $this->input->post('register'),
            'place_id' => ( $this->input->post('place') ),
            'discription' => $this->input->post('textarea'),
            'vtype_id' => ( $this->input->post('vehicletype') ),
            'uptype_id' => ( $this->input->post('uptype') ),
            'ownershipdetails' => $this->input->post('vehicleauth'),
            'contact_number' => $this->input->post('number'),
            'sdate' => $this->input->post('sdate'),
            'edate' => $this->input->post('edate'),
            'idv' => $this->input->post('idv'),
            'transmission' => $this->input->post('tmission'),
            'ftype' => $this->input->post('ftype'),
            'land_no' => $this->input->post('lnumber'),
            'insurance_comp' => $this->input->post('inscomp'),
            'status' => 1));
        $this->datas->data->message = "Saved";
        $this->datas->data->id = ( $this->db->insert_id() ) + 1111;
        $this->datas->data->error = false;
        $this->datas->output();
    }

    public function addnew() {
        if ($this->session->userdata('keralaonroads_admin') == false) {
            redirect(base_url() . 'welcome/login', 'refresh');
            header('location:' . base_url() . 'welcome/login');
            echo 'Sorry Sir Please Login or Register';
        }
        $sname = $this->session->userdata('keralaonroads_admin');
        if (!isset($_POST['adtitle'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'adtitle';
            $this->datas->data->error = true;
            $this->datas->output();
        } else
        if (!preg_match("/^[a-zA-Z0-9 ]+$/", $this->input->post('adtitle'))) {
            $this->datas->data->message = "Its not valid title (A-Z a-z 0-9 and space only allowed)";
            $this->datas->data->id = 'adtitle';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['company'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'company';
            $this->datas->data->error = true;
            $this->datas->output();
        } else
        if ((!preg_match("/^[0-9]+$/", $this->input->post('company')) ) || ( $this->input->post
                        ('company') == 0 )) {
            $this->datas->data->message = "Please select a valid company Name";
            $this->datas->data->id = 'company';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['model'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'model';
            $this->datas->data->error = true;
            $this->datas->output();
        } else
        if ((!preg_match("/^[0-9]+$/", $this->input->post('model')) ) || ( $this->input->post
                        ('model') == 0 )) {
            $this->datas->data->message = "Please select a valid model Name";
            $this->datas->data->id = 'model';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['variant'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'variant';
            $this->datas->data->error = true;
            $this->datas->output();
        } else
        if ((!preg_match("/^[0-9]+$/", $this->input->post('variant')) ) || ( $this->input->post
                        ('variant') == 0 )) {
            $this->datas->data->message = "Please select a valid variant Name";
            $this->datas->data->id = 'variant';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['color'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'color';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['textarea'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'textarea';
            $this->datas->data->error = true;
            $this->datas->output();
        } else
        if (( strlen($this->input->post('textarea')) > 150 ) || ( strlen($this->input->post
                                ('textarea')) <= 5 )) {
            $this->datas->data->message = "Please enter description 5-150 charcters only";
            $this->datas->data->id = 'textarea';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['inr'])) {
            $this->datas->data->message = "This field is required";
            $this->datas->data->id = 'inr';
            $this->datas->data->error = true;
            $this->datas->output();
        } else
        if ((!preg_match("/^[0-9]+$/", $this->input->post('inr')))) {
            $this->datas->data->message = "Please sslect a valid INR value";
            $this->datas->data->id = 'price';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        $this->db->insert('new_vehicle', array(
            'tittle' => $this->input->post('adtitle'),
            'model_id' => ( $this->input->post('model') ),
            'veriant_id' => ( $this->input->post('variant') ),
            'company_id' => ( $this->input->post('company') ),
            'color_availables' => $this->input->post('color'),
            'price' => $this->input->post('inr'),
            'discription' => $this->input->post('textarea'),
            'created_at' => date("Y-m-d H:i:s"),
            'updated_at' => date("Y-m-d H:i:s"),
            'status' => 0));
        $this->datas->data->message = "Saved";
        $this->datas->data->id = ( $this->db->insert_id() ) + 1111;
        $this->datas->data->error = false;
        $this->datas->output();
    }

    public function add_dealer() {

        if (!isset($_POST['dealer_id'])) {
            $this->datas->data->message = "Dealer Selection is required";
            $this->datas->data->id = 'adtitle';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if ((!preg_match("/^[0-9]+$/", $this->input->post('dealer_id')) ) || ( $this->input->post('dealer_id') == 0 )) {
            $this->datas->data->message = "Please Select Valid option";
            $this->datas->data->id = 'adtitle';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['brtitle'])) {
            $this->datas->data->message = "Branch Tittle field is required";
            $this->datas->data->id = 'brtitle';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['district'])) {
            $this->datas->data->message = "District field is required";
            $this->datas->data->id = 'district';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['district']) || $this->input->post('district') == 0) {
            $this->datas->data->message = "District field is required";
            $this->datas->data->id = 'district';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['address'])) {
            $this->datas->data->message = "Address field is required";
            $this->datas->data->id = 'textarea';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (strlen($this->input->post('address')) <= 5) {
            $this->datas->data->message = "Please enter address with mnore than 5 charcters";
            $this->datas->data->id = 'address';
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST['email'])) {
            $this->datas->data->message = 'Please enter your email';
            $this->datas->data->error = true;
            $this->datas->data->id = 'email';
            $this->datas->output();
        }
        if (!filter_var($this->input->post('email'), FILTER_VALIDATE_EMAIL)) {
            $this->datas->data->message = 'Enter a valid email address like "example@mail.com"';
            $this->datas->data->error = true;
            $this->datas->data->id = 'email';
            $this->datas->output();
        }
        if (( strlen($this->input->post('email')) <= 6 ) || ( strlen($this->input->post('email')) >
                50 )) {
            $this->datas->data->message = 'Enter a valid email address use 7-50 charcters';
            $this->datas->data->error = true;
            $this->datas->data->id = 'email';
            $this->datas->output();
        }
        if (!empty($_POST['salesEmail'])) {
            if (!isset($_POST['salesEmail'])) {
                $this->datas->data->message = 'Please enter Sales email';
                $this->datas->data->error = true;
                $this->datas->data->id = 'salesEmail';
                $this->datas->output();
            }
            if (!filter_var($this->input->post('salesEmail'), FILTER_VALIDATE_EMAIL)) {
                $this->datas->data->message = 'Enter a valid email address like "example@mail.com"';
                $this->datas->data->error = true;
                $this->datas->data->id = 'salesEmail';
                $this->datas->output();
            }
            if (( strlen($this->input->post('salesEmail')) <= 6 ) || ( strlen($this->input->post('salesEmail')) >
                    50 )) {
                $this->datas->data->message = 'Enter a valid email address use 7-50 charcters';
                $this->datas->data->error = true;
                $this->datas->data->id = 'salesEmail';
                $this->datas->output();
            }
        }
        if (!empty($_POST['serEmail'])) {
            if (!isset($_POST['serEmail'])) {
                $this->datas->data->message = 'Please enter Service email';
                $this->datas->data->error = true;
                $this->datas->data->id = 'salesEmail';
                $this->datas->output();
            }
            if (!filter_var($this->input->post('serEmail'), FILTER_VALIDATE_EMAIL)) {
                $this->datas->data->message = 'Enter a valid email address like "example@mail.com"';
                $this->datas->data->error = true;
                $this->datas->data->id = 'serEmail';
                $this->datas->output();
            }
            if (( strlen($this->input->post('serEmail')) <= 6 ) || ( strlen($this->input->post('serEmail')) >
                    50 )) {
                $this->datas->data->message = 'Enter a valid email address use 7-50 charcters';
                $this->datas->data->error = true;
                $this->datas->data->id = 'serEmail';
                $this->datas->output();
            }
        }
        if ($_POST['branch_id'] == -1) {
            $this->db->insert('dealer_branch', array(
                'dealer_id' => $this->input->post('dealer_id'),
                'name' => $this->input->post('brtitle'),
                'district_id' => $this->input->post('district'),
                'town_id' => $this->input->post('town'),
                'map_iframe' => $this->input->post('map_iframe'),
                'address' => $this->input->post('address'),
                'sale_ph' => $this->input->post('salesPh'),
                'sale_email' => $this->input->post('salesEmail'),
                'sar_ph' => $this->input->post('serPh'),
                'sar_email' => $this->input->post('serEmail'),
                'email' => $this->input->post('email'),
                'ph1' => $this->input->post('phone1'),
                'ph2' => $this->input->post('phone2'),
                'rec_number' => $this->input->post('rec_number')
            ));
            $this->datas->data->message = "Saved" . $this->db->insert_id();
            $this->datas->data->id = $this->db->insert_id();
            $this->datas->data->error = false;
            $this->datas->output();
        }
        if ($_POST['branch_id'] > 0) {
            $this->db->update('dealer_branch', array(
                'dealer_id' => $this->input->post('dealer_id'),
                'name' => $this->input->post('brtitle'),
                'map_iframe' => $this->input->post('map_iframe'),
                'address' => $this->input->post('address'),
                'sale_ph' => $this->input->post('salesPh'),
                'sale_email' => $this->input->post('salesEmail'),
                'sar_ph' => $this->input->post('serPh'),
                'sar_email' => $this->input->post('serEmail'),
                'email' => $this->input->post('email'),
                'ph1' => $this->input->post('phone1'),
                'ph2' => $this->input->post('phone2'),
                'rec_number' => $this->input->post('rec_number')
                    ), array('branch_id' => $this->input->post('branch_id')));
            $this->datas->data->message = "Updated";
            $this->datas->data->id = $this->input->post('branch_id');
            $this->datas->data->error = false;
            $this->datas->output();
        } else {
            $this->datas->data->message = "Error";
            $this->datas->data->id = $this->input->post('branch_id');
            $this->datas->data->error = false;
            $this->datas->output();
        }
    }

    public function getfeatures() {
        $query = $this->db->get("feaur");
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $this->datas->data->content[$row->feachur_id] = $row->feachur;
            }
        }
        $this->datas->data->error = false;
        $this->datas->data->alert = "Successfully fetched";
        $this->datas->exit();
    }

    public function addfeatures() {
        if ($this->input->post('value6') == 0) {
            $this->datas->data->message = "Please enter variant";
            $this->datas->data->append = "alert";
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST["vehicle_feature"])) {
            $this->datas->data->message = "Please enter vehicle feature";
            $this->datas->data->append = "alert";
            $this->datas->data->error = true;
            $this->datas->output();
        }
        $parent = 0;
        $description = $this->input->post("newfeaturedis");
        if (isset($_POST["newfeaturedis"])) {
            $description = $this->input->post("newfeaturedis");
            if (( strlen($description) < 5 ) || ( strlen($this->input->post("description")) >
                    700 )) {
                $this->datas->data->message = "Please enter description use 5 -700 characters";
                $this->datas->data->append = "alert";
                $this->datas->data->error = true;
                $this->datas->output();
            }
        }
        $parent = $this->input->post("parentof");
        $query = $this->db->get_where('feaur', array('feachur' => $this->input->post("vehicle_feature"), 'patent' => $parent));
        if ($query->num_rows() > 0) {
            $where = array('feachur' => $this->input->post("vehicle_feature"));
            $inputs = array('description' => $description, 'patent' => $parent);
            $this->db->update("feaur", $inputs, $where);
            $this->datas->data->content = $this->input->post("vehicle_feature");
            $this->datas->data->error = false;
            $this->datas->data->process = 'up';
            $this->datas->data->append = 'featuresul';
            $this->datas->data->message = "Successfully Updated";
            $this->datas->output();
        } else {
            $inputs = array(
                'feachur' => $this->input->post("vehicle_feature"),
                'description' => $description,
                'patent' => $parent);
            $this->db->insert("feaur", $inputs);
            $this->datas->data->process = 'add';
            $this->datas->data->content = $this->input->post("vehicle_feature");
            $this->datas->data->append = 'featuresul';
            $this->datas->data->error = false;
            $this->datas->data->message = "Successfully added";
            $this->datas->output();
        }
    }

    public function addspecifications() {
        if ($this->input->post('value6') == 0) {
            $this->datas->data->message = "Please enter variant";
            $this->datas->data->append = "alert";
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST["newspecadd"])) {
            $this->datas->data->message = "Please enter vehicle specification";
            $this->datas->data->append = "alert";
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (isset($_POST["newspecadd"])) {
            if (( strlen($this->input->post("newspecadd")) < 3 ) || ( strlen($this->input->post("newspecadd")) > 70 )) {
                $this->datas->data->message = "Please enter vehicle specification use 6 -70 characters";
                $this->datas->data->append = "alert";
                $this->datas->data->error = true;
                $this->datas->output();
            }
        }
        $parent = 0;
        $description = $this->input->post("newspecadd");
        if ($this->input->post('parentofspec') != 0) {
            $parent = $this->input->post("parentofspec");
        }
        $query = $this->db->get_where('specification', array('specification' => $this->input->post("newspecadd"), 'patent' => $parent));
        if ($query->num_rows() > 0) {
            $where = array('specification' => $this->input->post("newspecadd"));
            $inputs = array('description' => $description, 'patent' => $parent);
            $this->db->update("specification", $inputs, $where);
            $this->datas->data->content = $this->input->post("newspecadd");
            $this->datas->data->error = false;
            $this->datas->data->process = 'up';
            $this->datas->data->append = 'specul';
            $this->datas->data->message = "Successfully Updated";
            $this->datas->output();
        } else {
            $inputs = array(
                'specification' => $this->input->post("newspecadd"),
                'description' => $description,
                'patent' => $parent);
            $this->db->insert("specification", $inputs);
            $this->datas->data->process = 'add';
            $this->datas->data->content = $this->input->post("newspecadd");
            $this->datas->data->append = 'specul';
            $this->datas->data->error = false;
            $this->datas->data->message = "Successfully added";
            $this->datas->output();
        }
    }

    public function adddeatils() {
        if ($this->input->post('value6') == 0) {
            $this->datas->data->message = "Please enter variant";
            $this->datas->data->append = "alert";
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST["newdeatiladd"])) {
            $this->datas->data->message = "Please enter vehicle deatils";
            $this->datas->data->append = "alert";
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (isset($_POST["newdeatiladd"])) {
            if (( strlen($this->input->post("newdeatiladd")) < 3 ) || ( strlen($this->input->post
                                    ("newdeatiladd")) > 70 )) {
                $this->datas->data->message = "Please enter vehicle specification use 6 -70 characters";
                $this->datas->data->append = "alert";
                $this->datas->data->error = true;
                $this->datas->output();
            }
        }
        $query = $this->db->get_where('deatils', array('deatil' => $this->input->post("newdeatiladd")));
        if ($query->num_rows() > 0) {
            $where = array('deatil' => $this->input->post("newdeatiladd"));
            $inputs = array('description' => $this->input->post("deatildisc"));
            $this->db->update("deatils", $inputs, $where);
            $this->datas->data->content = $this->input->post("newdeatiladd");
            $this->datas->data->error = false;
            $this->datas->data->process = 'up';
            $this->datas->data->append = 'deatilsul';
            $this->datas->data->message = "Successfully Updated";
            $this->datas->output();
        } else {
            $inputs = array('deatil' => $this->input->post("newdeatiladd"), 'description' => $this->input->post
                        ("deatildisc"));
            $this->db->insert("deatils", $inputs);
            $this->datas->data->process = 'add';
            $this->datas->data->content = $this->input->post("newspecadd");
            $this->datas->data->append = 'deatilsul';
            $this->datas->data->error = false;
            $this->datas->data->message = "Successfully added";
            $this->datas->output();
        }
    }

    public function uploaddealerlogo() {
        $type = (($this->input->post('condition') ) * $this->input->post('type'));
        /* if (isset($_FILES)) {
          $config['upload_path'] = './assets/images/dealers/';
          $config['allowed_types'] = 'gif|jpg|png|jpeg';
          $config['max_size'] = '8048';
          $company = str_replace('-', ' ', $this->input->post('dealer'));
          $config['file_name'] = $company;
          $this->load->library('upload', $config);
          if (!$this->upload->do_upload('0')) {
          $error = array('error' => $this->upload->display_errors());
          $this->datas->data->message = "Please try again something error occured";
          $this->datas->data->errora = $error;
          $this->datas->data->error = true;
          $this->datas->output();
          } else {
          $data = array('upload_data' => $this->upload->data());
          if ($data['upload_data']['is_image'] != 1) {
          $this->datas->data->message = "Please upload an image";
          $this->datas->data->error = true;
          $this->datas->output();
          } else {
          $config['image_library'] = 'gd2';
          $config['source_image'] = $data['upload_data']['full_path'];
          $config['new_image'] = $data['upload_data']['file_path'] . "/thumb/";
          $config['create_thumb'] = true;
          $config['width'] = 350;
          $config['height'] = '1';
          $config['maintain_ratio'] = true;
          $config['master_dim'] = 'width';
          $this->load->library('image_lib', $config);
          if (!$this->image_lib->resize()) {
          $this->datas->data->message = "Sorry Unable to make thumb image ,Please Try again";
          $this->datas->data->error = true;
          $this->datas->output();
          } else {
          if($_POST['id']==-1){
          $array = array(
          'name' => $this->input->post('dealer'),
          'logo' => $data['upload_data']['file_name'],
          'vtype' => $this->input->post('type'),
          'type' => $type,
          'company_id' => isset($_POST['company'])?$this->input->post('company'):0,
          'email' => $this->input->post('dealeremail'),
          'phnum' => $this->input->post('dealernumber'),
          'inserted_at' => date("Y-m-d H:i:s"),
          'updated_at' => date("Y-m-d H:i:s"));
          $image = $data['upload_data']['file_name'];
          $this->db->insert('dealer', $array);
          $this->datas->data->message = "ok";
          $this->datas->data->process = 'add';
          $this->datas->data->id = $this->db->insert_id();
          }
          else if($_POST['id']>0){
          $array = array(
          'name' => $this->input->post('dealer'),
          'logo' => $data['upload_data']['file_name'],
          'vtype' => $this->input->post('type'),
          'type' => $type,
          'company_id' =>  isset($_POST['company'])?$this->input->post('company'):0,
          'email' => $this->input->post('dealeremail'),
          'phnum' => $this->input->post('dealernumber'),
          'updated_at' => date("Y-m-d H:i:s"));
          $image = $data['upload_data']['file_name'];
          $this->db->update('dealer', $array, array('id'=>$this->input->post('id')));

          $image = explode('.', trim($image));
          $this->datas->data->image = $image[0] . '_thumb.' . $image[1];
          $this->datas->data->error = false;
          $this->datas->data->append = 'adtitle';
          $this->datas->data->content = $this->input->post('dealer');
          $this->datas->output();
          $this->datas->data->message = "uploaded successfully";
          $this->datas->data->error = false;
          $this->datas->output();
          }
          }
          }
          }
          }

          else { */
        $image = 'default.jpg';
        if ($_POST['id'] == -1) {
            $array = array(
                'name' => $this->input->post('dealer'),
                'logo' => $image,
                'vtype' => $this->input->post('type'),
                'type' => $type,
                'company_id' => isset($_POST['company']) ? $this->input->post('company') : 0,
                'email' => $this->input->post('dealeremail'),
                'phnum' => $this->input->post('dealernumber'),
                'inserted_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"));
            $this->db->insert('dealer', $array);
            $this->datas->data->message = "ok";
            $this->datas->data->process = 'add';
            $this->datas->data->id = $this->db->insert_id();
            $this->datas->data->error = false;
            $this->datas->output();
        } else if ($_POST['id'] > 0) {
            $array = array(
                'name' => $this->input->post('dealer'),
                'vtype' => $this->input->post('type'),
                'type' => $type,
                'company_id' => isset($_POST['company']) ? $this->input->post('company') : 0,
                'email' => $this->input->post('dealeremail'),
                'phnum' => $this->input->post('dealernumber'),
                'updated_at' => date("Y-m-d H:i:s"));
            $this->db->update('dealer', $array, array('id' => $this->input->post('id')));
            $this->datas->data->message = "ok";
            $this->datas->data->process = 'Updated Successfully';
            $this->datas->data->id = $this->input->post('id');
            $this->datas->data->error = false;
            $this->datas->output();
        } else {
            $this->datas->data->message = "Select details";
            $this->datas->data->process = 'Not updated';
            $this->datas->data->error = true;
            $this->datas->output();
        }

        //}
        $this->datas->data->message = "ok";
        $this->datas->data->process = 'Updated Successfully';
        $this->datas->data->id = $this->input->post('id');
        $this->datas->data->error = false;
        $this->datas->output();
    }

    public function upload() {
        if (isset($_FILES)) {
            $config['upload_path'] = './assets/images/companies/';
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
            $config['max_size'] = '8048';
            $company = str_replace('-', ' ', $this->input->post('company'));
            $config['file_name'] = $company;
            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('0')) {
                $error = array('error' => $this->upload->display_errors());
                $this->datas->data->message = "Please try again something error occured";
                $this->datas->data->errora = $error;
                $this->datas->data->error = true;
                $this->datas->output();
            } else {
                $data = array('upload_data' => $this->upload->data());
                if ($data['upload_data']['is_image'] != 1) {
                    $this->datas->data->message = "Please upload an image";
                    $this->datas->data->error = true;
                    $this->datas->output();
                } else {
                    $config['image_library'] = 'gd2';
                    $config['source_image'] = $data['upload_data']['full_path'];
                    $config['new_image'] = $data['upload_data']['file_path'] . "/thumb/";
                    $config['create_thumb'] = true;
                    $config['width'] = 350;
                    $config['height'] = '1';
                    $config['maintain_ratio'] = true;
                    $config['master_dim'] = 'width';
                    $this->load->library('image_lib', $config);
                    if (!$this->image_lib->resize()) {
                        $this->datas->data->message = "Sorry Unable to make thumb image ,Please Try again";
                        $this->datas->data->error = true;
                        $this->datas->output();
                    } else {
                        $image = 'default_thumb.jpg';
                        $array = array('cmp_id' => $this->input->post('id'), 'type' => $this->input->post('type'));
                        $query = $this->db->get_where('company', $array);
                        $array1 = array('companyname' => $this->input->post('company'), 'type' => $this->input->post('type'));
                        $query1 = $this->db->get_where('company', $array1);
                        if ($query->num_rows() > 0) {
                            foreach ($query->result() as $row) {
                                $this->datas->data->id = $row->cmp_id;
                                $imagName = $row->image;
                            }
                            $image = $data['upload_data']['file_name'];
                            $this->datas->data->process = 'up';
                            $data = array(
                                'companyname' => $this->input->post('company'),
                                'image' => $data['upload_data']['file_name'],
                                'status' => $this->input->post('status'),
                                'web' => $this->input->post('web'));
                            $this->db->update('company', $data, $array);
                            if ((!empty($imagName)) && $imagName != "default_thumb.jpg") {
                                delete_files(IMAGES_PATH . "companies/$imagName");
                                unlink("assets/images/companies/$imagName");
                                $imagName = strrev(implode(strrev("_thumb."), explode(".", strrev($imagName), 2)));
                                delete_files(IMAGES_PATH . "companies/thumbs/$imagName");
                                unlink("assets/images/companies/thumb/$imagName");
                            }
                        } else
                        if ($query1->num_rows() > 0) {
                            foreach ($query1->result() as $row1) {
                                $this->datas->data->id = $row1->cmp_id;
                                $imagName = $row->image;
                            }
                            $image = $data['upload_data']['file_name'];
                            $this->datas->data->process = 'up';
                            $data1 = array('web' => $this->input->post('web'), 'status' => $this->input->post('status'), 'image' => $data['upload_data']['file_name']);
                            $this->db->update('company', $data1, $array1);
                            if ((!empty($imagName)) && $imagName != "default_thumb.jpg") {
                                delete_files(IMAGES_PATH . "companies/$imagName");
                                unlink("assets/images/companies/$imagName");
                                $imagName = strrev(implode(strrev("_thumb."), explode(".", strrev($imagName), 2)));
                                delete_files(IMAGES_PATH . "companies/thumbs/$imagName");
                                unlink("assets/images/companies/thumb/$imagName");
                            }
                        } else {
                            $array = array(
                                'companyname' => $this->input->post('company'),
                                'web' => $this->input->post('web'),
                                'image' => $data['upload_data']['file_name'],
                                'status' => $this->input->post('status'),
                                'type' => $this->input->post('type'));

                            $image = $data['upload_data']['file_name'];
                            $this->db->insert('company', $array);
                            $this->datas->data->message = "ok";
                            $this->datas->data->process = 'add';
                            $this->datas->data->id = $this->db->insert_id();
                        }
                        $image = explode('.', trim($image));
                        $this->datas->data->image = $image[0] . '_thumb.' . $image[1];
                        $this->datas->data->error = false;
                        $this->datas->data->append = 'company';
                        $this->datas->data->content = $this->input->post('company');
                        $this->datas->output();
                        $this->datas->data->message = "uploaded successfully";
                        $this->datas->data->error = false;
                        $this->datas->output();
                    }
                }
            }
        } else {
            $image = 'default_thumb.jpg';
            $array = array('cmp_id' => $this->input->post('id'));
            $query = $this->db->get_where('company', $array);
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $row) {
                    $this->datas->data->id = $row->cmp_id;
                    $image = $row->image;
                }
                $this->datas->data->process = 'up';
                $data = array('companyname' => $this->input->post('company'), 'status' => $this->input->post('status'), 'web' => $this->input->post('web'));
                $this->db->update('company', $data, $array);
            } else {
                $array = array(
                    'companyname' => $this->input->post('company'),
                    'image' => $image,
                    'web' => $this->input->post('web'),
                    'status' => $this->input->post('status'),
                    'type' => $this->input->post('type'));
                $this->db->insert('company', $array);
                $this->datas->data->message = "ok";
                $this->datas->data->process = 'add';
                $this->datas->data->id = $this->db->insert_id();
            }
            $image = explode('.', trim($image));
            $this->datas->data->image = $image[0] . '_thumb.' . $image[1];
            $this->datas->data->error = false;
            $this->datas->data->append = 'company';
            $this->datas->data->content = $this->input->post('company');
            $this->datas->output();
            $this->datas->data->message = "uploaded successfully";
            $this->datas->data->error = false;
            $this->datas->output();
        }
        $this->datas->output();
    }

    public function uploadvehicleimages() {
        if (( $this->input->post('model') != '')) {
            if (isset($_FILES)) {
                $config['upload_path'] = './assets/images/newvehicles/';
                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                $config['max_size'] = '8048';
                $config['file_name'] = 'keralaOnRoad_' . $this->input->post('model');
                $this->load->library('upload', $config);
                if (!$this->upload->do_upload('0')) {
                    $error = array('error' => $this->upload->display_errors());
                    $this->datas->data->message = $this->upload->display_errors();
                    $this->datas->data->errora = $error;
                    $this->datas->data->error = true;
                    $this->datas->output();
                } else {
                    $data = array('upload_data' => $this->upload->data());
                    $model_id = $this->input->post('model');
                    if ($data['upload_data']['is_image'] != 1) {
                        $this->datas->data->message = "Please upload an image";
                        $this->datas->data->error = true;
                        $this->datas->output();
                    } else if ($model_id > 0) {
                        $config['image_library'] = 'gd2';
                        $config['source_image'] = $data['upload_data']['full_path'];
                        $config['new_image'] = $data['upload_data']['file_path'] . "/thumbs/";
                        $config['create_thumb'] = true;
                        $config['width'] = 350;
                        $config['height'] = '1';
                        $config['maintain_ratio'] = true;
                        $config['master_dim'] = 'width';
                        $this->load->library('image_lib', $config);
                        if (!$this->image_lib->resize()) {
                            $this->datas->data->message = "Sorry Unable to make thumb image ,Please Try again";
                            $this->datas->data->error = true;
                            $this->datas->output();
                        } else {
                            $array = array(
                                'model_id' => $model_id,
                                'model_image' => $data['upload_data']['file_name'],
                                'status' => 1);
                            $image = $data['upload_data']['file_name'];
                            $this->db->insert('model_images', $array);
                            $this->datas->data->message = "Added Successfuly";
                            $this->datas->data->process = 'add';
                            $this->datas->data->id = $this->db->insert_id();
                            $image = explode('.', trim($image));
                            $this->datas->data->image = $image[0] . '_thumb.' . $image[1];
                            $this->datas->data->error = false;
                            $this->datas->data->message = "updated successfully";
                            $this->datas->data->error = false;
                            $this->datas->output();
                        }
                    } else {
                        $this->datas->data->message = "Model Information error";
                        $this->datas->data->error = true;
                        $this->datas->output();
                    }
                }
            } else {
                $this->datas->data->message = "Please enter image";
                $this->datas->data->error = true;
                $this->datas->output();
            }
        } else {
            $this->datas->data->message = "Please Filll Out";
            $this->datas->data->error = true;
            $this->datas->output();
        }
        $this->datas->output();
    }

    public function addcolors() {
        if (( $this->input->post('colors') != '' ) && ( $this->input->post('model') != '' )) {
            if ($this->input->post('image') != '') {
                if (isset($_FILES)) {
                    $config['upload_path'] = './assets/images/newvehicles/';
                    $config['allowed_types'] = 'gif|jpg|png|jpeg';
                    $config['max_size'] = '8048';
                    $config['file_name'] = 'keralaOnRoad_' . $this->input->post('model');
                    $this->load->library('upload', $config);
                    if (!$this->upload->do_upload('0')) {
                        $error = array('error' => $this->upload->display_errors());
                        $this->datas->data->message = $this->upload->display_errors();
                        $this->datas->data->errora = $error;
                        $this->datas->data->error = true;
                        $this->datas->output();
                    } else {
                        $data = array('upload_data' => $this->upload->data());
                        if ($data['upload_data']['is_image'] != 1) {
                            $this->datas->data->message = "Please upload an image";
                            $this->datas->data->error = true;
                            $this->datas->output();
                        } else {
                            $config['image_library'] = 'gd2';
                            $config['source_image'] = $data['upload_data']['full_path'];
                            $config['new_image'] = $data['upload_data']['file_path'] . "/thumbs/";
                            $config['create_thumb'] = true;
                            $config['width'] = 350;
                            $config['height'] = '1';
                            $config['maintain_ratio'] = true;
                            $config['master_dim'] = 'width';
                            $this->load->library('image_lib', $config);
                            if (!$this->image_lib->resize()) {
                                $this->datas->data->message = "Sorry Unable to make thumb image ,Please Try again";
                                $this->datas->data->error = true;
                                $this->datas->output();
                            } else {
                                $image = 'default_thumb.jpg';
                                $array = array('colorname' => $this->input->post('colors'), 'model_id' => $this->input->post
                                            ('model'));
                                $query = $this->db->get_where('color_new_vehicle', $array);
                                $array1 = array('colorcode' => $this->input->post('colorcode'), 'model_id' => $this->input->post
                                            ('model'));
                                $query1 = $this->db->get_where('color_new_vehicle', $array1);
                                if ($query->num_rows() > 0) {
                                    foreach ($query->result() as $row) {
                                        $this->datas->data->id = $row->ci_id;
                                    }
                                    $image = $data['upload_data']['file_name'];
                                    $this->datas->data->process = 'up';
                                    $data = array(
                                        'status' => $this->input->post('statuscolor'),
                                        'colorcode' => $this->input->post('colorcode'),
                                        'colorimage' => $data['upload_data']['file_name']);
                                    $this->db->update('color_new_vehicle', $data, $array);
                                } else
                                if ($query1->num_rows() > 0) {
                                    foreach ($query1->result() as $row1) {
                                        $this->datas->data->id = $row1->ci_id;
                                    }
                                    $image = $data['upload_data']['file_name'];
                                    $this->datas->data->process = 'up';
                                    $data1 = array(
                                        'status' => $this->input->post('statuscolor'),
                                        'colorname' => $this->input->post('colors'),
                                        'colorimage' => $data['upload_data']['file_name']);
                                    $this->db->update('color_new_vehicle', $data1, $array1);
                                } else {
                                    $array = array(
                                        'colorname' => $this->input->post('colors'),
                                        'colorimage' => $data['upload_data']['file_name'],
                                        'colorcode' => $this->input->post('colorcode'),
                                        'model_id' => $this->input->post('model'),
                                        'status' => $this->input->post('statuscolor'));
                                    $image = $data['upload_data']['file_name'];
                                    $this->db->insert('color_new_vehicle', $array);
                                    $this->datas->data->message = "Added Successfuly";
                                    $this->datas->data->process = 'add';
                                    $this->datas->data->id = $this->db->insert_id();
                                    $this->datas->output();
                                }
                                $image = explode('.', trim($image));
                                $this->datas->data->image = $image[0] . '_thumb.' . $image[1];
                                $this->datas->data->error = false;
                                $this->datas->data->message = "updated successfully";
                                $this->datas->data->error = false;
                                $this->datas->output();
                            }
                        }
                    }
                }
            } else {
                $array = array('colorname' => $this->input->post('colors'), 'model_id' => $this->input->post
                            ('model'));
                $query = $this->db->get_where('color_new_vehicle', $array);
                $array1 = array('colorcode' => $this->input->post('colorcode'), 'model_id' => $this->input->post
                            ('model'));
                $query1 = $this->db->get_where('color_new_vehicle', $array1);
                if ($query->num_rows() > 0) {
                    foreach ($query->result() as $row) {
                        $this->datas->data->id = $row->ci_id;
                    }
                    $this->datas->data->process = 'up';
                    $data = array('status' => $this->input->post('statuscolor'), 'colorcode' => $this->input->post
                                ('colorcode'));
                    $this->db->update('color_new_vehicle', $data, $array);
                } else
                if ($query1->num_rows() > 0) {
                    foreach ($query1->result() as $row1) {
                        $this->datas->data->id = $row1->ci_id;
                    }
                    $this->datas->data->process = 'up';
                    $data1 = array(
                        'status' => $this->input->post('statuscolor'),
                        'colorname' => $this->input->post('colors'),
                    );
                    $this->db->update('color_new_vehicle', $data1, $array1);
                } else {
                    $array = array(
                        'colorname' => $this->input->post('colors'),
                        'colorcode' => $this->input->post('colorcode'),
                        'model_id' => $this->input->post('model'),
                        'status' => $this->input->post('statuscolor'));
                    $this->db->insert('color_new_vehicle', $array);
                    $this->datas->data->message = "Added Successfuly";
                    $this->datas->data->process = 'add';
                    $this->datas->data->id = $this->db->insert_id();
                    $this->datas->output();
                }
                $this->datas->data->error = false;
                $this->datas->data->message = "updated successfully";
                $this->datas->data->error = false;
                $this->datas->output();
            }
        } else {
            $this->datas->data->message = "Please Filll Out";
            $this->datas->data->error = true;
            $this->datas->output();
        }
        $this->datas->output();
    }

    public function changestatus() {
        if (isset($_POST["product_id"])) {
            if (( strlen($this->input->post("product_id")) < 0 ) || ( strlen($this->input->post
                                    ("product_id")) > 20 )) {
                $this->datas->data->message = "Please enter product id use 0 -20 characters";
                $this->datas->data->append = "product_id";
                $this->datas->data->error = true;
                $this->datas->output();
            }
        }
        if (!preg_match("/^[0-9]+$/", $this->input->post("product_id"))) {
            $this->datas->data->message = "Please enter  product id use 0-9 Only";
            $this->datas->data->append = "product_id";
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (!isset($_POST["approve"])) {
            $this->datas->data->message = "Please enter approve";
            $this->datas->data->append = "approve";
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if (isset($_POST["approve"])) {
            if (( strlen($this->input->post("approve")) < 1 ) || ( strlen($this->input->post("approve")) >
                    1 )) {
                $this->datas->data->message = "Please enter approve use 1 -1 characters";
                $this->datas->data->append = "approve";
                $this->datas->data->error = true;
                $this->datas->output();
            }
        }
        if (!preg_match("/^[0-9]+$/", $this->input->post("approve"))) {
            $this->datas->data->message = "Please enter  approve use 0-9 Only";
            $this->datas->data->append = "approve";
            $this->datas->data->error = true;
            $this->datas->output();
        }
        if ($this->input->post('type') === 2) {
            $where = array('pro_id' => $this->input->post("product_id"));
            $inputs = array('status' => $this->input->post("approve"));
            $this->db->update("vehicle_details", $inputs, $where);
            $this->datas->data->error = false;
            $this->datas->data->alert = "Successfully Changed";
            $this->datas->output();
        }
        if ($this->input->post('type') === 1) {
            $where = array('vehicle_id' => $this->input->post("product_id"));
            $inputs = array('status' => $this->input->post("approve"));
            $this->db->update("new_vehicle", $inputs, $where);
            $this->datas->data->error = false;
            $this->datas->data->alert = "Successfully Updated";
            $this->datas->output();
        }
    }

    public function users() {
        $userType = (int) $this->input->post('value1');
        if ($userType) {
            $this->db->limit(50);
            $this->db->from('users');
            $this->db->where('utype_id = ' . $userType);
            $query = $this->db->get();
            $this->datas->data = $query->result();
            $this->datas->output();
        } elseif ($this->input->post('value1') === "delapp") {
            $this->db->join('users', 'users.email=dealer.email');
            $query = $this->db->get_where('dealer');
            $this->datas->data->main = $query->result();
            $this->db->join('users', 'users.email=dealer_branch.email');
            $query = $this->db->get_where('dealer_branch');
            $this->datas->data->branch = $query->result();
            $this->datas->output();
        } else {
            $this->db->limit(50);
            $this->db->from('users');
            $this->db->where('utype_id = 2');
            $query = $this->db->get();
            $this->datas->data = $query->result();
            $this->datas->output();
        }
    }

    public function forgotpassword() {
        $user = $this->input->post('userName');
        $query = $this->db->get_where('users', array('email' => $user));
        $data[] = $query->result();
        if (empty($data)) {
            $this->datas->data = $user;
            $this->datas->output();
        } else if (count($data[0]) == 1) {
            $this->load->helper('security');
            $str = $user . time();
            $str = do_hash($str); // SHA1
            $str = do_hash($str, 'md5'); // MD5
            $datas = array('ipaddress' => $this->input->ip_address(), 'keys' => $str);
            $this->db->update('users', $datas, array('user_id' => $data[0][0]->user_id));
            $this->load->library('email');
            $config = Array(
                'protocol' => 'smtp',
                'smtp_host' => 'vps.tricetechnologies.in',
                'smtp_port' => 587,
                'smtp_user' => 'development@keralaonroad.com',
                'smtp_pass' => '_C^(4^6L=P^r',
                'mailtype' => 'html',
                'charset' => 'iso-8859-1'
            );
            $this->email->initialize($config);
            $this->email->from('development@keralaonroad.com', 'Support');
            $this->email->to($user);
            $this->email->cc('noreplay@keralaonroad.com');
            $this->email->subject('Welcome TO keralaonroad.com');
            $this->email->message('<div style="color: #f00;font-weight: bold;"><h2>WELCOME TO KERALA ON ROAD</h2><br /><a href="http://www.keralaonroad.com/"  style="color: #f00;font-weight: bold">www.keralaonroad.com</a><br />India�s N0.1 Automobile sellers, buyers, retailers, manufacturers and all related entities under a single umbrella.</div>
<p style="font-weight: bold">We are focused to conduct trade of new as well as used cars and bikes and everything that you look for being an automobile user & enthusiast...<br /><br />Click on the below LINK to complete your password reset  and �ENJOY� being part of US��<br /><br /><a href="' . site_url('welcome/passwordReSet') . "/" . $str . "?email=" . $user . '">Keralaonroad Reset password</a></p>');

            $this->email->send();
            $this->datas->data = "Check your mail to reset the password";
            $this->datas->output();
        } else {
            $this->datas->data = "Error To get user";
            $this->datas->output();
        }
    }

    public function compain() {
        $id = (int) $this->uri->segment(3);
        $usid = (int) $this->uri->segment(4);
        if ($id && $usid) {
            $data = array(
                'usid' => $usid
            );
            $this->db->update('dealer', $data, array('id' => $id));
            /* $this->db->where('id', $id);
              $this->db->update('usid', $data); */
            echo "down";
        } else
            echo "fails";
    }

    public function suprate() {
        $id = (int) $this->uri->segment(3);
        if ($id) {
            $data = array(
                'usid' => 0
            );
            $this->db->update('dealer', $data, array('id' => $id));
            echo "down";
        } else
            echo "fails";
    }

    public function compainbr() {
        $id = (int) $this->uri->segment(3);
        $usid = (int) $this->uri->segment(4);
        if ($id && $usid) {
            $data = array(
                'usid' => $usid
            );
            $this->db->update('dealer_branch', $data, array('branch_id' => $id));
            echo "down";
        } else
            echo "fails";
    }

    public function supratebr() {
        $id = (int) $this->uri->segment(3);
        if ($id) {
            $data = array(
                'usid' => 0
            );
            $this->db->update('dealer_branch', $data, array('branch_id' => $id));
            echo "down";
        } else
            echo "fails";
    }

    public function deleteImg() {
        $id = (int) $this->uri->segment(3);
        $data = $this->db->get_where('model_images', array('img_id' => $id));
        if ($data->num_rows() === 1) {
            $obj = $data->row();
            $name = $obj->model_image;
            delete_files(IMAGES_PATH . "newvehicles/$name");
            unlink("assets/images/newvehicles/$name");
            $name = strrev(implode(strrev("_thumb."), explode(".", strrev($name), 2)));
            delete_files(IMAGES_PATH . "newvehicles/thumbs/$name");
            unlink("assets/images/newvehicles/thumbs/$name");
            $this->db->where('img_id', $id);
            $this->db->delete('model_images');
            echo "file deleted";
        }
    }

    public function deleteColImg() {
        $id = (int) $this->uri->segment(3);
        $data = $this->db->get_where('color_new_vehicle', array('ci_id' => $id));
        if ($data->num_rows() === 1) {
            $obj = $data->row();
            $name = $obj->colorimage;
            delete_files(IMAGES_PATH . "newvehicles/$name");
            unlink("assets/images/newvehicles/$name");
            $name = strrev(implode(strrev("_thumb."), explode(".", strrev($name), 2)));
            delete_files(IMAGES_PATH . "newvehicles/thumbs/$name");
            unlink("assets/images/newvehicles/thumbs/$name");
            $this->db->where('ci_id', $id);
            $this->db->delete('color_new_vehicle');
            echo "file deleted";
        } else
            echo "no files";
    }

}