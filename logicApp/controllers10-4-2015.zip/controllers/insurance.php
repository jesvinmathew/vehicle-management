<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Insurance extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model(array('commanmodel'), '', true);
    }

    public function index() {
        $webData['tittle'] = "KeralaOnRoads - Insurance";
        $webData['content'][] = 'insurance';
        $webData['script'][] = "calendar";
        $webData['style'][] = "calendar";
        $webData['script'][] = "insurance";
        $this->load->view('templates/welcome', $webData);
    }

    public function idvmange() {
        if (!$this->session->userdata('keralaonroads_admin')) {
            redirect('welcome/login');
        } else {
            if (!empty($_POST)) {
                if (isset($_POST['vehicleType']) && $this->input->post('vehicleType') != 0 && isset($_POST['make']) && $this->input->post('make') != 0 && isset($_POST['model']) && $this->input->post('model') != 0) {
                    foreach ($this->input->post('idvid') as $key => $val) {
                        if (empty($val) || $val == "null") {
                            $query = $this->db->get_where('idv_chart', array('variant_id' => $this->input->post('vid')[$key]));
                            if ($query->num_rows() > 0) {
                                echo $this->input->post('vid')[$key];
                                $data = array(
                                    'comp_id' => $this->input->post('make'),
                                    'model_id' => $this->input->post('model'),
                                    'ageless6mon' => $this->input->post('ag6m')[$key],
                                    'age6to1' => $this->input->post('ag1y')[$key],
                                    'age1to2' => $this->input->post('ag2y')[$key],
                                    'age2to3' => $this->input->post('ag3y')[$key],
                                    'age3to4' => $this->input->post('ag4y')[$key],
                                    'age4to5' => $this->input->post('ag5y')[$key],
                                    'age5to6' => $this->input->post('ag6y')[$key],
                                    'age6to7' => $this->input->post('ag7y')[$key],
                                    'age7to8' => $this->input->post('ag8y')[$key],
                                'ag8to9' => $this->input->post('ag9y')[$key],
                                'ag9to10' => $this->input->post('ag10y')[$key],
                                'ag10to11' => $this->input->post('ag11y')[$key],
                                'ag11to12' => $this->input->post('ag12y')[$key],
                                'age12abow' => $this->input->post('ag13y')[$key],
                                    'status' => 1
                                );
                                $this->db->where('variant_id', $this->input->post('vid')[$key]);
                                $this->db->update('idv_chart', $data);
                            } else {
                                $data = array(
                                    'comp_id' => $this->input->post('make'),
                                    'model_id' => $this->input->post('model'),
                                    'variant_id' => $this->input->post('vid')[$key],
                                    'ageless6mon' => $this->input->post('ag6m')[$key],
                                    'age6to1' => $this->input->post('ag1y')[$key],
                                    'age1to2' => $this->input->post('ag2y')[$key],
                                    'age2to3' => $this->input->post('ag3y')[$key],
                                    'age3to4' => $this->input->post('ag4y')[$key],
                                    'age4to5' => $this->input->post('ag5y')[$key],
                                    'age5to6' => $this->input->post('ag6y')[$key],
                                    'age6to7' => $this->input->post('ag7y')[$key],
                                    'ag7to8' => $this->input->post('ag8y')[$key],
                                'ag8to9' => $this->input->post('ag9y')[$key],
                                'ag9to10' => $this->input->post('ag10y')[$key],
                                'ag10to11' => $this->input->post('ag11y')[$key],
                                'ag11to12' => $this->input->post('ag12y')[$key],
                                'age12abow' => $this->input->post('ag13y')[$key],
                                    'status' => 1
                                );
                                $this->db->insert('idv_chart', $data);
                            }
                        } else {
                            $data = array(
                                'comp_id' => $this->input->post('make'),
                                'model_id' => $this->input->post('model'),
                                'variant_id' => $this->input->post('vid')[$key],
                                'ageless6mon' => $this->input->post('ag6m')[$key],
                                'age6to1' => $this->input->post('ag1y')[$key],
                                'age1to2' => $this->input->post('ag2y')[$key],
                                'age2to3' => $this->input->post('ag3y')[$key],
                                'age3to4' => $this->input->post('ag4y')[$key],
                                'age4to5' => $this->input->post('ag5y')[$key],
                                'age5to6' => $this->input->post('ag6y')[$key],
                                'age6to7' => $this->input->post('ag7y')[$key],
                                'ag7to8' => $this->input->post('ag8y')[$key],
                            	'ag8to9' => $this->input->post('ag9y')[$key],
                                'ag9to10' => $this->input->post('ag10y')[$key],
                                'ag10to11' => $this->input->post('ag11y')[$key],
                                'ag11to12' => $this->input->post('ag12y')[$key],
                                'age12abow' => $this->input->post('ag13y')[$key],
                                'status' => 1
                            );
                            $this->db->where('idv_id', $val);
                            $this->db->update('idv_chart', $data);
                        }
                    }
                }
            }
            $webData['tittle'] = "KeralaOnRoads - IDV Manager";
            $webData['content'][] = 'idvmange';
            $webData['script'][] = "idvmange";
            $this->load->view('templates/welcome', $webData);
        }
    }

    public function manage() {
        $webData['tittle'] = "KeralaOnRoads - Insurance Manager";
        $webData['content'][] = 'insuranceMange';
        //$webData['script'][] = "insuranceMange";
        $this->load->view('templates/welcome', $webData);
    }
    
    public function buyinsuranse(){
        $webData['tittle'] = "KeralaOnRoads - Insurance";
        $webData['script'][] = "buyinsuranse";
        $webData['content'][] = 'buyInsurance';
        if(!isset($_POST['userchkd'])){
            $qry1=$this->db->get_where('company', array('cmp_id' => $this->input->post('make')));
            $webData['make']=$qry1->result();
            $qry2=$this->db->get_where('model', array('model_id' => $this->input->post('model')));
            $webData['model']=$qry2->result();
            $qry3=$this->db->get_where('variant', array('varient_id' => $this->input->post('variant')));
            $webData['var']=$qry3->result();
        }
        
         if(isset($_POST['km'])){
         $this->db->where('id',$this->input->post('id'));
          $this->db->update('insu_eqry', array(
                            'address'=>$this->input->post('address'),
                            'location'=>$this->input->post('location'),
                            'city'=>$this->input->post('city'),
                            'pin'=>$this->input->post('pin'),
                            'km'=>$this->input->post('km'),
                            'fual'=>$this->input->post('fual'),
                            'insu_cmp'=>$this->input->post('insu_cmp')
                
                
                ));
                if (($_FILES['rc']['name']) != "") 
                         {
             		$nesId = $this->db->insert_id();
        		$config['upload_path'] = './assets/images/insu_eqry/';
                        $config['allowed_types'] = 'gif|jpg|png|jpeg';
                        $config['max_size'] = '8048';
                        $_FILES['newimg']['name'] = $_FILES['rc']['name'];
                        $_FILES['newimg']['type'] = $_FILES['rc']['type'];
                        $_FILES['newimg']['tmp_name'] = $_FILES['rc']['tmp_name'];
                        $_FILES['newimg']['error'] = $_FILES['rc']['error'];
                        $_FILES['newimg']['size'] = $_FILES['rc']['size'];
                       	$config['file_name'] = 'korins_' . $nesId;
                        $this->load->library('upload', $config);
                        if (!$this->upload->do_upload('newimg')) {
                            $error = array('error' => $this->upload->display_errors());
                            echo $this->upload->display_errors();
                        } 
                        else {
                            $data = array('upload_data' => $this->upload->data());
                            $config['image_library'] = 'gd2';
                            $config['source_image'] = $data['upload_data']['full_path'];
                            $this->load->library('image_lib', $config);
                            $this->image_lib->initialize($config);
                            $this->db->insert('insu_eqry_images', array('name' => $data['upload_data']['file_name'], 'type' => 	1,'ins_id'=>$this->input->post('id')));
                      }}
                         
                         }
      $this->load->view('templates/welcome', $webData);
    }
    public function insu_enqry() {
        if (isset($_POST['name'])) {
            $this->db->insert('insu_eqry', $_POST);
            echo $this->db->insert_id();
        }
    }
    public function showEnquery(){
    	if ($this->session->userdata('keralaonroads_admin')) {
    		$webData['tittle'] = "KeralaOnRoads - Insurance Enquery";
	        $webData['content'][] = 'insuranceEnq';
	        $this->db->order_by('id','DESC');
	        $webData['enqu']=$this->db->get('insu_eqry')->result();
	        $this->load->view('templates/welcome', $webData);
    	}
    	else{
    		redirect('insurance');
    	}
    }
    public function enqueryInfo(){
    	if ($this->session->userdata('keralaonroads_admin') && ((int)$this->uri->segment(3))) {
    		$webData['tittle'] = "KeralaOnRoads - Insurance Enquery";
	        $webData['content'][] = 'insuranceEnqInfo';
	        $webData['enqu']=$this->db->get_where('insu_eqry',array('id'=>$this->uri->segment(3)))->result();
	        if(isset($_POST['submit'])){
                    $this->db->where('id',$this->uri->segment(3));
                    $this->db->update('insu_eqry',  array('thiParty'=>$this->input->post('tparty'),
                                                            'normel'=>$this->input->post('normel'),
                                                            'extra'=>$this->input->post('extra')
                        ));
                    
                    
                }
                if(isset($_POST['g_email'])){
            if(isset($_POST['toemail'])){
            $toEmail=$this->input->post('toemail');
            
            
            $this->load->library('email');
                $config = Array(
                    'protocol' => 'smtp',
                    'smtp_host' => 'vps.tricetechnologies.in',
                    'smtp_port' => 587,
                    'smtp_user' => 'development@keralaonroad.com',
                    'smtp_pass' => '_C^(4^6L=P^r',
                    'mailtype' => 'html',
                    'charset' => 'iso-8859-1'
                );
                $this->email->initialize($config);
                $this->email->from('info@keralaonroad.com', 'Admin');
                $this->email->to($toEmail);
                $this->email->subject('Insurance request reply');
                $this->email->message("hai");
                $this->email->send();
                 if($this->email->send()){
                echo "Your request Successfully sent";}
                else
                    echo 'no';
         }}
	        $this->load->view('templates/welcome', $webData);
    	}
    	else{
    		redirect('insurance');
    	}
    }
}