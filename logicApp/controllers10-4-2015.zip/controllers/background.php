<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Background extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model(array('commanmodel'), '', true);
    }
    
    public function testDrive(){
    
     $this->load->view('pages/testDriveForm');
    }
    public function service(){
        $this->load->view('pages/bookService');
    }
    public function breakservice(){
        $this->load->view('pages/breakService');
    }
    public function bookTestDrive(){
        if(isset($_POST['msg'])){
            if($_POST['delId'])
            {
                $qry=$this->db->get_where('dealer_branch',  array('branch_id'=>  $this->input->post('delId')));
                $toEmail=($qry->result()[0]->sale_email=="")?"support@keralaonroad.com":$qry->result()[0]->sale_email;
            }
            else
            {
                $toEmail="support@keralaonroad.com";
            }
            $ccEmail="support@keralaonroad.com";
            $this->load->library('email');
                $config = Array(
                    'protocol' => 'smtp',
                    'smtp_host' => 'vps.tricetechnologies.in',
                    'smtp_port' => 587,
                    'smtp_user' => 'development@keralaonroad.com',
                    'smtp_pass' => '_C^(4^6L=P^r',
                    'mailtype' => 'html',
                    'charset' => 'iso-8859-1'
                );
                $this->email->initialize($config);
                $this->email->from('info@keralaonroad.com', 'Admin');
                $this->email->to($toEmail);
                $this->email->cc($ccEmail);
                $this->email->subject('Test Drive');
                $this->email->message($this->input->post('msg'));
                $this->email->send();
                if($this->email->send()){
                echo "Your request successfully sent";
                $this->email->initialize($config);
                $this->email->from('info@keralaonroad.com', 'Admin');
                $this->email->to($this->input->post('toemail'));
                $this->email->subject('Pending');
                $this->email->message('Dear Mr. /Ms.'.$this->input->post('toname').'

We thank you for the interest shown in keralaonroad.com products and for your request for Test Drive<br/><br/>

As per your request, our team will assist you based on the information you have provided in this regard. We are confident that <br/>
(Model Requested) will meet all your requirements for space, durability, reliability, fuel efficiency and exceptional styling.<br/><br/>

We also take this opportunity to invite you to visit our website http://www.keralaonroad.com for various latest information and <br/>
updates on our Products and Services.<br/><br/>

Your request is in process and will get in touch with you shortly.<br/><br/>

Thank you once again for your time and effort.<br/><br/>

Regards<br/>
Customer Relation Manager/Department/Division<br/>
Keralaonroad.com<br/>
Email:info@keralaonroad.com
');
                $this->email->send();
                }
        }  

        
     }
    public function bookService(){
        if(isset($_POST['msg'],$_POST['delId'])){
            $qry=$this->db->get_where('dealer_branch',  array('branch_id'=>  $this->input->post('delId')));
            $toEmail=($qry->result()[0]->sar_email=="")?"support@keralaonroad.com":$qry->result()[0]->sar_email;
            $ccEmail="admin.executive@keralaonroad.com";
            $this->load->library('email');
                $config = Array(
                    'protocol' => 'smtp',
                    'smtp_host' => 'vps.tricetechnologies.in',
                    'smtp_port' => 587,
                    'smtp_user' => 'development@keralaonroad.com',
                    'smtp_pass' => '_C^(4^6L=P^r',
                    'mailtype' => 'html',
                    'charset' => 'iso-8859-1'
                );
                $this->email->initialize($config);
                $this->email->from('info@keralaonroad.com', 'Admin');
                $this->email->to($toEmail);
                $this->email->cc($ccEmail);
                $this->email->subject('Service');
                $this->email->message($this->input->post('msg'));
                $this->email->send();
                echo "Your request successfully sent";
        }
    }
    public function enquLone(){
        if(isset($_POST['msg'])){
            $toEmail="support@keralaonroad.com";
            $this->load->library('email');
                $config = Array(
                    'protocol' => 'smtp',
                    'smtp_host' => 'vps.tricetechnologies.in',
                    'smtp_port' => 587,
                    'smtp_user' => 'development@keralaonroad.com',
                    'smtp_pass' => '_C^(4^6L=P^r',
                    'mailtype' => 'html',
                    'charset' => 'iso-8859-1'
                );
                $this->email->initialize($config);
                $this->email->from('info@keralaonroad.com', 'Admin');
                $this->email->to($toEmail);
                $this->email->subject('Lone');
                $this->email->message($this->input->post('msg'));
                $this->email->send();
                echo "Your request Successfully sent";
        }
    }
    
    public function unenq(){
        if(isset($_POST['msg'])){
            $toEmail="support@keralaonroad.com";
            $this->load->library('email');
                $config = Array(
                    'protocol' => 'smtp',
                    'smtp_host' => 'vps.tricetechnologies.in',
                    'smtp_port' => 587,
                    'smtp_user' => 'development@keralaonroad.com',
                    'smtp_pass' => '_C^(4^6L=P^r',
                    'mailtype' => 'html',
                    'charset' => 'iso-8859-1'
                );
                $this->email->initialize($config);
                $this->email->from('info@keralaonroad.com', 'Admin');
                $this->email->to($toEmail);
                $this->email->subject('usedvehi enquiry');
                $this->email->message($this->input->post('msg'));
                $this->email->send();
               if($this->email->send()){
                echo "Your request successfully sent";
                $this->email->initialize($config);
                $this->email->from('info@keralaonroad.com', 'Admin');
                $this->email->to($this->input->post('toemail'));
                $this->email->subject('Pending');
                $this->email->message('Dear Mr. /Ms.'.$this->input->post('toname').'

We thank you for the interest shown in keralaonroad.com products and for your request for Test Drive<br/><br/>

As per your request, our team will assist you based on the information you have provided in this regard. We are confident that <br/>
(Model Requested) will meet all your requirements for space, durability, reliability, fuel efficiency and exceptional styling.<br/><br/>

We also take this opportunity to invite you to visit our website http://www.keralaonroad.com for various latest information and <br/>
updates on our Products and Services.<br/><br/>

Your request is in process and will get in touch with you shortly.<br/><br/>

Thank you once again for your time and effort.<br/><br/>

Regards<br/>
Customer Relation Manager/Department/Division<br/>
Keralaonroad.com<br/>
Email:info@keralaonroad.com
');
                $this->email->send();
                }
        }
    }
    public function vareq(){
        if(isset($_POST['msg'])){
            $toEmail="support@keralaonroad.com";
            $this->load->library('email');
                $config = Array(
                    'protocol' => 'smtp',
                    'smtp_host' => 'vps.tricetechnologies.in',
                    'smtp_port' => 587,
                    'smtp_user' => 'development@keralaonroad.com',
                    'smtp_pass' => '_C^(4^6L=P^r',
                    'mailtype' => 'html',
                    'charset' => 'iso-8859-1'
                );
                $this->email->initialize($config);
                $this->email->from('info@keralaonroad.com', 'Admin');
                $this->email->to($toEmail);
                $this->email->subject('Varient Price enquiry');
                $this->email->message($this->input->post('msg'));
                $this->email->send();
                if($this->email->send()){
                echo "Your request successfully sent";
                }
        }
    }
    public function browser(){
    	if(isset($_POST['msg'])){
            $toEmail="support@keralaonroad.com";
            $this->load->library('email');
                $config = Array(
                    'protocol' => 'smtp',
                    'smtp_host' => 'vps.tricetechnologies.in',
                    'smtp_port' => 587,
                    'smtp_user' => 'development@keralaonroad.com',
                    'smtp_pass' => '_C^(4^6L=P^r',
                    'mailtype' => 'html',
                    'charset' => 'iso-8859-1'
                );
                $this->email->initialize($config);
                $this->email->from('development@keralaonroad.com', '');
                $this->email->to($toEmail);
                $this->email->subject('Brochure');
                $this->email->message($this->input->post('msg'));
                $this->email->send();
                echo "Your request successfully sent";
        }
    }
    
    
}