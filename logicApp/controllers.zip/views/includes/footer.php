
    <div class="secondary radius columns">
        
        <center>Powered By <a href="http://www.logiclabz.co.in"> LogicLabz</a></center>
        </div>