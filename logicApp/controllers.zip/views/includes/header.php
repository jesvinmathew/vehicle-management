<div class="header">
    <div class="large-1 columns space1"></div>
    <div class="logo medium-3 columns">
        <img class="right" src="<?= IMAGE_PATH ?>logo.png" />
    </div>
    <div class="large-8 he1 "></div>
    <div class="medium-12 menu">
        <div class="large-8 he1 right">
            <?PHP $this->load->view('includes/menu'); ?>            
        </div>
    </div>
</div>