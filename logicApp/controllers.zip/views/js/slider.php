
<script src="<?= JS_PATH; ?>foundation/foundation.orbit.js"></script>
<script>
    $(document).foundation({
  orbit: {
    animation: 'slide',
    timer_speed: 5000,
    pause_on_hover: true,
    animation_speed: 500,
    navigation_arrows: true,
    bullets: false
  }
});

</script>