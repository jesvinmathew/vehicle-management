
<script src="<?= JS_PATH; ?>jquery.scrollbox.js"></script>
