
<link rel="stylesheet" href="<?= CSS_PATH; ?>index.css" />