<div  class="greeBg">
    
    <div class="row">
        <div style="height: 250px;" class="medium-12"></div>
        <div class="medium-6 medium-push-2">
            <br />
            <form class="form-horizontal" role="form" method="post">
                Login
                <label class="columns">
                    <div class="medium-4 columns">User name</div>
                    <div class="medium-8 columns">
                        <input type="text" class="text-control" required name="email" />
                    </div>
                </label>

                <label class="columns">
                    <div class="medium-4 columns">Password</div>
                    <div class="medium-8 columns">
                        <input type="password" class="text-control" required name="password">
                    </div>
                </label>
                <div class="columns">
                    <div class="medium-5 medium-push-4 columns">
                        <button type="submit" class="small round button">Login</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
