<style>
.hideme{
    display: none;
}
.form-control , .input-group{
    margin-top: 10px;
}

.input-group .new{
    width:70%;
}
.input-group .addnew{
    width:30%;
}
.input-group .file{
    width:30%;
}
.select{
    text-transform: capitalize;
    
}
.new{
    text-transform: capitalize;
}
.alert{
  color: white;

height: 29px;
padding: 0px 5px 0px 20px;
border: 3px solid #FFFFFF;
border-radius: 3px;
box-shadow: 0px 0px 1px 0px #000000;`
    
}
	.btn{
font-size: 14px;
line-height: 16px;
padding: 8px 16px 14px 16px;
font-weight: bold;
text-align: center;
color: #fff;
background-color: #2b5f90;
margin-top: 16px;
text-transform: uppercase;}
.uploadArea{ min-height:200px; width:200px; height:auto; border:1px dotted #ccc; padding:10px; cursor:move; margin-bottom:10px; position:relative; background:url(<?= IMAGES_PATH ?>plus-icon1.png) no-repeat center;}
.uploadArea1{min-height:90px; width:90px; height:auto; border:1px dotted #ccc; padding:10px; cursor:move; margin-bottom:10px; position:relative; background:url(<?= IMAGES_PATH ?>plus-icon1.png) no-repeat center;}
.uploadArea h1{ color:#666; z-index:0; text-align:center;}
.dfiles{ clear:both; border:1px solid #ccc; background-color:#E4E4E4; padding:3px;  position:relative; height:25px; margin:3px; z-index:1; width:97%; opacity:0.6; cursor:default;}

.invalid { border:1px solid red !important; }
.buttonUpload { display:inline-block; padding: 7px 20px 7px 20px; font-weight:bold; text-align: center; text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25); background-color: #0074cc; -webkit-border-radius: 4px;-moz-border-radius: 4px; border-radius: 4px; border-color: #e6e6e6 #e6e6e6 #bfbfbf; border: 1px solid #cccccc; color:#fff; }
.progress img{ margin-top:7px; margin-left:24px; }

</style>