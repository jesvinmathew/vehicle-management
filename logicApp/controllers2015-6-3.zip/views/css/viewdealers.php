<style>
.dealersimages{
    background-position: center;
    background-size: cover;
    height:200px;
    background-repeat: no-repeat;
   
}
</style>