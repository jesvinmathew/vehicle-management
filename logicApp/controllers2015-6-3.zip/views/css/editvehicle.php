<style>
td{
    background-size: contain;
background-repeat: no-repeat;
background-position: center;
}
</style>