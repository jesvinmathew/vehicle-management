 
<link rel="stylesheet" href="<?=BS_PATH;?>css/bootstrap.css"/>
<!--  --><link rel="stylesheet" href="<?= CSS_PATH; ?>style.css"/>
<link rel="stylesheet" href="<?= CSS_PATH; ?>menu.css"/>