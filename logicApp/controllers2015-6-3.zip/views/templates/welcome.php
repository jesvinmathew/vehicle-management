<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8"/>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
        <title><?PHP echo isset($tittle) ? $tittle : "Welcome To Kerala On Roads"; ?></title>
        <link rel="icon" href="<?PHP echo IMAGES_PATH ?>favicon.ico"/>
        <?PHP
        $this->load->view('css/common');
        if (isset($style)) {
            foreach ($style as $val)
                $this->load->view('css/' . $val);
        }
        $this->load->view('js/common');
        if (isset($script)) {
            foreach ($script as $val)
                $this->load->view('js/' . $val);
        }
        ?>
    </head>
    <body class="page1" id="top">
        <div class="progressdiv" style="display:none">

        </div>
        <div class="main col-xs-50 col-lg-46 col-lg-offset-2" style="overflow-x: hidden;" >
            <?PHP
            $this->load->view('includes/header');
            if (isset($_GET['erMsg'])) {            
                $msClass="has-error";
                $bgCls="bg-danger";
                ?>            
                <div class="col-xs-50" style="margin-top:5px;">
                    <nav class="navbar col-xs-48 col-xs-offset-1 col-md-35 col-md-offset-7 <?= $msClass." ".$bgCls ?>">
                        <ul class="help-block">
                            <label class="col-xs-50" style="padding:20px;"><?= $_GET['erMsg'];?></label>                            
                        </ul>
                    </nav>
                </div>
                <?php
            }
            if (isset($content)) {
                foreach ($content as $val)
                    $this->load->view('pages/' . $val);
            }
            ?>            
            <?php $this->load->view("includes/footer"); ?>
        </div>
    </body>