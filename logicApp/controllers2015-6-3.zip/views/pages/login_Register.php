<div class="bg1">
	<div class="content">
  		<div class="container">
    		<div class="row">
           		<div class="grid_12">
      				<center><h2 class="mb1">User Login</h2></center>
                    <div class="grid_5">
    					<form class="blocks" method="post" id="form">
                            <div class="grid_5">
                                <p>
                                    <label class="name" for="email">email:</label>
                                    <input placeholder="Enter Your User Name"  required="required"  id="email" name="email" class="text" type="text" />
                                </p>
                            </div>
                            <div class="grid_5">
                                <p>
                                    <label class="name" for="pass">Password:</label>
                                    <input placeholder="Enter Password Here"  required="required"  type="password" name="pass" id="pass" class="text" />
                                </p>
                            </div>
                            <div class="grid_5">
                        	<p>
                                <label>&nbsp;</label>
								<input type="submit" class="btn1" value="Login" name="submit" />
                            </p>
                        </div>
                    	</form>
                    </div>
                    <div class="grid_6">
    				<form class="blocks" method="post" id="form">
                    	<div class="grid_5">
                        	<p>
                                <label class="name">Contact Name</label>
                                <input class="text" required="required" type="text" name="name" placeholder="Contact Name" />
                            </p>
                        </div>	
                		<div class="grid_5">
                			<p>
                                <label class="name" for="email">email:</label>
                                <input placeholder="Enter Your User Name"  required="required"  id="email" name="email" class="text" type="text" />
                            </p>
		                </div>
        		        <div class="grid_5">
                			<p>
                                <label class="name" for="pass">Password:</label>
                                <input placeholder="Enter Password Here"  required="required"  type="password" name="pass" id="pass" class="text" />
                            </p>
		                </div>
                        <div class="grid_5">
                			<p>
                                <label class="name" for="rpass">Conform:</label>
                                <input placeholder="Conform Password"  required="required" type="password" name="rpass" id="rpass" class="text" />
                            </p>
		                </div>
                        <div class="grid_5">
                        	<p>
                                <label class="name">Phone</label>
                                <input class="text" type="text"  required="required" name="phone" placeholder="Contact Phone Number" />
                            </p>
                        </div>
                        <div class="grid_5">
                        	<p>
                                <label class="name">District</label>
                                <input class="text" type="text"  required="required" name="district" placeholder="Your Location" />
                            </p>
                        </div>
                        <div class="grid_5">
                        	<p>
                                <label class="name">Location</label>
                                <input class="text" type="text"  required="required" name="location" placeholder="Your Location" />
                            </p>
                        </div>
                        <div class="grid_5">
                        	<p>
                                <input class="line" id="saveMyData"  required="required"  type="checkbox" data-ga="remember-contact-information" checked="checked"><a href="#">Read and Agreed to the terms & Conditions of Kerala On Road.</a>
                            </p>
                        </div>
                		<div class="grid_5">
                        	<p>
                                <label>&nbsp;</label>
								<input type="submit" class="btn1" value="Register" name="submit" />
                            </p>
                        </div></form>
            		</form>
                </div>
                    
    			</div>
  			</div>
		</div>
	</div>
</div>