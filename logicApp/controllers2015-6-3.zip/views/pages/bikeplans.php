<div class="col-xs-48 col-xs-offset-1">
    <div class="col-xs-50">
            <div class="page1_block1">
                <img src="<?= IMAGES_PATH . '/ad.jpg'; ?>" />
            </div>
        </div>
    <div class="col-xs-50">
        <center><h2 class="mb1">User Plans Bike</h2></center>
        <div class="pricing_table" style="padding:20px 7px 50px 7px">

            <ul>
                <li>Plan</li>
                <li>Charge</li>
                <li>Search </li>
                <li>Bike Add</li>
                <li>Added vehicle Life</li>
                <li>Auto Update Vehicle</li>
                <li>Email Alert</li>
                <li>SMS Alert</li>
                
            </ul>

            <ul>
                <li>Free</li>
                <li>&#x20B9;0</li>
                <li><image src="<?PHP echo IMAGES_PATH; ?>yes.png" width="30px;" /></li>
                <li>1</li>
                <li>90 days</li>
                <li><image src="<?PHP echo IMAGES_PATH; ?>not.png" width="30px;" /></li>
                <li><image src="<?PHP echo IMAGES_PATH; ?>yes.png" width="30px;" /></li>
                <li><image src="<?PHP echo IMAGES_PATH; ?>not.png" width="30px;" /></li>
                
                <li><a href="" class="btn">Active Now</a></li>
            </ul>
            <ul>
                <li>Silver</li>
                <li>&#x20B9;5000</li>
                <li><image src="<?PHP echo IMAGES_PATH; ?>yes.png" width="30px;" /></li>
                <li>10</li>
                <li>90 days</li>
                <li>Once in 10 days</li>
                <li><image src="<?PHP echo IMAGES_PATH; ?>yes.png" width="30px;" /></li>
                <li><image src="<?PHP echo IMAGES_PATH; ?>yes.png" width="30px;" /></li>
                
                <li><a href="" class="btn">Buy Now</a></li>
            </ul>
            <ul>
                <li>Gold</li>
                <li>&#x20B9;8000</li>
                <li><image src="<?PHP echo IMAGES_PATH; ?>yes.png" width="30px;" /></li>
                <li>20</li>
                <li>90 days</li>
                <li>Once in 5 Day</li>
                <li><image src="<?PHP echo IMAGES_PATH; ?>yes.png" width="30px;" /></li>
                <li><image src="<?PHP echo IMAGES_PATH; ?>yes.png" width="30px;" /></li>
                
                <li><a href="" class="btn">Buy Now</a></li>
            </ul>

            <ul>
                <li>Platinum</li>
                <li>&#x20B9;12000</li>
                <li><image src="<?PHP echo IMAGES_PATH; ?>yes.png" width="30px;" /></li>
                <li>40</li>
                <li>90 days</li>
                <li>Once in a day</li>
                <li><image src="<?PHP echo IMAGES_PATH; ?>yes.png" width="30px;" /></li>
                <li><image src="<?PHP echo IMAGES_PATH; ?>yes.png" width="30px;" /></li>
                
                <li><a href="" class="btn">Buy Now</a></li>
            </ul>
            <ul>
                <li>Diamond Bikes and Cars</li>
                <li>&#x20B9;12000</li>
                <li><image src="<?PHP echo IMAGES_PATH; ?>yes.png" width="30px;" /></li>
                <li>40</li>
                <li>90 days</li>
                <li>Once in a day</li>
                <li><image src="<?PHP echo IMAGES_PATH; ?>yes.png" width="30px;" /></li>
                <li><image src="<?PHP echo IMAGES_PATH; ?>yes.png" width="30px;" /></li>
                
                <li><a href="" class="btn">Buy Now</a></li>
            </ul>
        </div>
    </div>
    <div class="col-xs-50">
        <br /><br/></div>
    <div class="col-xs-50">
            <div class="page1_block1">
                <img src="<?= IMAGES_PATH . '/ad.jpg'; ?>" />
            </div>
        </div>
</div>