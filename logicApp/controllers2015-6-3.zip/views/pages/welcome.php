<div class="col-xs-48 col-xs-offset-1">
    <div class="col-xs-50 col-sm-50 col-md-12 col-lg-12 ">
        <?php $this->load->view('includes/searchvehicle'); ?>
    </div>
    <div class="col-xs-50 col-sm-50 col-md-38 col-lg-38 ">
        <div class="col-xs-50" id="adDivHed">
            <div class="modal-header" style="float: right; z-index: 1055; position: absolute; right: 5px;">
                <button type="button" class="adclose" data-dismiss="adDivHed"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            </div>
            <div class="col-xs-50"><br /></div>
            <div class="col-xs-50 pull-right">
                <div id="carousel-example-generic111" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <?PHP
                        $this->db->where_in('loc', array('1', '2', '3', '4'));
                        $this->db->order_by('loc', 'ASC');
                        $ad = $this->db->get('add')->result();
                        for ($i = 0; isset($ad[$i]->loc) && $ad[$i]->loc == "1"; $i++) {
                            ?>
                            <div class="item item11 <?= (!$i) ? "active" : ""; ?>">
                                <img class="col-xs-50" src="<?= IMAGES_PATH . "advertisement/" . $ad[$i]->img_path1 ?>" />
                                <div class="carousel-caption">
                                </div>
                            </div>
                            <?PHP
                        }
                        ?>
                    </div>
                </div>
                <a class="left carousel-control" data-slide="prev" role="button" href="#carousel-example-generic111">

                    <span class="glyphicon glyphicon-chevron-left"></span>

                </a>
                <a class="right carousel-control" data-slide="next" role="button" href="#carousel-example-generic111">

                    <span class="glyphicon glyphicon-chevron-right"></span>

                </a>
            </div>
        </div>
        <div class="col-xs-50" id="adDivHed2">
            <div class="modal-header" style="float: right; z-index: 1055; position: absolute; right: 5px;">
                <button type="button" class="adclose2" data-dismiss="adDivHed"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            </div>
            <div class="col-xs-50"><br /></div>
            <div class="col-xs-50 pull-right">
                <div id="carousel-example-generic112" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <?PHP
                        for ($j = 0; isset($ad[$i]->loc) && $ad[$i]->loc == "2"; $i++, $j++) {
                            ?>
                            <div class="item item11 <?= (!$j) ? "active" : ""; ?>">
                                <img class="col-xs-50" src="<?= IMAGES_PATH . "advertisement/" . $ad[$i]->img_path1 ?>" />
                                <div class="carousel-caption">
                                </div>
                            </div>
                            <?PHP
                        }
                        ?>
                    </div>
                </div>
                <a class="left carousel-control" data-slide="prev" role="button" href="#carousel-example-generic112">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                </a>
                <a class="right carousel-control" data-slide="next" role="button" href="#carousel-example-generic112">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                </a>
            </div>
        </div>
        <div class="col-xs-50 col-sm-25" id="addhed1">
            <div class="slider_wrapper ">
                <div id="camera_wrap">
                    <?PHP
                    for (; isset($ad[$i]->loc) && $ad[$i]->loc == "3"; $i++) {
                        ?>
                        <div data-src="<?= IMAGES_PATH . "advertisement/" . $ad[$i]->img_path1 ?>"></div>
                        <?PHP
                    }
                    ?>
                </div>
            </div>
        </div>
        <div class="col-xs-50 col-sm-25" id="addhed2">
            <div class="slider_wrapper">
                <div id="camera_wrap1" class="">
                    <?PHP
                    for (; isset($ad[$i]->loc) && $ad[$i]->loc == "4"; $i++) {
                        ?>
                        <div data-src="<?= IMAGES_PATH . "advertisement/" . $ad[$i]->img_path1 ?>"></div>
                        <?PHP
                    }
                    ?>

                </div>
            </div>
        </div>
    </div>
    <div class="col-xs-48 col-xs-offset-1">
        <h2>&nbsp; &nbsp; Pre Owned Vehicles Recent Arrivals</h2>
        <div class="clear"></div>
        <div class="col-xs-25 alpha">
            <h3 class="bg11">&nbsp; &nbsp;Cars</h3>
            <div class="clear"></div>
            <?php $this->load->view('includes/usedarrivalscars.php'); ?>
        </div>
        <div class="col-xs-25">
            <h3 class="bg11">&nbsp; &nbsp; Bikes</h3>
            <div class="clear"></div>
            <?php $this->load->view('includes/usedarrivalsbikes.php'); ?>
        </div>
    </div>
    <div class="col-xs-48 col-xs-offset-1 content">
        <div class="col-xs-50">
            <div class="col-xs-50">
                <h2>Pre Owned Car Dealers</h2>
                <div class="col-xs-50 content">
                    <ul>
                        <?PHP
                        $this->db->order_by("placename", "ASC");
                        $qry = $this->db->get_where("place", array("type" => 3, "root_id" => 2));
                        foreach ($qry->result() as $place) {
                            ?>
                            <li class="col-xs-25 col-sm-10"><h5><a href="<?= site_url('welcome/search/used/car') . "?placeId=$place->place_id" ?>"><?= $place->placename; ?></a></h5></li>
                            <?PHP
                        }
                        ?>
                    </ul>
                </div>
            </div>

            <br>
            <br>
            <hr>
        </div>        
        <div class="col-xs-50">
            <div class="page1_block1">
                <?PHP
                    $this->db->where_in('loc', array('10', '11'));
                    $this->db->order_by('loc', 'ASC');
                    $add = $this->db->get('add')->result();
                    foreach($add as $ad){
                        ?>
                <a href="<?=$ad->link;?>"><img src="<?= IMAGES_PATH . "advertisement/" . $ad->img_path1; ?>" class="col-xs-23 col-xs-offset-1"/></a>
                        <?php
                    }
                ?>
            </div>
        </div>
        <div class="col-xs-48 col-xs-offset-1">
            <h2>&nbsp; &nbsp; New Vehicles Recent Arrivals</h2>
            <div class="col-xs-25">
                <h3 class="bg11">&nbsp; &nbsp; Cars</h3>
                <div class="clear"></div> 
                <?php $this->load->view('includes/newarrivalscars.php'); ?>
            </div>
            <div class="col-xs-25">
                <h3 class="bg11">&nbsp; &nbsp; Bikes</h3>
                <div class="clear"></div>
                <?php $this->load->view('includes/newarrivalsbikes.php'); ?>
            </div>
        </div>
        <div class="col-xs-48 col-xs-offset-1" id="navigations">
            <div class="col-xs-50 col-sm-25 col-md-16 mainbox">
                <div class="borderBox col-xs-50" style="font-size: 18px; padding: 10px; text-align: center;">Hot Group Chat</div>
                <div class="col-xs-50"><br /></div>
                <?php $this->load->view("includes/latecaht"); ?>
            </div>
            <div class="col-xs-50 col-sm-25 col-md-34">
                <div class="col-xs-40 col-xs-offset-5">
                    </div>
            </div>
        </div>
    </div>
</div>