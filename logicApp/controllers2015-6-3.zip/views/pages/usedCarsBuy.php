<div class="content">
  <div class="container">
    <div class="row">
      <div class="grid_12">
        <h2>List By Car Type </h2>        
      </div>
      <div class="grid_12 content" style="background:#FF6; padding-top:30px; margin-bottom:30px;">
        <div class="grid_2">
          <ul>
            <li><h5><a href="#">Alappuzha -  <span>2,580</span></a></h5></li>
            <li><h5><a href="#">Kannur -  <span> 2,451</span></a></h5></li>
            <li><h5><a href="#">Kochi -  <span> 16,443</span></a></h5></li>
          </ul>
        </div>
        <div class="grid_3">
          <ul>
            <li><h5><a href="#">Kollam -  <span> 5,633</span></a></h5></li>
            <li><h5><a href="#">Kottayam -  <span>  6,651</span></a></h5></li>
            <li><h5><a href="#">Kozhikode -  <span>  4,733</span></a></h5></li>
          </ul>
        </div>
        <div class="grid_3">
          <ul>
          	<li><h5><a href="#">Malappuram -  <span>  2,684</span></a></h5></li>
            <li><h5><a href="#">Manjeri -  <span>  875</span></a></h5></li>
            <li><h5><a href="#">Palakkad -  <span>  3,047</span></a></h5></li>  
          </ul>
        </div>
         <div class="grid_3">
          <ul>
            <li><h5><a href="#">Thiruvananthapuram -  <span>   8,334</span></a></h5></li>
            <li><h5><a href="#">Thrissur -  <span>   7,214</span></a></h5></li>
            <li><h5><a href="#">Tiruvalla -  <span>   1,800</span></a></h5></li>
          </ul>
        </div>
        <div class="grid_12">
        	
           
        	<a href="#" rel="popuprel" class="popup"><br><h3>Filter By Cities</h3></a>
            <div class="popupbox grid_10" id="popuprel">

              <h2><center>More Cities</center></h2>
              	<div class="grid_2">
          <ul>
  

            <li><h5><a href="#">Alappuzha -  <span>1,173</span></a></h5></li>
            <li><h5><a href="#">Changanacheri -  <span> 136</span></a></h5></li>
            <li><h5><a href="#">Cherthala -  <span> 73</span></a></h5></li>
            <li><h5><a href="#">Edathala -  <span>211</span></a></h5></li>
            <li><h5><a href="#">Guruvayur -  <span> 115</span></a></h5></li>
            <li><h5><a href="#">Kalamassery -  <span> 349</span></a></h5></li>
            <li><h5><a href="#">Kanhangad -  <span> 83</span></a></h5></li>
            <li><h5><a href="#">Kannur -  <span> 1,148</span></a></h5></li>
          </ul>
        </div>
        <div class="grid_2">
        
    <ul>
            <li><h5><a href="#">Kasaragod -  <span>310</span></a></h5></li>
            <li><h5><a href="#">Kayamkulam -  <span>239</span></a></h5></li>
            <li><h5><a href="#">Kochi -  <span>8,400</span></a></h5></li>
            <li><h5><a href="#">Kodungallur -  <span>367</span></a></h5></li>
            <li><h5><a href="#">Kollam -  <span>2,698</span></a></h5></li>
            <li><h5><a href="#">Kottayam -  <span>3,524</span></a></h5></li>
            <li><h5><a href="#">Kozhikode -  <span>2,307</span></a></h5></li>
            <li><h5><a href="#">Kunnamkulam -  <span>106</span></a></h5></li>
          </ul>
        </div>
        <div class="grid_2">
          <ul>
    
          	<li><h5><a href="#">Malappuram -  <span>1,405</span></a></h5></li>
            <li><h5><a href="#">Manjeri -  <span>502</span></a></h5></li>
            <li><h5><a href="#">Nedumangad -  <span>74</span></a></h5></li>
            <li><h5><a href="#">Neyyattinkara -  <span>67</span></a></h5></li>
            <li><h5><a href="#">Palakkad -  <span>1,463</span></a></h5></li>
            <li><h5><a href="#">Payyannur -  <span>55</span></a></h5></li>
            <li><h5><a href="#">Ponnani -  <span>89</span></a></h5></li>
            <li><h5><a href="#">Thalassery -  <span>134</span></a></h5></li>
          </ul>
        </div>
         <div class="grid_3">
          <ul>
    		<li><h5><a href="#">Thiruvananthapuram -  <span>3,867</span></a></h5></li>
            <li><h5><a href="#">Thrippunithura -  <span>301</span></a></h5></li>
            <li><h5><a href="#">Thrissur -  <span>3,503</span></a></h5></li>
            <li><h5><a href="#">Tirur -  <span>438</span></a></h5></li>
            <li><h5><a href="#">Tiruvalla -  <span>1,017</span></a></h5></li>
            <li><h5><a href="#">Vadakara -  <span>140</span></a></h5></li>
           </ul>
        </div>     

</div>
        
        </div>       
      </div>
      <div class="grid_4 search-box alpha">
    	<form>
       		<br>
      		<em><strong>Search By Keywords</strong></em><br>
          		<input  class="tmInput" data-class="tmInput"  type="text" id="searchbox" placeholder="Search..."><a href="#"><img src="<?= IMAGES_PATH; ?>/back.png" style="margin:-2px 0px 0px 5px;"></a>
             <hr style="width:90%" align="left" />
            <em><strong>Price</strong></em><br>
       		<input  class="tmInput" data-class="tmInput"  type="text" id="searchbox" placeholder="From" style="width:34%;"> - <input  class="tmInput" data-class="tmInput" style="width:34%;"  type="text" id="searchbox" placeholder="To"><a href="#"><img src="<?= IMAGES_PATH; ?>/back.png" style="margin:-2px 0px 0px 5px;"></a>
            <hr style="width:90%" align="left" />
            <em><strong>Make</strong></em><br>
            <div style="height:155px; overflow:auto; margin-right:20px;">
            <?php $this->load->view('includes/brands'); ?>
            
              </div>
              <br>
              <hr style="width:90%;" align="left" />
              <em><strong>Year</strong></em><br>
       		From :<?php $this->load->view('includes/fromyear'); ?> To :  <?php $this->load->view('includes/toyear'); ?>
            <a href="#"><img src="<?= IMAGES_PATH; ?>/back.png" style="margin:-2px 0px 0px 5px;"></a>
            <hr style="width:90%;" align="left" />
            <em><strong>Mileage</strong></em><br>
       		<select  style="width:90%;" name="mileage" id="mileage">
 			 <option value="all">All</option>
			 <option value="kilometers_0_30000">Less than 30,000Kms</option>
			 <option value="kilometers_0_50000">Less than 50,000Kms</option>
			 <option value="kilometers_0_80000">Less than 80,000Kms</option>
			 <option value="kilometers_0_120000">Less than 1,20,000Kms</option>
			 <option value="kilometers_0_150000">Less than 1,50,000 Kms</option>
 		   </select>
       		
            <hr style="width:90%;" align="left" />
            <em><strong>Condition</strong></em><br>
       		<select  style="width:90%;"  name="condition" id="condition">
 			 <option value="New">New</option>
			 <option value="Used">Used</option>
 		   </select>
            <hr style="width:90%" align="left" />
            <em><strong>Seller Type</strong></em><br>
       		<select  style="width:90%" name="seller type" id="seller type">
 			 <option value="Individuals">Individuals</option>
			 <option value="Professionals/Businesses">Professionals / Businesses</option>
 		   </select>
           <div class="content"></div>
        </form>
      </div>
  <div class="grid_8"><?php $this->load->view('includes/cars'); ?></div> 
    </div>
  </div>
</div>