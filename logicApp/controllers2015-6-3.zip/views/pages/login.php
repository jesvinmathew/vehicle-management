<div class="page1_block1">
            <?PHP if(($this->uri->segment(2)=='login')){
                $this->db->where('loc', 75);}
                else{
                $this->db->where('loc', 0);
                }
                    $this->db->order_by('loc', 'ASC');
                    $add = $this->db->get('add')->result();
                    if(isset($add[0]->img_path1)){
                        ?>
                    <a href="<?=$add[0]->link;?>"><img src="<?= IMAGES_PATH . "advertisement/" . $add[0]->img_path1; ?>" class="col-xs-48 col-xs-offset-1" style="padding:5px;"/></a>    
                    <?php }?>
        </div>

<div class="col-xs-50 col-sm-25 col-md-20 col-lg-15 col-sm-offset-5">
    <center><h2 class="mb1">User Login</h2></center>

    <?php
    if ($this->session->userdata('keralaonroads')) {
        redirect(site_url('welcome'));
    }
    ?>
    <ul class="options" style="list-style-type: none;">
        <?php
        if ($error == 0) {
            echo '<li class="success">' . $data . '</li>';
        }
        if ($error > 0) {
            echo '<li >' . $data . '</li>';
        }
        ?>
    </ul>
    <form class="blocks" method="post" id="form" action="<?= site_url('welcome/login') ?>">
        <div class="col-xs-50">
            <div class="col-xs-12 form-group">
                <label class="name"  style="margin-right:25px;line-height: 13px;" for="usName">Email:</label>
            </div>	<div class="col-xs-38"> <input placeholder="Enter Your email" required="required"  id="userName" name="userName" class="text form-control" type="email" />
            </div>
        </div>
        <div class="col-xs-50">
            <div class="col-xs-12 form-group">
                <label class="name" style="margin-right:25px;line-height: 13px;" for="pass">Password:</label>
            </div>	<div class="col-xs-38">  <input placeholder="Enter Password Here" required="required"  type="password" name="pass" id="pass" class="text form-control" />
            </div>
        </div>                
        <div class="col-xs-50">

            <a href="<?= site_url('welcome/forgotpassword'); ?>">Forgot Password. Need help ?</a>&nbsp; | &nbsp;<a href="<?= site_url('welcome/register'); ?>">New User Sign Up</a>

        </div>
        <div class="col-xs-50">

            <label>&nbsp;</label>
            <input type="submit" class="btn" id="submit" name="submit" value="Login" />

        </div>
    </form>
</div>