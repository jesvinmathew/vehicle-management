<div class="col-xs-48 col-xs-offset-1">
    <div class="col-xs-50">
        <img class="col-xs-30 col-xs-offset-10" src="<?= IMAGES_PATH . "commingSoon.jpg";?>" />
    </div>
</div>