 <?php
  $this->load->view('css/sell');
  if (isset($_POST['submitHandler']))
            {
                }
                else
                {
                
  ?>
  
	<script src="<?PHP echo JS_PATH; ?>jquery.js"></script>
    	<script src="<?PHP echo JS_PATH; ?>multiupload.js"></script>
     <?php
     }
  $this->load->view('includes/sellvehicle');
  ?>
