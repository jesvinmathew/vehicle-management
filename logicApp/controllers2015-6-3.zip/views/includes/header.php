<?PHP
    if($this->session->userdata('korUsId') && $this->session->userdata('korUsId')==101){
        $this->db->select('pid');
        $qry=$this->db->get_where('privilege_user',['usid'=>$this->session->userdata('keralaonroads')])->result();
        $privilage=array();
        foreach($qry as $val){
            $privilage[]=$val->pid;
        }
    }
    if($this->session->userdata('korUsId') && $this->session->userdata('korUsId')==107){
        $privilage=array();
    }
   
?>
<style>
    .icon-bar{
        background-color: #fff;
    }
</style>
<header>
    <div class="col-xs-50" style="background: #ca0002;">
        <div class="col-sm-48 col-sm-offset-1">
            <div class="col-xs-35 col-sm-30">
                <h1>
                    <a href="#"><img src="<?= IMAGES_PATH; ?>logo.png" alt="Kerala On Road"></a>
                </h1>
            </div>
            <div class="col-xs-50 col-sm-20 h_top fright">
                <?php
                if ($this->session->userdata('keralaonroads') == false) {
                    ?>
                    <a href="<?= site_url('welcome/login'); ?>">Login</a> | <a href="<?= site_url('welcome/register'); ?>">Register</a>
                    <?php
                } else if ($this->session->userdata('keralaonroads') == true) {
                    ?>
                    <a href="<?= site_url('welcome/logout'); ?>">Logout</a> 
                    Welcome <a href="<?= site_url('welcome/profile'); ?> "> <?= $this->session->userdata('keralaonroads_name'); ?></a><?PHP
            }
                ?>
                <div class="socials">
                    <a href="#" class="fa fa-twitter"></a>
                    <a href="#" class="fa fa-facebook"></a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xs-50" style="background: #b80002;">   
        <div class="ul col-xs-50 col-sm-48 col-sm-offset-1 container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                  <span class="sr-only">Menu</span>
                  <span class="icon-bar" style="background: #fff;"></span>
                  <span class="icon-bar" style="background: #fff;"></span>
                  <span class="icon-bar" style="background: #fff;"></span>
                </button>
                <div class="ultop col-xs-8 col-sm-5 col-md-50 col-lg-50  home">
                    <a href="<?= site_url('welcome/index');?>">&nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;</a>
                <div class="li col-xs-50">
                    <a href="<?= site_url('welcome/view/about'); ?>"> <b>About Us</b></a>
                    <a href="<?= site_url('welcome/view/brochure'); ?>"> <b>Brochure</b></a>
                    <a href="<?= site_url('welcome/contact'); ?>"><b>Contact Us</b></a>
                    <a href="<?= site_url('ad/adsWithus'); ?>"><b>Advertise With Us</b></a>
                    <?PHP
                        if ((isset($privilage) && in_array(9,$privilage))|| $this->session->userdata('korUsId')==107){
                        ?>
                        <a href="<?= site_url('admin/traffic'); ?>">Traffic</a>
                    <?php }?>
                </div>
                </div>
            </div>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <div class="ultop col-xs-10 col-md-4 drop">
                <a href="<?PHP echo site_url('welcome/sell/car'); ?>">Used Car</a>  
                <div class="li col-xs-50"> 
                    <a href="<?= site_url('welcome/sell/car'); ?>"> Sell Car</a>
                    <a href="<?= site_url('welcome/search/used/car'); ?>">Buy Car</a>
                    <a href="<?= site_url('welcome/plans'); ?>">User Plans</a>
                    <a href="<?= site_url('welcome/view/car-selling-tips'); ?>">Car Selling Tips</a>
                    <a href="<?= site_url('welcome/view/car-buying-tips'); ?>">Car Buying Tips</a>
                </div>
            </div>
            <div class="ultop col-xs-10 col-md-4 drop">
                <a href="<?= site_url('welcome/sell/bike'); ?>">Used Bike</a>
                <div class="li col-xs-50">
                    <a href="<?= site_url('welcome/sell/bike'); ?>">Sell Bike</a>
                    <a href="<?= site_url('welcome/search/used/bike'); ?>">Buy Bike</a>
                    <a href="<?= site_url('welcome/plans'); ?>">User Plans</a>
                    <a href="<?= site_url('welcome/view/bike-selling-tips'); ?>">Bike Selling Tips</a>
                    <a href="<?= site_url('welcome/view/bike-buying-tips'); ?>">Bike Buying Tips</a>
                </div>
            </div>
            <div class="ultop col-xs-10 col-md-5 drop">
                <a href="<?= site_url('welcome/search/new'); ?>">New Vehicle</a>
                <div class="li col-xs-50">
                    <a href="<?= site_url('welcome/search/new/car'); ?>">Car</a>
                    <a href="<?= site_url('welcome/search/new/bike'); ?>">Bike</a>
                    <a href="<?= site_url('welcome/brands/car'); ?>">Car Brands</a>
                    <a href="<?= site_url('welcome/brands/bike'); ?>">Bike Brands</a>
                </div>
            </div>
            <div class="ultop col-xs-10 col-md-4 drop">
                <a href="<?= site_url('welcome/search'); ?>">Search</a>
                <div class="li col-xs-50"> 
                    <a href="<?= site_url('welcome/search/used/car'); ?>">Used Car</a>
                    <a href="<?= site_url('welcome/search/used/bike'); ?>">Used Bike</a>
                    <a href="<?= site_url('welcome/search/new/car'); ?>">New Car</a>
                    <a href="<?= site_url('welcome/search/new/bike'); ?>">New Bike</a>
                </div>
            </div>
            <div class="ultop col-xs-10 col-md-5 drop">
                <a href="#">Dealers</a>
                <div class="li col-xs-50">
                    <a href="<?= site_url('dealer/index/used/car'); ?>">Used Car</a>
                    <a href="<?= site_url('dealer/index/used/bike'); ?>">Used Bike</a>
                    <a href="<?= site_url('dealer/index/new/car'); ?>">New Car</a>
                    <a href="<?= site_url('dealer/index/new/bike'); ?>">New Bike</a>
                    <a href="<?= site_url('dealer/service/car'); ?>">Car Service Centers</a>
                    <a href="<?= site_url('dealer/service/bike'); ?>">Bike Service Centers</a>
                    <?PHP
                        if (in_array(6,$privilage )|| $this->session->userdata('korUsId')==107){
                        ?>
                        <a href="<?= site_url('admin/dealersMange/new'); ?>">New Dealers Mange</a>
                        <a href="<?= site_url('admin/dealersMange/used'); ?>">Used Dealers Mange</a>
                        <?PHP
                    }
                    ?>
                </div>
            </div>
            <div class="ultop col-xs-10 col-md-5">
                <a href="<?= site_url('insurance'); ?>">Insurance</a>
                <div class="li col-xs-50">
                <?PHP
                        if (in_array(7,$privilage )|| $this->session->userdata('korUsId')==107){
                        ?>
                        <a href="<?= site_url('insurance/idvmange'); ?>">IDV Manage</a>
                        <a href="<?= site_url('insurance/showEnquery'); ?>">Show Enquery</a>
                        <?php }?>
                </div>
            </div>
            <div class="ultop col-xs-10 col-md-3">
                <a href="<?= site_url('welcome/loan'); ?>">Loans</a>
                <div class="li col-xs-50">
                    <a href="<?= site_url('welcome/loan'); ?>">Vehicle Loan</a>
                    <?php if ($this->session->userdata('keralaonroads_admin')) {
                        ?>
                    <a href="<?= site_url('welcome/emi'); ?>">EMI Calculator</a> <?php }?>
                </div>
            </div>
            <div class="ultop col-xs-10 col-md-7">
                <a href="<?= site_url('news'); ?>">News And Events</a>
                <div class="li col-xs-50">
                    <a href="<?= site_url('news/newsgallery'); ?>">Photo Gallery</a>
                    <?PHP
                        if (in_array(8,$privilage )|| $this->session->userdata('korUsId')==107){
                        ?>
                      <a href="<?= site_url('news/manage'); ?>">News Manage</a><?php }?>  
                    </div>
            </div>
            <div class="ultop col-xs-10 col-md-5 col-lg-5">
                <a href="<?= site_url('hotties') ?>">Hot Groups</a>
            </div>
            <?php if ($this->session->userdata('keralaonroads_admin')) {
                ?>
                <div class="ultop col-xs-10 col-md-5 col-lg-5">
                    <a href="#">Manage</a>
                    <div class="li col-xs-50">
                        <?PHP
                        if (in_array(1,$privilage )|| $this->session->userdata('korUsId')==107){
                        ?>
                        <a href="<?= site_url('admin/manage'); ?>">Vehicle Manage</a>
                        <?PHP } 
                        if(in_array(2,$privilage )|| $this->session->userdata('korUsId')==107){
                        ?>
                        <a href="<?= site_url('admin/userMange'); ?>">Users Manage</a><?php }
                        if(in_array(3,$privilage )|| $this->session->userdata('korUsId')==107){
                         ?>
                       	<a href="<?= site_url('ad/manage');?>">AddManage</a><?php }
                       	if(in_array(11,$privilage )|| $this->session->userdata('korUsId')==107){ ?>
                        <a href="<?= site_url('admin/placemanage'); ?>">Place Manage</a> <?php } 
                        if(in_array(4,$privilage )|| $this->session->userdata('korUsId')==107){ ?>
                        <a href="<?= site_url('welcome/uvManage');?>">Used vehicle manage</a>
                        <?php }  if(in_array(5,$privilage )|| $this->session->userdata('korUsId')==107){?>
                        <a href="<?= site_url('admin/plans');?>">Plan</a> <?php } ?>
                        <a href="<?= site_url('welcome/accessories'); ?>">Accessories</a>
                    </div>
                </div>                        
                <?php } else{ ?>
           
                <div class="ultop col-xs-10 col-md-5 col-lg-5">
                    <a href="<?= site_url('welcome/accessories'); ?>">Accessories</a>
                </div>
<?php } ?>            
            </div></div>
        <div class="clear"></div>
    </div>  
</header>