<div class="vticker adv">
	<ul>
		<li><a href="#"><img src="<?php echo IMAGES_PATH;?>/page1_img17.jpg"></a></li>
		<li><a href="#"><img src="<?php echo IMAGES_PATH;?>/page1_img18.jpg"></a></li>
        <li><a href="#"><img src="<?php echo IMAGES_PATH;?>/page1_img19.jpg"></a></li>
		<li><a href="#"><img src="<?php echo IMAGES_PATH;?>/page1_img20.jpg"></a></li>
        <li><a href="#"><img src="<?php echo IMAGES_PATH;?>/page1_img21.jpg"></a></li>
		<li><a href="#"><img src="<?php echo IMAGES_PATH;?>/page1_img22.jpg"></a></li>
	</ul>
</div>