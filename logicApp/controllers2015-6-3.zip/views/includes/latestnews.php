<div class="holder6"></div>
<div class="customBtns">
      <span class="arrowPrev"></span>
      <span class="arrowNext"></span>
    </div>
<hr>
<div class="clear"></div>
<ul id="itemContainer6">
<li>
<p><img class="image" src="<?php echo IMAGES_PATH;?>/page1_img7.jpg">
Lorem ipsum dolor sit amet conse ctetur Lorem ipsum dolor sit amet conse.
  <br>
  <strong class="fright"><a href="#">More</a></strong>
  <br>
  <hr>
</p>
</li>
<li>
<p>
<img class="image" src="<?php echo IMAGES_PATH;?>/page1_img8.jpg">
Lorem ipsum dolor sit amet conse ctetur Lorem ipsum dolor sit amet conse.
  <br>
  <strong class="fright"><a href="#">More</a></strong>
  <br>
  <hr>
</p>
</li>
<li>
<p>
<img class="image" src="<?php echo IMAGES_PATH;?>/page1_img9.jpg">
Lorem ipsum dolor sit amet conse ctetur Lorem ipsum dolor sit amet conse.
  <br>
  <strong class="fright"><a href="#">More</a></strong>
  <br>
  <hr>
</p>
</li>
<li>
<p>
<img class="image" src="<?php echo IMAGES_PATH;?>/page1_img10.jpg">
Lorem ipsum dolor sit amet conse ctetur Lorem ipsum dolor sit amet conse.
  <br>
  <strong class="fright"><a href="#">More</a></strong>
  <br>
  <hr>
</p>
</li>
<li>
<p>
<img class="image" src="<?php echo IMAGES_PATH;?>/page1_img11.jpg">Lorem ipsum dolor sit amet conse ctetur Lorem ipsum dolor sit amet conse.
  <br>
  <strong class="fright"><a href="#">More</a></strong>
  <br>
  <hr>
</p>
</li>
<li>
<p>
<img class="image" src="<?php echo IMAGES_PATH;?>/page1_img12.jpg">Lorem ipsum dolor sit amet conse ctetur Lorem ipsum dolor sit amet conse.
  <br>
  <strong class="fright"><a href="#">More</a></strong>
  <br>
  <hr>
</p>
</li>
</ul>