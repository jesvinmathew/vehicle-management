<link rel="stylesheet" type="text/css" href="<?PHP echo CSS_PATH; ?>calendar/jquery.ui.all.css" />
        <link rel="stylesheet" type="text/css" href="<?PHP echo CSS_PATH; ?>jquery-ui.css" />
        <script language="javascript" src="<?= JS_PATH ?>jquery-1.7.2.js" type="text/javascript"></script>
        <script language="javascript" type="text/javascript" src="<?= JS_PATH ?>calendar/jquery.ui.widget.js"></script>
        <script language="javascript" type="text/javascript" src="<?= JS_PATH ?>calendar/jquery.ui.core.js"></script>
        <script language="javascript" type="text/javascript" src="<?= JS_PATH ?>calendar/jquery.ui.datepicker.js"></script>