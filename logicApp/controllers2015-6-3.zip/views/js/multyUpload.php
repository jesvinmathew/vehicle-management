    <!--[if lt IE 9]>
          <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
    <script src="<?= JS_PATH; ?>jquery.filedrop.js"></script>