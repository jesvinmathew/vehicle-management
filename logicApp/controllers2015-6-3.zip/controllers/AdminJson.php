<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class AdminJson extends CI_Controller {

    public function __construct() {
        parent::__construct();
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
        header('Content-type: application/json; charset=utf8');
        $this->load->helper(array('form', 'url'));
        $this->load->model('datas');
        $this->load->model('CommanModel');
        $this->load->model('validate');
        $this->load->model('users');
    }
    public function searchUser(){
    	if(isset($_POST['email'])){
    		$this->db->select('user_id,fname,lname,gender,email,username,address,contactno,location,created_at,updated_at,uptypename,vehicle_type');
		$this->db->join('uptype', 'uptype.uptype_id = users.ac_type');
		$query = $this->db->get_where('users',['email'=>  $this->input->post('email')]);
		$this->datas->data = $query->result();
                $this->datas->output();
    	}
    }
     public function getTraffic(){
    	if(isset($_POST['id'])){
    		
		$query = $this->db->get('traffic_admin');
		$this->datas->data = $query->result();
                $this->datas->output();
    	}
    }
}