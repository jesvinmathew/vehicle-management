    <?php

    if (!defined('BASEPATH'))
        exit('No direct script access allowed');

    class Admin extends CI_Controller {

        public function __construct() {
            parent::__construct();
            if ($this->session->userdata('keralaonroads_admin')) {
                $user = ($this->session->userdata('keralaonroads_name')) ? $this->session->userdata('keralaonroads_name') : "Guest";
                $trafic = Array(
                    'ip' => $this->input->ip_address(),
                    'page' => uri_string(),
                    'username' => $user,
                    'usid' => $this->session->userdata('keralaonroads'),
                    'date' => date("Y-m-d")
                );
                $this->db->insert('traffic_admin', $trafic);
            } else {
                redirect('welcome');
                exit;
            }
        }

        public function index() {
            $webData['tittle'] = "Welcome To KeralaONRoads";
            $webData['style'][] = "index";
            $webData['script'][] = "index";
            $webData['content'][] = 'welcome';
            $this->load->view('templates/welcome', $webData);
        }

        public function logout() {
            $this->session->unset_userdata('keralaonroads');
            redirect(base_url() . 'welcome', 'refresh');
            header('location:' . base_url() . 'welcome');
        }

        public function placemanage() {
            if ($this->session->userdata('keralaonroads_admin')) {
                $webData['country'] = $this->db->get_where('place', array('type' => 1))->result();
                $webData['tittle'] = "Welcome To KeralaOnRoads- Place Mange";
                $webData['script'][] = "placeMange";
                $webData['content'][] = 'placeMange';
                $this->load->view('templates/welcome', $webData);
            } else
                redirect('welcome/login');
        }

        public function plans() {
            if ($this->session->userdata('keralaonroads_admin')) {
                $webData['plans'] = $this->db->get('uptype')->result();
                $webData['tittle'] = "Welcome To KeralaOnRoads- Plans";
                $webData['content'][] = 'planMange';
                $webData['script'][] = "planMange";
                $this->load->view('templates/welcome', $webData);
            } else
                redirect('welcome/login');
        }

        public function updatePlan() {
            if ($this->session->userdata('keralaonroads_admin')) {
                if (is_array($_POST)) {
                    $this->db->update('uptype', $_POST, array('uptype_id' => $this->input->post('uptype_id')));
                    echo "Updated Successfully";
                } else {
                    echo "File error";
                }
            }
        }

        public function dealersMange() {
            if ($this->uri->segment(3) && $this->session->userdata('keralaonroads_admin')) {
                $sname = $this->session->userdata('keralaonroads_admin');
                $this->message = '';
                $this->error = '';
                $webData['upload_data'] = '';
                $webData['tittle'] = "Welcome To KeralaOnRoads- Dealer Management";
                $webData['script'][] = "dealersMange";
                $webData['content'][] = 'dealersmange';
                $this->load->view('templates/welcome', $webData);
            } else
                redirect('welcome/login');
        }

        public function traffic() {
            if ($this->session->userdata('keralaonroads_admin')) {
                $this->db->order_by('id', 'DESC');
                $this->db->limit(10000);
                $webData['trafic'] = $this->db->get('traffic')->result();
                $webData['tittle'] = "Welcome To KeralaOnRoads- Traffic";
                $webData['content'][] = 'traffic';
                $webData['style'][] = "slimtable";
                $webData['script'][] = "slimtable";
                $this->load->view('templates/welcome', $webData);
            } else
                redirect('welcome/login');
        }

        public function userMange() {
            if (!$this->session->userdata('keralaonroads_admin')) {
                redirect('welcome/login');
            } else {
                if (isset($_POST['userid']) && !(isset($_POST['chk']))) {
                    $this->db->where('user_id', $_POST['userid']);
                    $this->db->update('users', ['utype_id' => 1]);
                    $this->db->where('usid', $this->input->post('userid'));
                    $this->db->delete('privilege_user');
                }
                if (isset($_POST['userid']) && isset($_POST['chk'])) {
                    $this->db->where('user_id', $_POST['userid']);
                    $this->db->update('users', ['utype_id' => 101]);
                    $this->db->where('usid', $this->input->post('userid'));
                    $this->db->delete('privilege_user');
                    foreach ($_POST['chk'] as $value) {
                        $this->db->insert('privilege_user', array('usid' => $this->input->post('userid'), 'pid' => $value));
                    }
                }
                $this->db->order_by('user_id', 'DESC');
                $query = $this->db->get_where('users', array('utype_id' => 1));
                $webData['users'] = $query->result();
                $webData['utypes'] = $this->db->get('uptype')->result();
                $webData['dist'] = $this->db->get_where('place', array('type' => 3))->result();
                $webData['content'][] = "userMange";
                $webData['script'][] = "userMange";
                $this->load->view('templates/welcome', $webData);
            }
        }

        public function adminUser() {
            if (!$this->session->userdata('keralaonroads_admin')) {
                redirect('welcome/login');
            } else {
                if (isset($_POST['email'])) {
                    $data = $this->db->get_where('users', array('email' => $this->input->post('email')));

                    $webData['getuser'] = $data->result();
                    if (isset($data->result()[0]->utype_id)) {
                        echo "hi";
                        // $this->db->where('user_id', $data->result()[0]->utype_id);
                        //$this->db->update('users',  array('utype_id' => 101));
                    }
                }
                if (($this->uri->segment(3) === 'currentuser')) {
                    $data = $this->db->get('users');
                    $webData['alluser'] = $data->result();
                    if (isset($_GET['eid'])) {
                        $this->db->update('users', array('utype_id' => 1));
                    }
                }
                $webData['content'][] = "adminUser";
                $this->load->view('templates/welcome', $webData);
            }
        }

        public function manage() {
            $sname = $this->session->userdata('keralaonroads_admin');
            $this->message = '';
            $this->error = '';
            if (!$this->session->userdata('keralaonroads_admin')) {
                redirect('welcome/login');
            } else {
                $webData['tittle'] = "Welcome To KeralaONRoads- Sell Your Car";
                $webData['error'] = 2;
                $webData['value'] = '';
                $webData['style'][] = "manage";
                $webData['script'][] = "manage";
                $webData['content'][] = 'manage';
                $this->db->order_by("feachur_id asc");
                $query = $this->db->get_where('feaur', 'patent = 0');
                $webData['feaures1'] = $query->result();
                $this->db->order_by("patent asc, feachur asc");
                $query = $this->db->get_where('feaur', 'patent != 0');
                $webData['feaures2'] = $query->result();
                $this->db->order_by("spec_id", "asc");
                $query = $this->db->get_where('specification', 'patent = 0');
                $webData['specification1'] = $query->result();
                $this->db->order_by("patent asc, specification asc");
                $query = $this->db->get_where('specification', 'patent != 0');
                $webData['specification2'] = $query->result();
                $webData['deatils'] = $this->commanmodel->selectAll('deatils');
                $webData['fueltype'] = $this->commanmodel->selectAll('fueltype');
                $this->load->view('templates/welcome', $webData);
            }
        }

        public function deletetrafic() {
            if ($this->session->userdata('keralaonroads_admin')) {
                $this->db->delete('traffic', array('id' => $this->uri->segment(3)));
                redirect('admin/traffic');
            } else
                redirect('welcome/login');
        }

        public function traficExcel() {
            if ($this->session->userdata('keralaonroads_admin')) {
                $this->load->library('excel');
                //activate worksheet number 1
                $this->excel->setActiveSheetIndex(0);
                //name the worksheet
                $this->excel->getActiveSheet()->setTitle('Traffic Data');
                $this->db->distinct();
                $this->db->select('ip');
                $num = $this->db->get('traffic')->num_rows();

                //set cell A1 content with some text
                $this->excel->getActiveSheet()->setCellValue('A1', '#');
                $this->excel->getActiveSheet()->setCellValue('B1', 'I P');
                $this->excel->getActiveSheet()->setCellValue('C1', 'Page');
                $this->excel->getActiveSheet()->setCellValue('D1', 'User Name');
                $this->excel->getActiveSheet()->setCellValue('E1', 'Time');
                $this->excel->getActiveSheet()->setCellValue('H2', 'Number of different IPS');
                $this->excel->getActiveSheet()->setCellValue('J2', $num);
                $this->excel->getActiveSheet()->getStyle('H2')->getFont()->setBold(true);
                $this->excel->getActiveSheet()->setCellValue('H1', "Report");
                $this->excel->getActiveSheet()->getStyle('H1')->getFont()->setSize(16);
                $this->excel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
                $this->excel->setActiveSheetIndex(0)->mergeCells('H1:J1');
                $this->excel->setActiveSheetIndex(0)->mergeCells('H2:I2');
                $this->excel->getActiveSheet()->setCellValue('H3', 'Date');
                $this->excel->getActiveSheet()->setCellValue('I3', 'Hit');
                $this->excel->getActiveSheet()->setCellValue('J3', 'Ip');
                $this->excel->getActiveSheet()->getStyle('H3')->getFont()->setBold(true);
                $this->excel->getActiveSheet()->getStyle('I3')->getFont()->setBold(true);
                $this->excel->getActiveSheet()->getStyle('J3')->getFont()->setBold(true);
                $this->db->order_by('id', 'DESC');
                $exeData = $this->db->get('traffic')->result();
                foreach ($exeData as $key => $val) {
                    $this->excel->getActiveSheet()->setCellValue('A' . ($key + 2), $key + 1);
                    $this->excel->getActiveSheet()->setCellValue('B' . ($key + 2), $val->ip);
                    $this->excel->getActiveSheet()->setCellValue('C' . ($key + 2), $val->page);
                    $this->excel->getActiveSheet()->setCellValue('D' . ($key + 2), $val->username);
                    $this->excel->getActiveSheet()->setCellValue('E' . ($key + 2), $val->time);
                }
                /* $this->db->distinct();
                  $this->db->select('date');
                  $dates = $this->db->get('traffic')->result();
                  foreach($dates as $dkey => $dat){
                  $this->db->distinct();
                  $this->db->select('ip');
                  $datipnum=$this->db->get_where('traffic',['date'=>$dat->date])->num_rows();
                  $this->db->select('ip');
                  $datnum=$this->db->get_where('traffic',['date'=>$dat->date])->num_rows();
                  $this->excel->getActiveSheet()->setCellValue('H'.($dkey+4), $dat->date);
                  $this->excel->getActiveSheet()->setCellValue('I'.($dkey+4), $datipnum);
                  $this->excel->getActiveSheet()->setCellValue('J'.($dkey+4), $datnum);
                  } */
                /* //change the font size
                  $this->excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(20);
                  //make the font become bold
                  //$this->excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
                  //merge cell A1 until D1
                  //$this->excel->getActiveSheet()->mergeCells('A1:D1');
                  //set aligment to center for that merged cell (A1 to D1) */
                $this->excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                $filename = 'Traffic.xls'; //save our workbook as this file name
                header('Content-Type: application/vnd.ms-excel'); //mime type
                header('Content-Disposition: attachment;filename="' . $filename . '"'); //tell browser what's the file name
                header('Cache-Control: max-age=0'); //no cache
                //save it to Excel5 format (excel 2003 .XLS file), change this to 'Excel2007' (and adjust the filename extension, also the header mime type)
                //if you want to save it as .XLSX Excel 2007 format
                $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');
                //force user to download the Excel file without writing it to server's HD
                $objWriter->save('php://output');
            }
        }

    }
    