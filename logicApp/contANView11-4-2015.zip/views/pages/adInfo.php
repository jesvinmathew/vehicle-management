<div class="main col-xs-50 col-lg-46 col-lg-offset-2">
	<a href="<?=site_url('ad/add')?>">Add New</a>
	<table>
		<tr>
			<th>Page Location</th>
			<th>Type</th>
			<th>Position</th>
			<th>Duration</th>
			<th>Specification</th>
			<th></th>
		</tr>
		<?PHP
			foreach($ad as $add){
				?>
				<tr>
					<td><?=$add->location;?></td>
					<td><?=$add->type;?></td>
					<td><?=$add->postion;?></td>
					<td><?=$add->duration;?></td>
					<td><?=$add->specification;?></td>
				</tr>
				<?PHP
			}
		?>
	</table>
</div>