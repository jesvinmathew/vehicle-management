<div class="bg1">
	<div class="content">
  		<div class="container">
           		        <div class="col-xs-50">
                                      <h2>About Keralaonroad.com</h2> 
                                         <h3>Value your ownership</h3>
Welcome to Keralaonroad.com – Kerala’s first, foremost and dedicated auto media portal. Keralaonroad.com is an innovative platform for new and used cars/bikes owners to chase their dreams and passions.  Through Keralaonroad.com we provide you the best opportunity as buyer and seller to get the best deal next door.  We, in Keralaonroad.com yearn to provide the most reliable and accurate information of the vehicles for you to choose.
We also avail you with a platform where car and bike buyers and owners can come together to discuss and exchange the views about their cars and bikes.
<h2>Our Mission:</h2>
Our mission at Keralaonroad.com is to be your ultimate online solution for buying and selling new, certified and used cars and bikes. Our portal is designed to provide you with transparent and reliable information for buying process and make an array of choices of cars and bikes easier than ever before.

To arm our owners and buyers with comprehensive and impartial information on cars and bikes, we have developed tools like expert reviews, owner reviews, detailed specifications and biding process to evaluate your ownership.

<h2>Group:</h2>
Kerala on Road.com is owned by Kepler Technology services. 
Thank you for visiting Keralaonroad.com.
                                </div>
                </div>
        </div> 
</div>