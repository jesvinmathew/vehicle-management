<div class="col-xs-50 col-xs-offset-1">
    <div class="col-xs-50 col-sm-20 col-md-12 search-box alpha">
        <ul>
            <?PHP
            foreach ($utypes as $utype) {
                echo "<li><a href='#' class='users' title='$utype->uptype_id'>$utype->uptypename </a></li>";
            }
            ?>
            <li><a href="#" class="users" title="delapp">Dealer Head Approval</a></li>
            <li><a href="#" class="users" title="braapp">Dealer Branch Approval</a></li>
            <li><h3>District</h3></li>
            <?PHP
            foreach ($dist as $dis) {
                echo "<li><a href='#' class='dis' title='$dis->place_id'>$dis->placename</a></li>";
            }
            ?>
        </ul>
        <input type="hidden" value="1" id="uTypeId" />
    </div>
    <div class="col-xs-50 col-sm-30 col-md-38 alpha" id="userInfo">
        <?PHP
        if (isset($users)) {
            foreach ($users as $user) {
                ?>
                <div id="userInfo" class="col-xs-50 col-sm-30 col-md-15 box" style="margin: 3px 3px 3px 3px;">
                    <ul>
                        <li><b>Name:</b><?= $user->username; ?></li>
                        <li><b>Contact number:</b><?= $user->contactno; ?></li>
                        <li><b>Location:</b><?= $user->location; ?></li>                           
                        <li><b>Ip:</b><?= $user->ipaddress; ?></li>
                    </ul>

                </div>
                <?PHP
            }
        }
        ?>        
    </div>
</div>