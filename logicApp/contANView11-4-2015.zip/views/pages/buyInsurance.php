<style>
    #maintab .nav li{
        background-color: rgba(104, 104, 104, 0.77);
        color: #FFFFFF;
        margin-right: 0px;
        padding-top: 0px;
        font-size: 14px;
        float: left;
    }
    #maintab .nav li.active{
        background-color: rgb(62, 110, 165);
        color:#FFFFFF;
    }
    #maintab .nav > li.active > a, .nav-tabs > li.active > a:hover, .nav-tabs > li.active > a:focus
    {
        background-color:transparent;

        border:none;

    }
</style>
<div class="bg">
    <div class="container">
        <div class="row-fluid">
            <div class="col-xs-50">
                <h2>Buy insurance</h2>
                <div class="col-xs-50">
                    <form class="blocks" method="post" id="form" action="<?= site_url('insurance/buyinsuranse'); ?>">
                        <div class="col-xs-45">
                            <div class="col-xs-50">
                                <div class="col-xs-10 form-group">
                                    Name: 
                                </div>
                                <div class="col-xs-15">
                                    <b><?= $this->input->post('name'); ?></b>
                                </div>
                                <div class="col-xs-10 form-group">
                                    Email:
                                </div>
                                <div class="col-xs-15">
                                    <b><?= $this->input->post('email'); ?></b>
                                </div>
                            </div>
                            <div class="col-xs-50">
                                <div class="col-xs-10 form-group">
                                    Contact number  :
                                </div>
                                <div class="col-xs-15">
                                    <b><?= $this->input->post('ph'); ?></b>
                                </div>
                                <div class="col-xs-10 form-group">
                                    Vehicle type  :
                                </div>
                                <div class="col-xs-15">
                                    <b><?php
                                        if ($this->input->post('vehicleType') == 1) {
                                            echo 'bike';
                                        } elseif ($this->input->post('vehicleType') == 2) {
                                            echo'Private Car';
                                        } else
                                            echo 'Taxi Car';
                                        ?></b>
                                </div>
                            </div>
                            <?PHP
                            if (!isset($_POST['userchkd'])) {
                                ?>
                                <div class="col-xs-50">
                                    <div class="col-xs-10 form-group">
                                        Make :
                                    </div>
                                    <div class="col-xs-15">
                                        <b><?= $make[0]->companyname; ?></b>
                                    </div>
                                    <div class="col-xs-10 form-group">
                                        Model  :
                                    </div>
                                    <div class="col-xs-15">
                                        <b><?= $model[0]->model_name; ?></b>
                                    </div>
                                </div>
                                <div class="col-xs-50">
                                    <div class="col-xs-10 form-group">
                                        Variant  :
                                    </div>
                                    <div class="col-xs-15">
                                        <b><?= $var[0]->var_name; ?></b>
                                    </div>
                                    <?PHP
                                } else {
                                    ?>
                                    <div class="col-xs-50">
                                        <div class="col-xs-10 form-group">
                                            Make :
                                        </div>
                                        <div class="col-xs-15">
                                            <b><?= $this->input->post('newmake'); ?></b>
                                        </div>
                                        <div class="col-xs-10 form-group">
                                            Model  :
                                        </div>
                                        <div class="col-xs-15">
                                            <b><?= $this->input->post('newmodel'); ?></b>
                                        </div>
                                    </div>
                                    <div class="col-xs-50">
                                        <div class="col-xs-10 form-group">
                                            Variant  :
                                        </div>
                                        <div class="col-xs-15">
                                            <b><?= $this->input->post('newvariant'); ?></b>
                                        </div>    
                                        <?PHP
                                    }
                                    ?>
                                    <div class="col-xs-10 form-group">
                                        Registration number  :
                                    </div>
                                    <div class="col-xs-15">
                                        <b><?= $this->input->post('regno'); ?></b>
                                    </div>
                                </div>
                                <div class="col-xs-50">
                                    <div class="col-xs-10 form-group">
                                        Registration Date  :
                                    </div>
                                    <div class="col-xs-15">
                                        <b><?= $this->input->post('regdate'); ?></b>
                                    </div>
                                    <div class="col-xs-10 form-group">
                                        Current policy validity Date  :
                                    </div>
                                    <div class="col-xs-15">
                                        <b><?= $this->input->post('expdate'); ?></b>
                                    </div>
                                </div>
                                <div class="col-xs-50">
                                    <div class="col-xs-10 form-group">
                                        Model year  :
                                    </div>
                                    <div class="col-xs-15">
                                        <b><?= $this->input->post('modYear'); ?></b>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xs-45">
                                <div class="col-xs-15 form-group">
                                    <label class="name"  style=" line-height: 13px;" for="ph">Address:</label>
                                </div>
                                <div class="col-xs-32">
                                    <textarea name="ph" id="address" required class="form-control"></textarea>
                                </div>
                            </div>
                            <div class="col-xs-45">
                                <div class="col-xs-15 form-group">
                                    <label class="name"  style=" line-height: 13px;" for="location">location area</label>
                                </div>
                                <div class="col-xs-32">
                                    <input type='text' class="form-control" id="location" />
                                </div>
                            </div>
                            <div class="col-xs-45">
                                <div class="col-xs-15 form-group">
                                    <label class="name"  style=" line-height: 13px;" for="city">City</label>
                                </div>
                                <div class="col-xs-32">
                                    <input type='text' class="form-control" id="city" />
                                </div>
                            </div>
                            <div class="col-xs-45">
                                <div class="col-xs-15 form-group">
                                    <label class="name"  style=" line-height: 13px;" for="pin">Pin code</label>
                                </div>
                                <div class="col-xs-32">
                                    <input type="text" class="form-control" id="pin" placeholder="Pin Code"> 
                                </div>
                            </div>

                            <div class="col-xs-45">
                                <div class="col-xs-15 form-group">
                                    <label class="name"  style=" line-height: 13px;" for="date">Vehicle km</label>
                                </div>
                                <div class="col-xs-32">
                                    <input type="text" class="form-control" id="km" placeholder="Km Covered">
                                </div>
                            </div>
                            <div class="col-xs-45">
                                <div class="col-xs-15 form-group">
                                    <label class="name"  style=" line-height: 13px;" for="fual">Fuel type:</label>
                                </div>
                                <div class="col-xs-32">
                                    <input type="text" class="form-control" id="fual" placeholder="Fuel Type">
                                </div>
                            </div>
                            <div class="col-xs-45">
                                <div class="col-xs-15 form-group">
                                    <label class="name"  style=" line-height: 13px;" for="fual">Current company:</label>
                                </div>
                                <div class="col-xs-32">
                                    <input type="text" class="form-control" id="insu_cmp" placeholder="Current Insurance Company">
                                </div>
                            </div>
                           
                            <input id="fid" name="fid" type="hidden"  value="<?php echo $_POST['formid']; ?>" />
                            <div class="col-xs-45">
                                <div class="col-xs-15 form-group">
                                    <label class="name"  style=" line-height: 13px;" for="fual">Rc-book copy:</label>
                                </div>
                                <div class="col-xs-32">
                                    <input type="file" required="required" class="form-control" name="rc" />
                                </div>
                            </div>
                            
                            <div class="col-xs-45">
                                <div class="col-xs-15 form-group">
                                    <label class="name"  style=" line-height: 13px;" for="fual">Current insurance copy:</label>
                                </div>
                                <div class="col-xs-32">
                                    <input type="file"  class="form-control" name="incopy" />
                                </div>
                            </div>
                            <?PHP
                            if($this->input->post('vehicleType')==3){
                                ?>
                            <div class="col-xs-45">
                                <div class="col-xs-15 form-group">
                                    <label class="name"  style=" line-height: 13px;" for="fual">Tax receipt:</label>
                                </div>
                                <div class="col-xs-32">
                                    <input type="file" class="form-control" />
                                </div>
                            </div>
                                <?PHP
                            }
                            if(date('Y/m/d')>$this->input->post('expdate')){
                            ?>
                            <div class="col-xs-45 col-xs-offset-5"><p style="font-size: large;">Upload vehicle images</p></div>
                            <div class="col-xs-45">
                                <div class="col-xs-15 form-group">
                                    <label class="name"  style=" line-height: 13px;" for="fual">Front view image:</label>
                                </div>
                                <div class="col-xs-32">
                                    <input type="file" class="form-control" />
                                </div>
                            </div>
                            <div class="col-xs-45">
                                <div class="col-xs-15 form-group">
                                    <label class="name"  style=" line-height: 13px;" for="fual">Back view image:</label>
                                </div>
                                <div class="col-xs-32">
                                    <input type="file" class="form-control" />
                                </div>
                            </div>
                            <div class="col-xs-45">
                                <div class="col-xs-15 form-group">
                                    <label class="name"  style=" line-height: 13px;" for="fual">Right side image:</label>
                                </div>
                                <div class="col-xs-32">
                                    <input type="file" class="form-control" />
                                </div>
                            </div>
                            <div class="col-xs-45">
                                <div class="col-xs-15 form-group">
                                    <label class="name"  style=" line-height: 13px;" for="fual">Left side image:</label>
                                </div>
                                <div class="col-xs-32">
                                    <input type="file" class="form-control" />
                                </div>
                            </div>
                            
                            <?PHP                                
                            }
                            ?>
                            <center> <input type="button" id="submit" class="btn" name="Submit"  value="submit"></center>
                            
                        </div>
                       
                    </form>
                </div>

            </div>

        </div> 
    </div>
</div>