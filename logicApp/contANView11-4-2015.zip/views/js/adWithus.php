<script src="<?PHP echo JS_PATH; ?>jquery.js"></script>
<script src="<?= base_url() ?>assets/bs/js/bootstrap.min.js"></script>
<script>
    $(document).ready(function () {      
        $('.adBox').click(function () {
            
            $.ajax({
                url: "<?PHP echo base_url('ad/adRequest');?>"
            }).done(function (data) {
                $('#myModal').show();
                $('#myModal').find('.modal-body').html(data);
                return false;
            }).fail(function () {
                    alert("error");
                    //$('.progressdiv').hide();
                });
        });
    });
</script>