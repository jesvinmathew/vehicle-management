    <script src="<?= JS_PATH; ?>jquery.mobilemenu.js"></script>
    <!--[if (gt IE 9)|!(IE)]><!-->
    <script src="<?= JS_PATH; ?>jquery.mobile.customized.min.js"></script>
    <!--<![endif]-->
    <script src="<?= JS_PATH; ?>script.js"></script> 
    	<script src="<?= JS_PATH; ?>ddmenu.js"></script>
    <script src="<?= JS_PATH; ?>superfish.js"></script>
    <script src="<?= JS_PATH; ?>tmStickUp.js"></script>
    <script src="<?= JS_PATH; ?>jquery.ui.totop.js"></script>
    <script src="<?= JS_PATH; ?>camera.js"></script>
    
    <script src="<?= JS_PATH; ?>jquery-migrate-1.1.1.js"></script>
    <script src="<?= JS_PATH; ?>jquery.equalheights.js"></script>
    <script src="<?=JS_PATH; ?>jquery.easing.1.3.js"></script>
    <script src="<?= JS_PATH; ?>booking.js"></script>
    <script src="<?= JS_PATH; ?>jPages.js"></script>
    <script type="text/javascript" src="<?= JS_PATH; ?>jquery.easing.min.js"></script>
    <script type="text/javascript" src="<?= JS_PATH; ?>jquery.easy-ticker.js"></script>
    <script type="text/javascript" src="<?= JS_PATH; ?>jquery.tools.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
        	$("#addhed1").click(function (){
	           $("#adDivHed").show();
	        });
	        $(".adclose").click(function(){
	            $("#adDivHed").hide();
	        });
	        $("#addhed2").click(function (){
	        	$("#adDivHed2").show();
	        });
	        $(".adclose2").click(function(){
	            $("#adDivHed2").hide();
	        });
            function getdata(path,value1,value2,value3){
                var opt="";
                var postData={};
                postData.value1=value1;
                postData.value2=value2;
                $.ajax({
                    url:"<?PHP echo site_url('json');?>/"+path,
                    type:'post',
                    dataType:'json',
                    data:postData
                }).done(function(data){

                    var i=0;
                    while(i<data.i){
                        i++;
                        $('#' + value3).append('<option value="' + data.id[i] + '">' + data.content[i] + '</option>');
                    }
                    return(1);
                });
            }
            getdata('getcompany', 1, 0,"bikeCompany");
            getdata('getcompany', 2, 0,"carCompany");
              getdata('getfuel', 0, 0,"fueltype");
               $('#submitbike').click(function(){
                event.preventDefault();
                window.location.replace('<?=base_url()?>welcome/search/used/bike?company='+$('#bikeCompany').val()+'&fueltype='+$('#bikefuel').val())
              });
              $('#submitcar').click(function(){
                 event.preventDefault();
                window.location.replace('<?=base_url()?>welcome/search/used/car?company='+$('#carCompany').val()+'&fueltype='+$('#fueltype').val())
              });
        });
        function mylink(){
        	alert("");
        }
    </script>