 
<link rel="stylesheet" href="<?=base_url()?>assets/bs/css/bootstrap.css"/>
<!--  --><link rel="stylesheet" href="<?PHP echo CSS_PATH; ?>style.css"/>
<link rel="stylesheet" href="<?PHP echo CSS_PATH; ?>stuck.css"/>
<link rel="stylesheet" href="<?PHP echo CSS_PATH; ?>menu.css"/>