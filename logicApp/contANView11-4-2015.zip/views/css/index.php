<link rel="stylesheet" href="<?PHP echo CSS_PATH; ?>camera.css"/>
<link rel="stylesheet" href="<?PHP echo CSS_PATH; ?>jPages.css"/>
<style>
    .mainbox {
        border: 1px solid rgba(0, 0, 0, 0.18);
        background-color: rgba(236, 236, 236, 0.6);
        margin: 20px 0 20px 0;

    }
    .borderBox {
        border: 1px solid #CCC;
        background: #CCC;
    }
    #adDivHed{
	  display: none;
	  overflow: hidden;
	  position: absolute;
	  z-index: 50;
	  outline: 0;
    }
    #adDivHed2{
	  display: none;
	  overflow: hidden;
	  position: absolute;
	  z-index: 50;
	  outline: 0;
    }
</style>