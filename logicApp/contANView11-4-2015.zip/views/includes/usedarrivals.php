<section>
	<p>
    	<div class="holder3"></div>
      	<hr>
        <div class="clear"></div>
        <?php $this->load->view('includes/usedarrivalscars.php'); ?>          
        <div class="clear"></div>
        <br>
       	<hr>
      	<div class="holder3"></div>
      	<hr>
   	</p>
</section>
<section>
  	<p>
    	<div class="holder4"></div>
      	<hr>
        <div class="clear"></div>
        <?php $this->load->view('includes/usedarrivalsbikes.php'); ?>
        <div class="clear"></div>
        <br>
       	<hr>
      	<div class="holder4"></div>
      	<hr>
   	</p>
</section>