<section>
  <p>
    <div class="holder"></div>
      <hr>
        <div class="clear"></div>
          <?php $this->load->view('includes/newarrivalscars.php'); ?>
          
        <div class="clear"></div>
         <br>
       <hr>
      <div class="holder"></div>
      <hr>
   </p>
</section>
<section>
  <p>
    <div class="holder1"></div>
      <hr>
        <div class="clear"></div>
          <?php $this->load->view('includes/newarrivalsbikes.php'); ?>
        <div class="clear"></div>
         <br>
       <hr>
      <div class="holder"></div>
      <hr>
   </p>
</section>
<section>
  <p>
    <div class="holder2"></div>
      <hr>
        <div class="clear"></div>
          <?php $this->load->view('includes/newarrivalsaccessories.php'); ?>
        <div class="clear"></div>
         <br>
       <hr>
      <div class="holder"></div>
      <hr>
   </p>
</section>
  