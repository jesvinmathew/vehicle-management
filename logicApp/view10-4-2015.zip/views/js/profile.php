<script>                
    $(document).ready(function(){
        $("#proPic").hide();
        $("#changePicture").click(function(){
           $("#proPic").show(); 
        });
    });    
</script>