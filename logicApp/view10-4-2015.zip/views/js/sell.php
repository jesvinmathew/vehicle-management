<?PHP
    if (!isset($_POST['submitHandler'])){
        ?>
        <script src="<?PHP echo JS_PATH; ?>jquery.js"></script>
        <script src="<?PHP echo JS_PATH; ?>multiupload.js"></script>
        <?php
     }
 ?>
 <script>
    $(function () {
        var calendar = $.calendars.instance('persian');
        $('#edate').calendarsPicker({calendar: calendar});
        var calendar = $.calendars.instance('persian');
        $('#inlineDatepicker').calendarsPicker({calendar: calendar, onSelect: showDate});
    });
</script>