<link rel="stylesheet" href="<?= BS_PATH?>css/bootstrap.css"/>
<link rel="stylesheet" href="<?= CSS_PATH; ?>hotstyle.css"/>
<link rel="stylesheet" href="<?PHP echo CSS_PATH; ?>style.css"/>
<link rel="stylesheet" href="<?= CSS_PATH; ?>menu.css"/>