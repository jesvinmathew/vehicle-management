 
<link rel="stylesheet" href="<?= CSS_PATH; ?>hotindex.css"/>