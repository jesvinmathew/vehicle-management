<style>

.thumbnail div{
    height:140px;
    background-size: cover;
    background-position: center;
}
.box{
    padding: 4px 4px;
}
.thumbnail{
    margin-bottom: 0px; 
}
.disabled
{
    display:none !important;
}
a.distSelect{
	color:#f00;
}
</style>