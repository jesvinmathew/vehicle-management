<div class="col-xs-48 col-xs-offset-1">
    <div class="col-xs-50">
        <div class="col-xs-50 col-md-35">
            <div class="h1">Advertisement Details :</div>
            <div class="row1 col-xs-50">
                <div class="col-xs-40">
                    <div class="h2 box11">Slider Advertisement :</div>
                    <div class="h3 box21">Home Page</div>
                    <div class="h4 box31">Number with priority :2 same <br/>
                        Dimension: 370*301  <br/>
                        Supported types: png, jpg  <br/>
                        Number of images in each block :3-7
                   </div>
                </div>
                <div class="col-xs-10">
                    <img src="<?=IMAGES_PATH ?>row1.png"style="float: right;" />
                </div>
                
                <div class="box41 col-xs-10">
                    <br><br>
                    <a href="<?=site_url('ad/adRequest');?>"><img src="<?= IMAGES_PATH ?>contact.png" width="103" height="38" alt="contact"></a>
                </div>

            </div>
            <div class="row2 col-xs-50">
                <div class="col-xs-50">
                    <div class="h2 box11">Banner Advertisement :</div>
                    <div class="h3 box21">Home Page</div>
                </div>
                <div class="h4 box21 col-xs-50">Number with priority :1 Top<br/>
                    Dimension: 1200*130(small changes accepted)<br/>
                </div>
                <div class="h4 box31 col-xs-40">
                    Supported types: jpg, png, gif.<br/>
                    Number of images in each block :1
                </div>
                <div class="box41 col-xs-10">
                    <a href="#" class="adBox"><img src="<?= IMAGES_PATH ?>contact.png" width="103" height="38" alt="contact"></a>
                </div>
            </div>
            <div class="row1 col-xs-50">
                <div class="col-xs-50">
                    <div class="h2 box11">Banner Advertisement :</div>
                    <div class="h3 box21">View Page</div>
                    <div class="h4_copy box21">Number with priority :2 Top and Bottom <br/>
                        Dimension: 1200*130(small changes accepted)<br/>
                        Supported types: jpg, png, gif.<br/>
                    </div>
                </div>
                <div class="h4_copy box21 col-xs-40">
                    Number of images in each block :1<br/>
                    View with pages: about, Selling tips, Teams,  etc.
                </div>
                <div class="box41 col-xs-10"><a href="#"><img src="<?= IMAGES_PATH ?>contact.png" width="103" height="38" alt="contact"></a></div>

            </div>
            <div class="row2 col-xs-50">
                <div class="col-xs-50">
                    <div class="h2 box11">Banner Advertisement :</div>
                    <div class="h3 box21">Search Page</div>
                    <div class="h4_copy box21">Number with priority :2 Top and Bottom<br/> 
                        Dimension: 1200*130(small changes accepted)<br/>
                        Supported types: jpg, png, gif.<br/>
                    </div>
                </div>
                <div class="h4_copy box31 col-xs-40">
                    Number of images in each block :1<br/>
                    View with pages: search, used bike, used car, new car, new bike  etc.
                </div>
                <div class="box41 col-xs-10"><a href="#"><img src="<?= IMAGES_PATH ?>contact.png" width="103" height="38" alt="contact"></a></div>

            </div>
            <div class="row1 col-xs-50">
                <div class="col-xs-50">
                    <div class="h2 box11">Banner Advertisement :</div>
                    <div class="h3 box21">All other pages (About Us, Sell car, Buy car, User plans, Selling tips, Sell bike, <br/>Buy bike, New car, New bike, Car loans. EMI calculator, Terms)</div>
                    <div class="h4 box21">Number with priority :2 Top and Bottom <br/>
                        Dimension: 1200*130(small changes accepted)<br/>
                    </div>
                </div>
                <div class="h4_copy box31 col-xs-40">
                    Supported types: jpg, png, gif.<br/>
                    Number of images in each block :1
                </div>
                <div class="box41 col-xs-10"><a href="#"><img src="<?= IMAGES_PATH ?>contact.png" width="103" height="38" alt="contact"></a></div>

            </div>
            <div class="row2 col-xs-50">
                <div class="col-xs-50">
                    <div class="h2 box11">Video Advertisement :</div>
                    <div class="h3 box21">Search and Insurance Page</div>
                    <div class="h4 box21">Number with priority :1<br/>
                        Dimension: 320px × 320px<br/>
                    </div>
                </div>
                <div class="h4_copy box31 col-xs-40">
                    Supported types: mp4,youtube 
                </div>
                <div class="box41 col-xs-10"><a href="#"><img src="<?= IMAGES_PATH ?>contact.png" width="103" height="38" alt="contact"></a></div>

            </div>

        </div>
    </div>
</div>