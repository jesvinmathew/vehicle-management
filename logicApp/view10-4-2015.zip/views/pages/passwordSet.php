<div class="col-xs-48 col-xs-offset-1">
    <div class="col-xs-50">
        <div class="page1_block1">
            <img src="<?= IMAGES_PATH . '/ad.jpg'; ?>" />
        </div>
    </div>
    <div class="col-xs-50">

        <center><h2>Password Changing</h2></center>
        <div class="col-xs-25">
            <form method="post">
            <div class="col-xs-12 form-group">
                <label class="name"  style=" line-height: 13px;" for="newPass">New Password:</label>
            </div>
                <div class="col-xs-30"> <input placeholder="New Password" required="required" name="newPass"  id="newPass" class="text form-control" type="password" />
            </div>
            <div class="clear"></div>
            <div class="col-xs-12 form-group">
                <label class="name"  style=" line-height: 13px;" for="cnewPass">Conform new password:</label>
            </div>
            <div class="col-xs-30"> <input placeholder="Conform New Password" required="required" name="cnewPass" id="cnewPass" class="text form-control" type="password" />
            </div>
            <div class="clear"></div>
            <input type="submit" class="btn" />
            </form>
        </div>
    </div>
    <div class="col-xs-50">
        <div class="page1_block1">
            <img src="<?= IMAGES_PATH . '/ad.jpg'; ?>" />
        </div>
    </div>
</div>