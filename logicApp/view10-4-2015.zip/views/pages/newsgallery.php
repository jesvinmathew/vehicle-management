<div class="col-xs-30" id="slider">
		
	</div>
	<div class="col-xs-20">
		<div class="col-xs-50">
		<br />
		</div>
		<img src="/assets/images/advertisement/ad_right22.png" class="col-xs-48 col-lg-offset-1"></img>
	</div>
<div class="col-xs-50">
	
	<div class="col-xs-12">
	<div class="image_stack" onclick="getSlider(<?=$name[0]->news_id;?>);">
	<?php 
		$i=$name[0]->news_id;
		$j=1;
		
		foreach($name as $nimag){
			if($i!=$nimag->news_id){
				$i=$nimag->news_id;
				$j=1;
				?>
				</div>
				</div>
				<div class="col-xs-12">
				<div class="image_stack"  onclick="getSlider(<?=$i;?>);">
				<?PHP
			}
			if($j>3){
			continue;}
			?>
			<img id="photo<?= $j; ?>" class="stackphotos" src="<?= UPLOAD_PATH.'news/'.$nimag->name ; ?>"  >
			<?PHP
			$j++;
		}
	?>
        </div>
        </div>
</div>