<script type="text/javascript">
    $(document).ready(function () {
        $(".vehiDat").hide();
        $(".vehiType").click(function () {
            $(".vehiDat").hide();
            $("#" + $(this).attr('data-filed')).show();
            $("#" + $(this).attr('data-fill')).show();
        });
        $(".companyName").change(function () {
            var postData = {};
            postData.value1 = $(this).val();
            $.ajax({
                url: "<?PHP echo site_url('newjson'); ?>/getmodel",
                type: 'post',
                dataType: 'json',
                data: postData
            }).done(function (data) {
                $('#model').html('<option value="0">Select</option>');
                $.each(data, function (index, value) {
                    $('#model').append('<option value="' + value.content + '">' + value.content + '</option>');
                });
            });
        });

        /* $("#sentMail").click(function () {
         var msg = "";
         if ($("#fullName").val()) {
         msg += "fullname:" + $("#fullName").val() + "<br />";
         }
         else {
         alert("Please Fill fullname");
         return false;
         }
         if ($("#address").val()) {
         msg += "address:" + $("#address").val() + "<br />";
         }
         else {
         alert("Please Filla address");
         return false;
         }
         if ($("#mobileNo").val()) {
         msg += "mobileno:" + $("#mobileNo").val() + "<br />";
         }
         else {
         alert("Please Fill mobile number");
         return false;
         }
         if ($("#landNo").val()) {
         msg += "landno:" + $("#landNo").val() + "<br />";
         }
         else {
         alert("Please Fill Land number");
         return false;
         }
         if ($("#district").val()) {
         msg += "district:" + $("#district option:selected").text() + "<br />";
         }
         else {
         alert("Please Fill district");
         return false;
         }
         if ($("#pinCode").val()) {
         msg += "pincode:" + $("#pinCode").text() + "<br />";
         }
         else {
         alert("Please Fill pincode");
         return false;
         }
         if ($("#emailId").val()) {
         msg += "emailId:" + $("#emailId").val() + "<br />";
         }
         else {
         alert("Please Fill emailId");
         return false;
         }
         if ($("#place").val()) {
         msg += "place:" + $("#place").val() + "<br />";
         }
         else {
         alert("Please Fill place");
         return false;
         }
         if ($("#selectresidence").val()) {
         msg += "rsidence type:" + $("#selectresidence option:selected").text() + "<br />";
         }
         else {
         alert("Please Fill residence type");
         return false;
         }
         if ($("#tYear").val()) {
         msg = "Transfer to current place year:" + $("#tYear option:selected").text() + "<br />";
         }
         else {
         alert("Please Fill transfer year");
         return false;
         }
         if ($("#tMonth").val()) {
         msg = "Transfer to current place month:" + $("#tMonth option:selected").text() + "<br />";
         }
         else {
         alert("Please Fill transfer month");
         return false;
         }
         if ($("#dob").val()) {
         msg += "date of birth:" + $("#dob").val() + "<br />";
         }
         else {
         alert("Please Fill date of birth");
         return false;
         }
         if($('#newb').is(':checked')){
         if ($("#bike").val()) {
         msg += "companyname:" + $("#bike option:selected").text() + "<br />";
         }
         else {
         alert("Please Fill  companyname");
         return false;
         }
         }
         if($('#newc').is(':checked')){
         if ($("#car").val()) {
         msg += "companyname:" + $("#car option:selected").text() + "<br />";
         }
         else {
         alert("Please Fill  companyname");
         return false;
         }
         }
         if($('#usedc').is(':checked')){
         if ($("#companyName1").val()) {
         msg += "companyname:" + $("#companyName1 option:selected").text() + "<br />";
         }
         else {
         alert("Please Fill  companyname");
         return false;
         }
         }
         if($('#usedb').is(':checked')){
         if ($("#companyName1").val()) {
         msg += "companyname:" + $("#companyName1 option:selected").text() + "<br />";
         }
         else {
         alert("Please Fill  companyname");
         return false;
         }
         
         }
         if ($("#selectemploy").val()) {
         msg += "employment type:" + $("#selectemploy option:selected").text() + "<br/>";
         }
         else {
         alert("Please Fill employment type");
         return false;
         }
         if ($("#loanAmount").val()) {
         msg = "Loan Amount:" + $("#loanAmount").val() + "<br />";
         }
         else {
         alert("Please Fill Amount");
         return false;
         }
         if ($("#anualIncome").val()) {
         msg += "anual income:" + $("#anualIncome").val() + "<br />";
         }
         else {
         alert("Please Fill Amount");
         return false;
         }
         if ($("#selectbank").val()) {
         msg += "bank:" + $("#selectbank").val() + "<br />";
         }
         else {
         alert("Please Fill bank");
         return false;
         }
         var postdata = {};
         postdata.msg = msg;
         $.ajax({
         url: "<?= site_url('background'); ?>/enquLone",
         type: 'post',
         dataType: 'html',
         data: postdata
         }).done(function (data) {
         alert(data);
         });
         });*/
    });

</script>
<div class="col-xs-48 col-xs-offset-1">
    <div class="col-xs-50">
        <div class="page1_block1">
            <?PHP
            $this->db->where_in('loc', array('52', '53'));
            $this->db->order_by('loc', 'ASC');
            $add = $this->db->get('add')->result();
            foreach ($add as $ad) {
                if (isset($ad->img_path1)) {
                    ?>
                    <a href="<?= $ad->link; ?>"><img src="<?= IMAGES_PATH . "advertisement/" . $ad->img_path1; ?>" class="col-xs-23 col-xs-offset-1"/></a>
                    <?php
                }
            }
            ?>
        </div>
    </div>
    <div class="col-xs-50">
        
            <div class="box2 col-xs-35">
                <div class=" col-xs-35">
                <form class="blocks" method="post" id="form" enctype="multipart/form-data">
                    <center><h2>Apply vehicle loan</h2></center>

                    <div class="col-xs-9 col-xs-offset-1 "><b>* Loan needed for:</b></div>
                    <div class="col-xs-10">
                        <input type="radio"  id="newc" class="vehiType" data-fill="newVmod" data-filed="newCmake" name="vehiType"  value="1">New Car
                    </div>
                    <div class="col-xs-10">
                        <input type="radio" id="newb" class="vehiType" data-fill="newVmod" data-filed="newBmake" name="vehiType" value="2"> New bike
                    </div>
                    <div class="col-xs-10">
                        <input type="radio" id="usedc" class="vehiType" data-fill="usedVmod" name="vehiType" data-filed="usedVmake" value="3">Pre owned car
                    </div>
                    <div class="col-xs-10">
                        <input type="radio" id="usedb" class="vehiType" data-fill="usedVmod" name="vehiType" data-filed="usedVmake"  value="4"> Pre owned bike
                    </div>

                    <div class="col-xs-9 col-xs-offset-1">
                        <label class="name"  style=" line-height: 13px;" for="fullName">Sex</label>
                    </div>

                    <div class="col-xs-15">
                        <input type="radio" id="male"   name="sex"   value="male">Male
			<input type="radio" id="female"   name="sex"   value="female">Female
                    </div>
                    <div class="col-xs-48 form-group col-xs-offset-1" style=" padding: 5px;">
                        <div class="col-xs-50">
                          <p><b><u>Personal details:</u></b></p>  
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="fullName">Full name</label>
                            </div>
                            <div class="col-xs-40"> 
                                <input type="text" placeholder="Full name"  required="required"  id="fullName" name="fullName" class="text form-control" type="email" />
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="mobileNo">Mobile no</label>
                            </div>
                            <div class="col-xs-40"> 
                                <input type="text" placeholder="Mobile no"  required="required"  id="mobileNo" name="mobileNo" class="text form-control" type="email" />
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="emailId">Email id</label>
                            </div>
                            <div class="col-xs-40"> 
                                <input type="email" placeholder="Email id"  required="required"  id="emailId" name="emailId" class="text form-control" type="email" />
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="loanAmount">Current address</label>
                            </div>
                            <div class="col-xs-40">
                                <textarea  placeholder="Address"  required="required"  id="caddress" name="caddress" class="text form-control"></textarea>
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="district">District</label>
                            </div>
                            <div class="col-xs-40"> 
                                <select name="cdistrict" class="tmSelect auto form-control" required="required" style="line-height:13px;" id="cdistrict" data-class="tmSelect tmSelect2" data-constraints="">
                                    <option value="0">Select district</option>
                                    <?PHP
                                    foreach ($district as $dis) {
                                        echo "<option value='$dis->placename'>$dis->placename</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="loanAmount">Permanent address</label>
                            </div>
                            <div class="col-xs-40">
                                <textarea  placeholder="Address"  required="required"  id="paddress" name="paddress" class="text form-control"></textarea>
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="district">District</label>
                            </div>
                            <div class="col-xs-40"> 
                                <select name="pdistrict" class="tmSelect auto form-control" required="required" style="line-height:13px;" id=pdistrict"" data-class="tmSelect tmSelect2" data-constraints="">
                                    <option value="0">Select district</option>
                                    <?PHP
                                    foreach ($district as $dis) {
                                        echo "<option value='$dis->placename'>$dis->placename</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="mobileNo">Land no</label>
                            </div>
                            <div class="col-xs-40"> 
                                <input type="text" placeholder="Land no"  required="required"  id="landNo" name="landNo" class="text form-control" type="email" />
                            </div>
                        </div>
                        
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="dob">D.O.B</label>
                            </div>
                            <div class="col-xs-40"> 
                                <input type="date" placeholder="Date of birth"  required="required"  id="dob" name="dob" class="text form-control" type="date" />
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="mobileNo">Pin code</label>
                            </div>
                            <div class="col-xs-40"> 
                                <input type="number" placeholder="Pin code"  required="required"  id="pinCode" name="pinCode" class="text form-control" type="email" />
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="selectresidence">Residence type</label>
                            </div>
                            <div class="col-xs-40"> 
                                <select name="residence" class="tmSelect auto form-control" required="required" style="line-height:13px;" id="selectresidence" data-class="tmSelect tmSelect2" data-constraints="">
                                    <option value="">Select residence type</option>
                                    <option value="Owned by self/spouse">Owned by self/spouse</option>
                                    <option value="Owned by parents/siblings">Owned by parents/siblings</option>
                                    <option value="Rented-with family">Rented-with family</option>
                                    <option value="Rented-with friends">Rented-with friends</option>
                                    <option value="Rented-staying alone">Rented-staying alone</option>
                                    <option value="Paying guest">Paying guest</option>
                                    <option value="Hostel">Hostel</option>
                                    <option value="Company provided">Company provided</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="loanAmount">When did you move to current residence</label>
                            </div>
                            <div class="col-xs-40">
                                <select name="tYear" class="select required form-control" required="required" id="tYear">
                                    <option value="0" selected="selected">Please select transfer year</option>
                                    <?php
                                    $i = 2014;
                                    while ($i >= 1920) {
                                        echo '<option value="' . $i . '">' . $i . '</option>';
                                        $i--;
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="dob">When did you move to current residence</label>
                            </div>
                            <div class="col-xs-40"> 
                                <select name="tMonth" class="select required form-control" required="required" id="tMonth">
                                    <option value="" selected="selected">Please select transfer month</option>
                                    <option value="january" >January</option>
                                    <option value="February" >February</option>
                                    <option value="March">March</option>
                                    <option value="April" >April</option>
                                    <option value="May" >May</option>
                                    <option value="June" >June</option>
                                    <option value="July" >July</option>
                                    <option value="August">August</option>
                                    <option value="September" >September</option>
                                    <option value="October" >October</option>
                                    <option value="November" >November</option>
                                    <option value="December" >December</option>
                                </select> 
                            </div>
                        </div>
                        
                    </div>

                    <hr style=" color:  brown">

                    <div class="col-xs-48 form-group col-xs-offset-1" style=" padding: 5px;">

                    <div class="col-xs-50">
                          <p><b><u>Proffessional details:</u></b></p>  
                        </div>
                        <div class="col-xs-24 form-group vehiDat" id="newCmake">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;">Make</label>
                            </div>
                            <div class="col-xs-40"> 
                                <select name="newmakeC" class="companyName tmSelect auto form-control"  style="line-height:13px;" id="car" data-class="tmSelect tmSelect2" data-constraints="">
                                    <option value="">Select make</option>
                                    <?PHP
                                    foreach ($Cbrands as $brand)
                                        echo "<option value='$brand->cmp_id'>$brand->companyname</option>";
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-24 form-group vehiDat" id="newBmake">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="companyName">Make</label>
                            </div>
                            <div class="col-xs-40"> 
                                <select name="newmakeB" class="companyName tmSelect auto form-control"  style="line-height:13px;" id="bike" data-class="tmSelect tmSelect2" data-constraints="">
                                    <option value="">Select make</option>
                                    <?PHP
                                    foreach ($Bbrands as $brand)
                                        echo "<option value='$brand->cmp_id'>$brand->companyname</option>";
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-24 form-group vehiDat" id="usedVmake">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="fullName">Make</label>
                            </div>
                            <div class="col-xs-40"> 
                                <input type="text" placeholder="Type make"    id="companyName1" name="usedmake" class="text form-control" type="email" />
                            </div>
                        </div>
                        <div class="col-xs-24 form-group vehiDat" id="usedVmod">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="fullName">Model</label>
                            </div>
                            <div class="col-xs-40"> 
                                <input type="text" placeholder="Type model"  id="model1" name="usedmodel" class="text form-control" type="email" />
                            </div>
                        </div>
                        <div class="col-xs-24 form-group vehiDat" id="newVmod">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="companyName">Model</label>
                            </div>
                            <div class="col-xs-40"> 
                                <select name="newmodel" class="tmSelect auto form-control" style="line-height:13px;" id="model" data-class="tmSelect tmSelect2" data-constraints="">
                                    <option value="">Select model type</option>                    
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="selectemploy">Type of employment</label>
                            </div>
                            <div class="col-xs-40"> 
                                <select name="employ" class="tmSelect auto form-control" required="required" style="line-height:13px;" id="selectemploy" data-class="tmSelect tmSelect2" data-constraints="">
                                    <option value="">Select type</option>
                                    <option value="Salaried">Salaried</option>
                                    <option value="Self employed business">Self employed business</option>
                                    <option value="Self employed proffessional">Self employed proffessional</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="loanAmount">Loan amount</label>
                            </div>
                            <div class="col-xs-40"> 
                                <input type="number" placeholder="Loan amount" required="required"   id="loanAmount" name="loanAmount" class="text form-control" type="email" />
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="anualIncome">Annual income</label>
                            </div>
                            <div class="col-xs-40"> 
                                <input type="number" placeholder="Annual income"  required="required"  id="anualIncome" name="anualIncome" class="text form-control" type="email" />
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="selectbank">Select bank</label>
                            </div>
                            <div class="col-xs-40"> 
                                <select name="bank" class="tmSelect auto form-control" required="required" style="line-height:13px;" id="selectbank" data-class="tmSelect tmSelect2" data-constraints="">
                                    <option value="">Select bank</option>
                                    <option value="HDFC">HDFC bank</option>
                                    <option value="SBT">SBT bank</option>
                                    <option value="SBI">SBI bank</option>
                                    <option value="Axis">Axis bank</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="anualIncome">Upload pancard copy (max-size 5 mb)</label>
                            </div>
                            <div class="col-xs-40"> 
                                <input  class="form-control" name="pancard" id="image" type="file"   />
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="anualIncome">Upload address proof (max-size 5 mb)</label>
                            </div>
                            <div class="col-xs-40"> 
                                <input  class="form-control" name="addrproof" id="image" type="file"   />
                            </div>
                        </div>
                        <div class="col-xs-24 form-group">
                            <div class="col-xs-40">
                                <label class="name"  style=" line-height: 13px;" for="anualIncome">Statements of 3 month income(max-size 5 mb)</label>
                            </div>
                            <div class="col-xs-40"> 
                                <input   class="form-control"  name="salaryStmnt" id="image" type="file"   />
                            </div>
                        </div>
                    </div>
                    <div class="clear"></div>
                    <div class="col-xs-40">
                        <p>Vehicle Booked: <input type="radio"  name="select" value="3"> Yes
                            <input type="radio" name="select" value="4"> No</p>
                    </div>
                    <div class="col-xs-50">
			<input type = "checkbox"
                               id = "chk"
                               value = "checkbox" required="required" /> I declare that the information I have provided above is accurate and complete to the best of my knowledge.I authorize Keralaonroad its representatives to call or sms me with reference to my loan application as per our <a href="<?= site_url('welcome/view/privacy-policy'); ?>">privacy policy</a> and<a href="<?= site_url('welcome/view/terms-and-conditions'); ?>"> Terms and conditions</a>
                    </div>
                    <div class="col-xs-20">
                        <input type="submit" name="submit" id="sentMail" value="Submit" class="btn" />
                    </div>
                    </form>
                </div>
                
                <div class="col-xs-15" style="padding-top: 75px;">
    	<?PHP 
            
              $this->db->where_in('loc', array('104', '105'));
              $this->db->order_by('loc', 'ASC');
              $add = $this->db->get('add')->result();
              foreach($add as $ad){
              if(isset($ad->img_path1)){
                        ?>
        <a href="<?=$ad->link;?>"><img src="<?= IMAGES_PATH . "advertisement/" . $ad->img_path1; ?>" style="margin: 20px 0 20px 0"/></a>
          <?php }
                     }
                ?>
    </div>
                <div class="clear"></div>
        
    </div>
</div>

<div class="col-xs-50">
    <div class="page1_block1">
        <?PHP
        $this->db->where('loc', 45);
        $this->db->order_by('loc', 'ASC');
        $add = $this->db->get('add')->result();
        if (isset($add[0]->img_path1)) {
            ?>
            <a href="<?= $add[0]->link; ?>"><img src="<?= IMAGES_PATH . "advertisement/" . $add[0]->img_path1; ?>" class="col-xs-48 col-xs-offset-1"/></a>
            <?php } ?>
    </div>
</div>
</div>
