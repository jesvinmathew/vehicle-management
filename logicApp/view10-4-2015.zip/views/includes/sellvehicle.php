<script type = "text/javascript">
    $(document).ready(function () {
        getdata('getcompany', $('#vehicletype').val(), 0);
        function getdata(path, value1, value2){
            var postData = {};
            postData.value1 = value1;
            postData.value2 = value2;
            $.ajax({
                url: "<?PHP echo site_url('json'); ?>/" + path,
                type: 'post',
                dataType: 'json',
                data: postData
            }).done(function (data) {
                var i = 0;
                while (i < data.i)
                {
                    i++;
                    $('#' + data.ids).append('<option value="' + data.id[i] + '">' + data.content[i] + '</option>');
                }
            });
        }
        $('#vehicletype').blur(function () {
            if ($('#vehicletype').val() !== 0){
                $('#company').html('');
                $('#model').html('');
                $('#variant').html('');
                getdata('getcompany', $(this).val(), 0);
            }
        });
        $('#company').blur(function (){
            if ($(this).val() !== 0){
                $('#model').html('');
                $('#variant').html('');
                getdata('getmodel', $(this).val(), 0);
            }
        });
        $('#model').blur(function () {

            if ($(this).val() !== 0){
                $('#variant').html('');
                getdata('getvariant', $(this).val(), 0);
            }
        });
        $('#submitHandler').click(function () {
            $(this).text('Uploading please wait');
        });
        console.log('jquery ok');
        $('#sendinformation').attr('type', 'button');
        var postData = {};
        postData['adtitle'] = '';
        postData['vehicletype'] = '';
        postData['brandname'] = '';
        postData['Mileage'] = '';
        postData['model'] = '';
        postData['cartype'] = '';
        postData['Fuel'] = '';
        postData['condition'] = '';
        postData['Transmission'] = '';
        postData['Odometer'] = '';
        postData['textarea'] = '';
        postData['price'] = '';
        postData['inr'] = '';
        postData['vehicleauth'] = '';
        $.extend({}, postData);

        var error = {};
        $('.required').blur(function () {
            var variable = $(this).attr('id');
            if ($(this).val().length <= 0) {
                $(this).parent('div').children('.alert').remove();
                $(this).parent('div').append('<div class="alert">This field is required</div>').children('.alert').css('background-color', 'red');
                error[variable] = true;
                $.extend({}, error);
            } else {
                $(this).parent('div').children('.alert').css('background-color', 'green').text('Its Ok').fadeOut(3000);
                var variable = $(this).attr('id');
                postData[variable] = $(this).val();
                $.extend({}, postData);
                error[variable] = false;
                $.extend({}, error);
            }
        });
        $('.nonmand').change(function () {
           
                $(this).parent('div').children('.alert').css('background-color', 'green').text('Its Ok').fadeOut(3000);
                var variable = $(this).attr('id');
                postData[variable] = $(this).val();
                $.extend({}, postData);
                error[variable] = false;
                $.extend({}, error);
            
        });
        

        $('.select').change(function () {
            console.log($(this).val());
            if ($(this).val() <= 99) {
                $(this).parent('div').children('.alert').remove();
                $(this).parent('div').append('<div class="alert">This field is required</div>').children('.alert').css('background-color', 'red');
                error[variable] = true;
                $.extend({}, error);

            } else {
                $(this).parent('div').children('.alert').css('background-color', 'green').text('Its Ok').fadeOut(3000);
                var variable = $(this).attr('id');
                postData[variable] = $(this).val();
                $.extend({}, postData);
                error[variable] = false;
                $.extend({}, error);
            }
        });
        $('.number').change(function () {
            alert("");
            if ($(this).val() <= 0) {
                $(this).parent('div').children('.alert').remove();
                $(this).parent('div').append('<div class="alert">This field is required</div>').children('.alert').css('background-color', 'red');
                error[variable] = true;
                $.extend({}, error);
            } else {
                $(this).parent('div').children('.alert').css('background-color', 'green').text('Its Ok').fadeOut(3000);
                var variable = $(this).attr('id');
                postData[variable] = $(this).val();
                $.extend({}, postData);
                error[variable] = false;
                $.extend({}, error);
            }
            if ($(this).val() <= 0) {
                $(this).parent('div').children('.alert').remove();
                $(this).parent('div').append('<div class="alert">This field is required</div>').children('.alert').css('background-color', 'red');
                error[variable] = true;
                $.extend({}, error);

            } else {
                $(this).parent('div').children('.alert').css('background-color', 'green').text('Its Ok').fadeOut(3000);
                var variable = $(this).attr('id');
                postData[variable] = $(this).val();
                $.extend({}, postData);
                error[variable] = false;
                $.extend({}, error);
            }
        });
        $('#sendinformation').click(function () {
            $.ajax({
                url: "<?= base_url() ?>json/addvehicle",
                type: 'post',
                dataType: 'json',
                data: postData
            }).done(function (data) {
                alert(data.message);
                if (data.error === true){
                    $('#' + data.id).parent('div').append('<div class="alert">' + data.message + '</div>').children('.alert').css('background-color', 'red');
                }
                else
                if (data.error === false){
                    $('#sendinformation').val(data.message).attr('id', 'uploadimage');
                    $('#vehicleimage').fadeIn(3000);
                    $('#upload_id').val(data.id);
                    $("html, body").animate({scrollTop: 0}, 5000);
                }
            });
        });
    });

</script>

        <div class="col-xs-48 col-xs-offset-1">
            <ul>

                <?php
                $display = 'none';
                $formdisplay = 'block';
                $value;
                if (isset($_POST['submitHandler'])) {
                    $value;
                    echo $error;
                    if ($value != '') {
                        $display = 'block';
                    }
                    $formdisplay = 'none';
                    ?>
                    <p><?php echo anchor('#', 'You can Upload Another File for same vehicle without refresh this page'); ?></p>
                    <?php
                }
                ?>
            </ul>




            <div class="row" id="vehicleimage" style="display: <?= $display ?>;">

                <div class="grid_12">

                    <h2>

                        Post your vehicle images here

                    </h2>

                </div>

                <div class="grid_12 content" style="background:#d4ecff; padding-top:25px;">

                    <div class="grid_7 bg111" >

                        <div class="grid_3 alpha"  style="display: none;">

                            <div id="dragAndDropFiles" class="uploadArea">

                                <h1>

                                    Drag & drop images here

                                </h1>

                            </div>

                        </div>

                        <div class="grid_4 omega" style="display: none;">

                            <ul>

                                <li style="float:left;">

                                    <div class="uploadArea1">

                                    </div>

                                </li>

                                <li style="float:left;">

                                    <div class="uploadArea1">

                                    </div>

                                </li>

                                <li style="float:left;">

                                    <div class="uploadArea1">

                                    </div>

                                </li>

                                <li style="float:left; margin-top:-10px;">

                                    <div class="uploadArea1">

                                    </div>

                                </li>

                                <li style="float:left; margin-top:-10px;">

                                    <div class="uploadArea1">

                                    </div>

                                </li>

                                <li style="float:left; margin-top:-10px;">

                                    <div class="uploadArea1">

                                    </div>

                                </li>

                            </ul>

                        </div>


                        <form method="post" name="demoFiler" id="demoFiler" enctype="multipart/form-data" action="/upload/do_upload">

                            <input id="upload_id" name="upload_id" type="hidden" value="<?= $value ?>" />

                            <input type="file" name="userfile" size="20" />
                            <input type="submit" name="submitHandler" id="submitHandler" value="Upload" class="buttonUpload" />


                        </form>

                        <div class="progressBar">

                            <div class="status">

                            </div>

                        </div>

                    </div>

                    <div class="grid_3 tooltip omega">

                        <ul>

                            <li>

                                Use original photos in .jpg, .gif or .png

                            </li>
                            <li>
                                Choice to add multiple image files.
                            </li>
                            <li>
                                Avoid low resolution images
                            </li>
                        </ul>
                    </div>
                </div>
                <a href="<?= site_url('welcome/profile/myvehicle'); ?>" role="button" class="btn">Finish</a>
            </div>
            <div class="col-xs-50 " style="display: <?= $formdisplay ?>;">
                <form method="post" action="<?= base_url() ?>welcome/usedCarsSell">
                    <div class="col-xs-50">
                        <h2 class="mb1">Vehicle information	</h2>
                    </div>
                    <div class="col-xs-50 col-sm-25">
                        <div class="col-xs-50">
                            <div class="col-xs-20">
                               <label class="name">Title for your Ad</label>
                            </div>
                            <div class="col-xs-26"><input required="required" name='adtitle' id="adtitle" class="text required form-control" type="text" placeholder=""/>
                            </div>
                        </div>
                        <div class="col-xs-50" hidden="hidden">
                            <div class="col-xs-20">
                                    <label class="name">Vehicle type</label>
                            </div>
                            <div class="col-xs-26">
                                

                                    <?php
                                    if ($this->uri->segment(3) == 'bike') {
                                    $type=1;
                                       
                                    } else
                                    if ($this->uri->segment(3) == 'car') {
                                    $type=2;
                                        
                                    } 
                                        ?>
                                 <input type="text" value="<?php echo $type;?>" id="vehicletype" name="vehicletype">
                            </div>
                        </div>
                        <div class="col-xs-50">
                            <div class="col-xs-20">
                                    <label class="name">Brand Name</label>
                            </div>
                            <div class="col-xs-26">
                                <select id="company" class="select required form-control" name="company">
                                    <option value="0" selected="selected">Please select</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-50">
                            <div class="col-xs-20">
                                    <label class="name">Model</label>
                            </div>
                            <div class="col-xs-26">
                                <select class="select required form-control" name="model" id="model">
                                    <option value="0" selected="selected">Please select</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-50">
                            <div class="col-xs-20">
                                    <label class="name">Variants</label>
                            </div>
                            <div class="col-xs-26">
                                <select class="select required form-control" name="variant" id="variant">
                                    <option value="0">Please select</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-50">

                            <div class="col-xs-20">
                                    <label class="name">Vehicle year&month</label>
                            </div>
                            <div class="col-xs-26">
                            	<div class="col-xs-25">
                                <select name="model_year" class="select required form-control" id="year">
                                    <option value="0" selected="selected">Please select</option>
                                    <?php
                                    $i = 2014;
                                    while ($i >= 1920) {
                                        echo '<option value="' . $i . '">' . $i . '</option>';
                                        $i--;
                                    }
                                    ?>
                                </select>
                                </div>
                                <div class="col-xs-25">
                                <select name="month" class="select required form-control" id="month">
                                    <option value="0" selected="selected">Please select</option>
                                    <option value="1" >January</option>
                                    <option value="2" >February</option>
                                    <option value="3">March</option>
                                    <option value="4" >April</option>
                                    <option value="5" >May</option>
                                    <option value="6" >June</option>
                                    <option value="7" >July</option>
                                    <option value="8">August</option>
                                    <option value="9" >September</option>
                                    <option value="10" >October</option>
                                    <option value="11" >November</option>
                                    <option value="12" >December</option>
                                </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-50">
                            <div class="col-xs-20">
                                    <label class="name">District</label>
                            </div>
                            <div class="col-xs-26">
                                <select id="district" class="select  required form-control">
                                    <option value="0" selected="selected">Please select</option>
                                    <?php
                                    $onroad_placequery = $this->db->get_where('place', array('type' => 3));
                                    foreach ($onroad_placequery->result() as $rowonroad_place) {
                                        $place_id = $rowonroad_place->place_id;
                                        echo '<option  value="' . $place_id . '">' . $rowonroad_place->placename . '</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-50">
                            <div class="col-xs-20">
                                    <label class="name">Place</label>
                            </div>
                            <div class="col-xs-26">
                                <input class="text required form-control" list="places" name="place_id" id="place"/>

                            </div>
                        </div>
                        <div class="col-xs-50">
                            <div class="col-xs-20">
                                    <label class="name">Condition</label>
                            </div>

                            <div class="col-xs-26">
                                <select class="select required form-control" name="con_id" id="condition">
                                    <option value="0" selected="selected">Please Select</option>
                                    <?php
                                    $onroad_conditionquery = $this->db->get('condition');
                                    foreach ($onroad_conditionquery->result() as $rowonroad_condition) {
                                        $con_id = $rowonroad_condition->con_id;
                                        echo '<option  value="' . $con_id . '">	' . $rowonroad_condition->condition_name . '	</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-50">
                            <div class="col-xs-20">
                                <label class="name">Color</label>
                            </div>
                            <div class="col-xs-26">
                                <input  required="required" type="text" class="text required form-control" name="color_id" id="color"/>
                            </div>
                        </div>
                       
                        <div class="col-xs-50">
                            <div class="col-xs-20">
                                    <label class="name">
                                        Insurance end date
                                    </label>
                            </div>
                            <div class="col-xs-26">
                                <input id="expdate" name="expdate" type="text" class="date form-control" value="<?= date('Y/m/d'); ?>" data-date-format="YYYY/MM/DD"/>
                            </div>
                        </div>

                        <div class="col-xs-50">
                            <div class="col-xs-20">
                                    <label class="name">
                                        Idv value
                                    </label>
                            </div>
                            <div class="col-xs-26">
                                <input id="idv" name="idv" type="number" class=" form-control nonmand" placeholder=""/>
                            </div>
                        </div>
                        <div class="col-xs-50">
                            <div class="col-xs-20">
                                    <label class="name">
                                        Current insurance company
                                    </label>
                            </div>
                            <div class="col-xs-26">
                                <input id="inscomp" name="inscomp"  required="required" type="text" class="text required form-control" placeholder=""/>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-50 col-sm-25">

                        <div class="col-xs-50">
                            <div class="col-xs-20">
                                    <label class="name">
                                        Kilometers covered
                                    </label>
                            </div>
                            <div class="col-xs-26">
                                <div  class="col-xs-40">
                                    <input id="Odometer" name="kilo_meter" required="required" class="text required number form-control" type="number" placeholder=""/></div>
                                &nbsp;&nbsp;&nbsp;Kms.
                            </div>	</div>
                        <div class="col-xs-50">
                            <div class="col-xs-20">
                                    <label class="name">
                                        Mileage
                                    </label>
                            </div>
                            <div class="col-xs-26">
                                <div  class="col-xs-40">
                                    <input id="Mileage"   name="millage" class=" form-control nonmand" type="number" placeholder=""/></div>
                                &nbsp;&nbsp;&nbsp;Kms.
                            </div>
                        </div>
                        <div class="col-xs-50">
                            <div class="col-xs-20">
                                    <label class="name">
                                        Description
                                    </label>
                            </div>
                            <div class="col-xs-26">
                                <textarea required="required" id="textarea" class="required textarea form-control" name="discription" data-constraints='@Required @Length(min=20,max=999999)'></textarea>
                            </div>
                        </div>
                        <div class="col-xs-50">
                            <div class="col-xs-20">
                                    <label class="name">
                                        Register number
                                    </label>
                            </div>
                            <div class="col-xs-26">
                                <input id="register" name="reg_no"  required="required" type="text" class="text required form-control" placeholder=""/>
                            </div>
                        </div>
                        <div class="col-xs-50">
                            <div class="col-xs-20">
                                    <label class="name">
                                        Price
                                    </label>
                            </div>
                            <div class="col-xs-26">
                                <div class="col-xs-25">
                                    <input id="inr" name="inr"  required="required" type="number" style="padding-left: 30px;" class="required input form-control" placeholder=""/>
                                </div>
                                <div class="col-xs-25">
                                    <select  class="select required form-control" name="price" id="price">
                                        <option value="0" selected="selected">
                                            Please select
                                        </option>
                                        <?php
                                        $onroad_price_typequery = $this->db->get('onroad_price_type');
                                        foreach ($onroad_price_typequery->result() as $rowonroad_price_type) {
                                            $pr_id = $rowonroad_price_type->pr_id;
                                            echo '	<option  value="' . $pr_id . '">	' . $rowonroad_price_type->pr_type_name .
                                            '	</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-50">
                            <div class="col-xs-20">
                                    <label class="name">
                                        Ownership details
                                    </label>
                            </div>
                            <div class="col-xs-26">
                                <textarea required="required" id="vehicleauth" class="required textarea form-control" name="vehicleauth" data-constraints='@Required @Length(min=20,max=999999)'></textarea>
                            </div>
                        </div>
                        <div class="col-xs-50">
                            <div class="col-xs-20">
                                    <label class="name">
                                        Mobile number
                                    </label>
                            </div>
                            <div class="col-xs-26">
                            <div class="col-xs-10">
                            	<input id="cuncode" name="cuncode" value="+91"  required="required" type="text" class="number text required form-control" />
                            </div>
                            <div class="col-xs-40">
                                <input id="number" name="number" required="required" type="text" class="number text required form-control" />
                            </div>
                            </div>
                        </div>
                        <div class="col-xs-50">
                            <div class="col-xs-20">
                                    <label class="name">
                                        Land number
                                    </label>
                            </div>
                            <div class="col-xs-26">
                            	<div class="col-xs-18">
                                	<input id="stdCod" name="stdCod"   type="text" class=" form-control" placeholder="Std Code"/>
                                </div>
                                <div class="col-xs-32">
                                	<input id="lnumber" name="lnumber"   type="text" class=" form-control" placeholder="Number"/>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-50">
                            <div class="col-xs-20">
                                    <label class="name">
                                        Fuel type
                                    </label>
                            </div>
                            <div class="col-xs-26">
                                <select name="ftype" class="select tmSelect auto form-control" id="ftype"  data-class="tmSelect tmSelect2" data-constraints="">
                                    <option value="">Select</option>
                                    <option value="Diesel">Diesel</option>
                                    <option value="Petrol">Petrol</option>
                                    <option value="LPG">LPG</option>
                                    <option value="CNG">CNG</option>
                                    <option value="Electric">Electric</option>
                                    <option value="Hybrid">Hybrid</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-50">
                            <div class="col-xs-20">
                                    <label class="name">
                                        Transmission 
                                    </label>
                            </div>
                            <div class="col-xs-26">
                               <select name="tmission" class="select tmSelect auto form-control" id="tmission"  data-class="tmSelect tmSelect2" data-constraints="">
                                    <option value="">Select</option>
                                    <option value="Manual">Manual</option>
                                    <option value="Automatic">Automatic</option>
                                    
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="clear">
                    </div>
                    <div class="grid_12" align="center">
                        <p>
                            <label>&nbsp;</label>
                            <input id="sendinformation" name="sendinformation" type="submit" class="btn" value="Next&#8594;" />
                        </p>
                    </div>
                </form>
            </div>
        </div>