<div class="slider_wrapper">
      <div id="camera_wrap1" class="">
      
        <div data-src="<?php echo IMAGES_PATH;?>advertisement/kairaliad.jpg"></div>
        <div data-src="<?php echo IMAGES_PATH;?>/slide4.jpg"></div>
        <div data-src="<?php echo IMAGES_PATH;?>/slide5.jpg"></div>  
        
       </div>
</div>   