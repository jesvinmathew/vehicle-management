<div class="form_block"  style="background: #ff3f42; color: #fff;">
    <div class="title">
        <div class="nav1">		
            <ul id="tabs1">
                <li><a class="current" href="#">Cars</a></li>
                <li><a href="#">Bikes</a></li>
            </ul>
            <br/>
            <span id="indicator1"></span>
        </div>
    </div>
    <div id="content1">
        <section>
            <p>	
            <form id="carSearchForm" action="<?=site_url('welcome/search/new/car');?>">  
                <em>CAR Make</em>
                <select name="company" class="tmSelect auto form-control" id="carCompany" data-class="tmSelect tmSelect2" data-constraints="">
                    <option value="">ALL CAR TYPES</option>

                </select>
                <div class="clear"></div>
                <em>Fuel Type</em>
                <select id="fueltype" name="fueltype" class="tmSelect auto form-control" data-class="tmSelect tmSelect2" data-constraints="">
                    <option value="">Any</option>

                </select>


                <div class="clear"></div>
                <input type="submit" class="btn1" value="search">
            </form>
            </p>
        </section>
        <section>
            <p>	
            <form id="bickSearchForm" action="<?=site_url('welcome/search/new/bike');?>">  
                <em>Bike Make</em>
                <select name="company" class="tmSelect auto form-control" id="bikeCompany" data-class="tmSelect tmSelect2" data-constraints="">
                    <option value="">ALL Bike TYPES</option>
                </select>
                <div class="clear"></div>
                <em>Fuel Type</em>
                <select id="bikefuel" name="fueltype" class="tmSelect auto form-control" data-class="tmSelect tmSelect2" data-constraints="">
                    <option value="">Any</option>
                    <option value="1">Petrol</option>
                    <option value="2">Diesel</option>
                </select>
                <div class="clear"></div>
                <input type="submit" class="btn1" value="search">
            </form>
            </p>
        </section>
    </div>
    <div class="clear"></div>
</div>