			<div class="grid_9">
        		<h2>Popular Used Cars</h2>
                <div class="grid_2 alpha content">
          			<ul>
            			<li><h5><a href="#">Alappuzha -  <span>2,580</span></a></h5></li>
            			<li><h5><a href="#">Kannur -  <span> 2,451</span></a></h5></li>
            			<li><h5><a href="#">Kochi -  <span> 16,443</span></a></h5></li>
          			</ul>
        		</div>
        		<div class="grid_2 content">
          			<ul>
            			<li><h5><a href="#">Kollam -  <span> 5,633</span></a></h5></li>
                        <li><h5><a href="#">Kottayam -  <span>  6,651</span></a></h5></li>
                        <li><h5><a href="#">Kozhikode -  <span>  4,733</span></a></h5></li>
          			</ul>
                </div>
                <div class="grid_2 content">
                  	<ul>
                        <li><h5><a href="#">Malappuram -  <span>  2,684</span></a></h5></li>
                        <li><h5><a href="#">Manjeri -  <span>  875</span></a></h5></li>
                        <li><h5><a href="#">Palakkad -  <span>  3,047</span></a></h5></li>  
                  	</ul>
                </div>
            	<div class="grid_3 content">
                    <ul>
                        <li><h5><a href="#">Thiruvananthapuram -  <span>   8,334</span></a></h5></li>
                        <li><h5><a href="#">Thrissur -  <span>   7,214</span></a></h5></li>
                        <li><h5><a href="#">Tiruvalla -  <span>   1,800</span></a></h5></li>
                    </ul>
                </div>        
            </div>